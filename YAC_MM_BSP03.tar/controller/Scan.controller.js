sap.ui.define(    
[    "sap/ui/core/mvc/Controller",
    "sap/m/MessageToast",
    "sap/ui/model/json/JSONModel",
    "sap/ui/model/odata/v2/ODataModel",
    'sap/m/MessageBox',
    "sap/ui/model/Filter",
    "sap/m/Dialog",
    'sap/ui/layout/VerticalLayout',
    'sap/m/Label',
    'sap/ui/layout/form/SimpleForm'
], function (Controller, MessageToast,JSONModel,ODataModel, MessageBox,Filter,Dialog,VerticalLayout,Label,SimpleForm) {
    "use strict";
    jQuery.sap.require("sap.ndc.BarcodeScanner");
    var flag = false;
    var NONE = "None";
    var ERROR = "Error"
    var oF4Model,typeModel,settingModel;
    var defaultData = {};
    //proxy/http/160.21.205.176:8001//?sap-client=331
    var oModel = new ODataModel ("/nsbsp03/sap/opu/odata/sap/ZGTMMF020_SRV/",true);
    return Controller.extend("ns.bsp03.controller.Scan", { 
        
        onToLanchpad: function(){
            history.go(-1);
        },
        
        onInit : function(){
          flag = false;
            var that = this;
            this.getView().byId("status").setState(false);
            oModel.read("/UserParaSet/",{
                async : false,
                success: function(oERP, oResponse){

                  defaultData.movementType = oERP.results[0].movementType;
                  defaultData.plant = oERP.results[0].plant;
                  defaultData.issueLocation = oERP.results[0].issueLocation;
                  defaultData.receiptLocation = oERP.results[0].receiptLocation;

                    that.getView().setModel((new JSONModel({
                      postingDate: new Date(),
                      movementType: oERP.results[0].movementType,
                      plant: oERP.results[0].plant,
                      issueLocation: oERP.results[0].issueLocation,
                      materialNumber: "",
                      materialDesc: "",
                      batch: "",
                      receiptLocation: oERP.results[0].receiptLocation,
                      quantity: "",
                      unit:"",
                      materialSlip: "",
                      text: "",
                      language: oERP.results[0].language
                    })), "data");
                    var aFilter = [];
                    aFilter[0] = new sap.ui.model.Filter({
                        path:     "plant",
                        operator: sap.ui.model.FilterOperator.EQ,
                        value1:	oERP.results[0].plant,
                        value2:   ""});
                    oModel.read("/Locations",{
                        async : false,
                        filters: aFilter,
                        success: function(oF4Data, oResponse){
                          if(oF4Data.results[0].msgty == 'E'){
                            that.fShowMessageBox('error', oF4Data.results[0].msg);
                            }else{
                              oF4Model = new JSONModel(oF4Data);
                            }
                        },
                        error: function(oError){
                          that.fShowMessageBox('error', oError.message);
                        }
                        
                    });
                    oModel.read("/MovementTypeSet",{
                        async : false,
                        success: function(typeData, oResponse){
                          if(typeData.results[0].msgty == 'E'){
                            that.fShowMessageBox('error', typeData.results[0].msg);
                            }else{
                              typeModel = new JSONModel(typeData);
                            }
                        },
                        error: function(oError){
                          that.fShowMessageBox('error', oError.message);
                        }
                        
                    })
                },
                error: function(oError){
                  that.fShowMessageBox('error', oError.message);
                }
            })
        },
        onScanError:function(){
          var that = this;
          var oJson = this.getView().getModel('data').getData();
          oJson.postingDate = that.getView().byId('postingDate').getDateValue();
            oJson.materialNumber = "";
            oJson.materialDesc = "";
            oJson.batch = "";
            oJson.quantity = "";
            oJson.unit = "";
            oJson.materialSlip = "";
            oJson.text = "";
            that.getView().setModel(new JSONModel(oJson) , "data");
            flag = false;
        },
        onLiveChange: function(evt){
          var sId = evt.getSource().getId()
          var str = evt.mParameters.newValue;
          str = str.toUpperCase();
          this.getView().byId(sId).setValue(str);
        },
        onScan: function(){
          flag = false;
          var that = this;
          var oData = this.getView().getModel('data');
          var oI18n = this.getView().getModel("i18n").getResourceBundle();
          if(true){
              //call method to scan
              sap.ndc.BarcodeScanner.scan(
                   
                  function(sResult){
                    //   MessageToast.show("We got a bar code\n" + "Result: " + sResult.text + "\n" + "Format: " + sResult.format + "\n" + "Cancelled: " + sResult.cancelled);
                                
                      //scan normally by user
                      if(sResult.cancelled == false){
//          var sResult = {};
//          sResult.text = "100020772,EA,72.000,4502294340,TEST,2016072101";
                        var result = sResult.text.split(',');
                        if(result.length != 6){
                          that.onScanError();
                          that.fShowMessageBox('error', oI18n.getText("codeError") + sResult.text);
                          return;
                        }
                        oData.setProperty("/materialNumber", result[0]);
                        oData.setProperty("/quantity", result[2]);
                        oData.setProperty("/batch", result[4]);
                          //set filter array
                          var aFilter = [];
                          //set material number filter
                          aFilter[0] = new sap.ui.model.Filter({
                              path:     "materialNumber",
                              operator: sap.ui.model.FilterOperator.EQ,
                              value1:   oData.getProperty("/materialNumber"),
                              value2:   ""});
                          //set login language
                          aFilter[1] = new sap.ui.model.Filter({
                              path:     "language",
                              operator: sap.ui.model.FilterOperator.EQ,
                              value1:   oData.getProperty("/language"), 
                              value2:   ""});
                          //set plant
                          aFilter[2] = new sap.ui.model.Filter({
                              path:     "plant",
                              operator: sap.ui.model.FilterOperator.EQ,
                              value1:   defaultData.plant, 
                              value2:   ""});
                          //get material description and unit
                          oModel.read("/EntitySets/",{
                                      filters: aFilter,
                                      success: function(oERP, oResponse){
                                          //check result: success
                                          if(oERP.results[0].msgty == 'S'){
                                              //set model
                                              oData.setProperty("/materialDesc", oERP.results[0].materialDesc);
                                              oData.setProperty("/unit", oERP.results[0].unit);
                                              flag = true;
                                              that.getView().byId('quantityid').focus();
                                              if (oERP.results[0].batchFlag == 'X') {
                                                  that.getView().byId('batchid').setEnabled(true);
                                              } else if(oERP.results[0].batchFlag == '') {
                                                  that.getView().byId('batchid').setEnabled(false);
                                                  that.getView().byId('batchid').setValue("");
                                                  that.getView().byId('batchlabelid').setRequired(false);
                                             }
                                          //check result: error
                                          }else{
                                              //error message output
                                            that.onScanError();
                                            that.fShowMessageBox('error', oERP.results[0].msg);
                                          }
                                      },
                                      error: function(oError){
                                          //error message output
                                        that.onScanError();
                                        that.fShowMessageBox('error', oError.message);
                                      }
                          })
                    }else{
                    that.onScanError();
                    that.fShowMessageBox('error', oI18n.getText("scanCancel"));
                    }
                })
          }
          else{
            that.onScanError();
            that.fShowMessageBox('error', oI18n.getText("scanError"));
          }
        },
        emptyCheckSave: function(){
          this.fClearMessage();
          var sPostingDate = this.getView().byId('postingDate').getValue();
            if (sPostingDate == null || sPostingDate == '') {
                this.getView().byId('postingDate').setValueState(ERROR);
                this.getView().byId('postingDate').focus();
                return false;
            }
            var sMovementType = this.getView().byId('movementType').getValue();
            if (sMovementType == null || sMovementType == '') {
                this.getView().byId('movementType').setValueState(ERROR);
                this.getView().byId('movementType').focus();
                return false;
            }
            var sIssueid = this.getView().byId('issueid').getValue();
            if (sIssueid == null || sIssueid == '') {
                this.getView().byId('issueid').setValueState(ERROR);
                this.getView().byId('issueid').focus();
                return false;
            }
            var sReceiptid = this.getView().byId('receiptid').getValue();
            if (sReceiptid == null || sReceiptid == '') {
                this.getView().byId('receiptid').setValueState(ERROR);
                this.getView().byId('receiptid').focus();
                return false;
            }
            var sMaterialNumberid = this.getView().byId('materialNumberid').getValue();
            if (sMaterialNumberid == null || sMaterialNumberid == '') {
                this.getView().byId('materialNumberid').setValueState(ERROR);
                this.getView().byId('materialNumberid').focus();
                return false;
            }
            var sMaterialDescid = this.getView().byId('materialDescid').getValue();
            if (sMaterialDescid == null || sMaterialDescid == '') {
                this.getView().byId('materialDescid').setValueState(ERROR);
                this.getView().byId('materialDescid').focus();
                return false;
            }
            var uncheckflag = this.getView().byId('batchid').getEnabled();
            if(uncheckflag){
                var sBatchid = this.getView().byId('batchid').getValue();
                if (sBatchid == null || sBatchid == '') {
                    this.getView().byId('batchid').setValueState(ERROR);
                    this.getView().byId('batchid').focus();
                    return false;
                }
            }
            
            var sQuantityid = this.getView().byId('quantityid').getValue();
            if (sQuantityid == null || sQuantityid == '') {
                this.getView().byId('quantityid').setValueState(ERROR);
                this.getView().byId('quantityid').focus();
                return false;
            }
            return true;
        },
        
      onSave: function(){
        var that = this;
        var oI18n = this.getView().getModel('i18n').getResourceBundle();
        
          //empty check first
      if(!flag){
        that.fShowMessageBox('error', oI18n.getText("notScan"));
        return;
      }
      if(!this.emptyCheckSave()){
        return;
      }
      var dataModel = this.getView().getModel("data");
      var oData = dataModel.getData();
      oData.postingDate = this.getView().byId("postingDate").getValue();
      var state = this.getView().byId("status").getState();
      if(state == true){
          oData.show = "";
      }else {
          oData.show = "X";
      }
      //post goods movement
      var oTimeStap = new Date();
      //Confirm
      var oSubDialog = new sap.m.Dialog({
              title: oI18n.getText("ConfirmTitle"),
              state: 'Warning',
              content: [new sap.m.Label({
                text: oI18n.getText("ConfirmText") + oData.materialNumber + "?"
              })]
            });
            oSubDialog.open();
            oSubDialog.addButton(new sap.m.Button({
              text: oI18n.getText("okBtn"),
              press: function() {
                oSubDialog.close();
                //post data
                oModel.create("/EntitySets" + '?' + oTimeStap , oData,{
                    async : false,
                      success: function(oResult, oResponse){
                        if(oResult.msgty == "E"){
                          that.fShowMessageBox('error', oResult.msg);
                        }else {
                          that.onScanError();
                          that.fShowMessageBox('success', oResult.msg);
                        }
                          
                      },
                      error: function(oError){
                        that.fShowMessageBox('error', oError.message);
                      }
                  });
              }
            }));
            //Cancel
            oSubDialog.addButton(new sap.m.Button({
                text: oI18n.getText("cancelBtn"),
                press: function() {
                  oSubDialog.close();
                }
              })); 
      },
      
   // confirm, alert, error, information, warning, success
        fShowMessageBox: function(type, content){
          var oI18n = this.getView().getModel('i18n').getResourceBundle();
            var bCompact = !!this.getView().$().closest(".sapUiSizeCozy").length;
            var Options = null;
            if(type == 'none'){
                Options = {
                        icon: sap.m.MessageBox.Icon.NONE,
                        title: "NONE",
                        actions: sap.m.MessageBox.Action.OK,
                        onClose: null,
                        styleClass: bCompact? "sapUiSizeCozy" : "",
                        initialFocus: null,
                        textDirection: sap.ui.core.TextDirection.Inherit
                };
            }
            else if(type == 'question'){
                Options = {
                        icon: sap.m.MessageBox.Icon.QUESTION,
                        title: "QUESTION",
                        actions: sap.m.MessageBox.Action.OK,
                        onClose: null,
                        styleClass: bCompact? "sapUiSizeCozy" : "",
                        initialFocus: null,
                        textDirection: sap.ui.core.TextDirection.Inherit
                };
            }
            else if(type == 'error'){
                Options = {
                        icon: sap.m.MessageBox.Icon.ERROR,
                        title: oI18n.getText("boxError"),
                        actions: sap.m.MessageBox.Action.OK,
                        onClose: null,
                        styleClass: bCompact? "sapUiSizeCozy" : "",
                        initialFocus: null,
                        textDirection: sap.ui.core.TextDirection.Inherit
                };
            }
            else if(type == 'information'){
                Options = {
                        icon: sap.m.MessageBox.Icon.INFORMATION,
                        title: "INFORMATION",
                        actions: sap.m.MessageBox.Action.OK,
                        onClose: null,
                        styleClass: bCompact? "sapUiSizeCozy" : "",
                        initialFocus: null,
                        textDirection: sap.ui.core.TextDirection.Inherit
                };
            }
            else if(type == 'warning'){
                Options = {
                        icon: sap.m.MessageBox.Icon.WARNING,
                        title: "WARNING",
                        actions: sap.m.MessageBox.Action.OK,
                        onClose: null,
                        styleClass: bCompact? "sapUiSizeCozy" : "",
                        initialFocus: null,
                        textDirection: sap.ui.core.TextDirection.Inherit
                };
            }
            else if(type == 'success'){
                Options = {
                        icon: sap.m.MessageBox.Icon.SUCCESS,
                        title:  oI18n.getText("boxSuccess"),
                        actions: sap.m.MessageBox.Action.OK,
                        onClose: null,
                        styleClass: bCompact? "sapUiSizeCozy" : "",
                        initialFocus: null,
                        textDirection: sap.ui.core.TextDirection.Inherit
                };
            }
            sap.m.MessageBox.show(content, Options);

        },

        fClearMessage: function(){
            this.getView().byId('postingDate').setValueState(NONE);
            this.getView().byId('movementType').setValueState(NONE);
            this.getView().byId('issueid').setValueState(NONE);
            this.getView().byId('receiptid').setValueState(NONE);
            this.getView().byId('materialNumberid').setValueState(NONE);
            this.getView().byId('materialDescid').setValueState(NONE);
            this.getView().byId('batchid').setValueState(NONE);
            this.getView().byId('quantityid').setValueState(NONE);
        },
        
        onClear : function(){
          this.fClearMessage();
          this.onInit();
          flag = false;
        },
        //Location ValueHelp
        handleValueHelp: function (oEvent) {
            var sInputValue = oEvent.getSource().getValue();
            this.inputId = oEvent.getSource().getId();
            // create value help dialog
            if (!this._valueHelpDialog) {
                this._valueHelpDialog = sap.ui.xmlfragment("ns.bsp03.view.Dialog",this);
                this.getView().addDependent(this._valueHelpDialog);
                this._valueHelpDialog.setModel(oF4Model);
            }
            // create a filter for the binding
            this._valueHelpDialog.getBinding("items").filter([new Filter( "location",  sap.ui.model.FilterOperator.Contains, sInputValue )]);
            // open value help dialog filtered by the input value
            this._valueHelpDialog.open(sInputValue);
        },
        _handleValueHelpSearch: function (evt) {
            var sValue = evt.getParameter("value");
            var oFilter = new Filter( "location", sap.ui.model.FilterOperator.Contains, sValue);
            evt.getSource().getBinding("items").filter([oFilter]);
        },
        _handleValueHelpClose: function (evt) {
            var oSelectedItem = evt.getParameter("selectedItem");
            if (oSelectedItem) {
                var productInput = this.getView().byId(this.inputId);
                productInput.setValue(oSelectedItem.getTitle());
                $("#V1").html(oSelectedItem.getTitle());
            }
            evt.getSource().getBinding("items").filter([]);
        },
        
        //Type 
        handleValueHelp_type: function (oEvent) {
            var sInputValue = oEvent.getSource().getValue();
            this.inputId = oEvent.getSource().getId();
            // create value help dialog
            if (!this._valueHelpDialog_type) {
                this._valueHelpDialog_type = sap.ui.xmlfragment("ns.bsp03.view.Dialog_type",this);
                this.getView().addDependent(this._valueHelpDialog_type);
                this._valueHelpDialog_type.setModel(typeModel);
            }
            // create a filter for the binding
            this._valueHelpDialog_type.getBinding("items").filter([new Filter( "location",  sap.ui.model.FilterOperator.Contains, sInputValue )]);
            // open value help dialog filtered by the input value
            this._valueHelpDialog_type.open(sInputValue);
        },
        _handleValueHelpSearch_type: function (evt) {
            var sValue = evt.getParameter("value");
            var oFilter = new Filter( "movementType", sap.ui.model.FilterOperator.Contains, sValue);
            evt.getSource().getBinding("items").filter([oFilter]);
        },
        _handleValueHelpClose_type: function (evt) {
            var oSelectedItem = evt.getParameter("selectedItem");
            if (oSelectedItem) {
                var productInput = this.getView().byId(this.inputId);
                productInput.setValue(oSelectedItem.getTitle());
                $("#V1").html(oSelectedItem.getTitle());
            }
            evt.getSource().getBinding("items").filter([]);
        },
        //user default setting
        onSetting: function(){
          var oI18n = this.getView().getModel('i18n').getResourceBundle();
          var that = this;
          if(!that._settingDialog){
            settingModel = {
                  movementType : defaultData.movementType,//Movement Type
                  plant : defaultData.plant,//Plant
                  issueLocation : defaultData.issueLocation,//Issuing Location
                        receiptLocation: defaultData.receiptLocation//Receiving Location
              }
              sap.ui.getCore().setModel(new JSONModel(settingModel),"settingData")
            that._settingDialog = new sap.m.Dialog({
                    title: oI18n.getText("defaultTitle"),
                    icon: "sap-icon://employee",
                    state: 'Success',
                    content : [
                    new SimpleForm({
                    content: [new VerticalLayout({
                    width: '350px',
                    content: [
                          new sap.m.Label({text : oI18n.getText("movementType"),required:true}),
                              new sap.m.Input("defaultmovementType",{value : "{settingData>/movementType}",
                                valueLiveUpdate:true,maxLength:3}),
                              new sap.m.Label({text : oI18n.getText("plant"),required:true}),
                              new sap.m.Input("defaultplant",{value : "{settingData>/plant}",
                                valueLiveUpdate:true,maxLength:4}),
                            new sap.m.Label({text : oI18n.getText("issueLocation"),required:true}),
                              new sap.m.Input("defaultissueLocation",{value : "{settingData>/issueLocation}",
                                valueLiveUpdate:true,maxLength:4}),
                              new sap.m.Label({text : oI18n.getText("receiptLocation"),required:true}),
                              new sap.m.Input("defaultreceiptLocation",{value : "{settingData>/receiptLocation}",
                                valueLiveUpdate:true,maxLength:4})
                          ]})]
                    })]
                    });
            that._settingDialog.addButton(new sap.m.Button({
                    text: oI18n.getText("save"),
                    type: "Accept",
                    icon: "sap-icon://save",
                    press: function() {
                      if(!that.emptyCheckSet()){
                        return;
                      }else{
                        settingModel.movementType = sap.ui.getCore().byId('defaultmovementType').getValue();
                        settingModel.plant = sap.ui.getCore().byId('defaultplant').getValue();
                        settingModel.issueLocation = sap.ui.getCore().byId('defaultissueLocation').getValue();
                        settingModel.receiptLocation = sap.ui.getCore().byId('defaultreceiptLocation').getValue();
                        sap.ui.getCore().setModel(new JSONModel(settingModel),"settingData");
                        var oTimeStap = new Date();
                        var oData = {};
                        oData.movementType = sap.ui.getCore().byId('defaultmovementType').getValue();
                        oData.plant = sap.ui.getCore().byId('defaultplant').getValue();
                        oData.issueLocation = sap.ui.getCore().byId('defaultissueLocation').getValue();
                        oData.receiptLocation = sap.ui.getCore().byId('defaultreceiptLocation').getValue();
                        //TODO OData create
                        oModel.create("/UserParaSet/" + '?' + oTimeStap , oData,{
                            success: function(oResult, oResponse){
                              if(oResult.msgty == "E"){
                                that.fShowMessageBox('error', oResult.msg);
                        }else {
                          that.onInit();
                        }
                              },
                              error: function(oError){
                                  that.fShowMessageBox('error', oError.message);
                              }
                          });
                        that._settingDialog.close();
                      }
                     }
                }));
              that._settingDialog.insertButton(new sap.m.Button({
                    text: oI18n.getText("cancelBtn"),
                    press: function() {
                      that._settingDialog.close();
                    }
                })); 
          }

          that._settingDialog.open();
           

        },
        emptyCheckSet: function(){
          var oType = sap.ui.getCore().byId('defaultmovementType');
          var oPlant = sap.ui.getCore().byId('defaultplant');
          var oIssueLocation = sap.ui.getCore().byId('defaultissueLocation');
          var oReceiptLocation = sap.ui.getCore().byId('defaultreceiptLocation');
          oType.setValueState(NONE);
          oPlant.setValueState(NONE);
          oIssueLocation.setValueState(NONE);
          oReceiptLocation.setValueState(NONE);
          var sType = oType.getValue();
          var sPlant = oPlant.getValue();
          var sIssueLocation = oIssueLocation.getValue();
          var sReceiptLocation = oReceiptLocation.getValue();

          if (sType == null || sType == '') {
              oType.setValueState(ERROR);
              oType.focus();
                return false;
            }
            if (sPlant == null || sPlant == '') {
              oPlant.setValueState(ERROR);
              oPlant.focus();
                return false;
            }
            if (sIssueLocation == null || sIssueLocation == '') {
              oIssueLocation.setValueState(ERROR);
              oIssueLocation.focus();
                return false;
            }
            if (sReceiptLocation == null || sReceiptLocation == '') {
              oReceiptLocation.setValueState(ERROR);
              oReceiptLocation.focus();
                return false;
            }

            return true;
        }

    });
});