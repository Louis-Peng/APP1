sap.ui.define([
	"ns/bsp03/test/unit/controller/App.controller"
], function () {
	"use strict";
});
