sap.ui.define([], function() {
    "use strict";
    var Formatter = {

    iconState: function(Status) {
        if (Status == 1) {
            return "sap-icon://message-warning";
        } else if(Status == ''){
            return "";
        } else if(Status == 0){
            return "sap-icon://message-success";
        } else if(Status == "1-"){
            return "sap-icon://message-warning";
        } else {
            return "";
        }
    },
    iconColor: function(Status){
        if (Status == 1) {
            return "Error";
        } else if(Status == ''){
            return;
        } else if(Status == 0){
            return "Success";
        } else if(Status == "1-"){
            return "Warning";
        } else {
            return;
        }
    },
    buttonText: function(Rgekz){
        if (Rgekz === 'X') {
                return 'Navigation';
            } else {
                return 'Inactive';
            }

    },
    textColor: function(signal){
        if (signal == 1) {
            return "Error";
        }  else if(signal == -1){
            return "Success";
        } else {
            return;
        }
    }
    };
    return Formatter;
}, /* bExport= */true);