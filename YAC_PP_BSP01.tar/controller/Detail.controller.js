sap.ui.define([
    'sap/ui/core/mvc/Controller',
    'sap/ui/model/Filter',
    'sap/ui/model/FilterOperator',
    'sap/m/MessageToast',
    'sap/ui/model/json/JSONModel',
    'sap/ui/model/odata/ODataModel',
    'sap/ui/model/resource/ResourceModel',
    'sap/ui/core/UIComponent',
    'sap/ui/core/routing/History',
    'sap/m/MessageBox'
    ],
    function(
        Controller,
        Filter,
        FilterOperator,
        MessageToast,
        JSONModel,
        ODataModel,
        ResourceModel,
        UIComponent,
        History,
        MessageBox
        ) {
    'use strict';
    var Aufnr, Matnr, Werks;
    var Flag;
    var sCharg,sMenge,sMeins;
    var clickflag = false;
    var Quantity3, Quantity1, QuantityPlan;
    var navModel,navData;
    var EMPTY = '';
    var NULL = null;
    var sCeil1;
    var ERROR = 'Error';
    var NONE = 'None';
    var bUpdate = false;
//    var sZGTPPF010_SRV = 'proxy/http/160.21.205.176:8001/sap/opu/odata/SAP/ZGTPPF010_SRV?sap-client=331';
    var sZGTPPF010_SRV = '/nsbsp01/sap/opu/odata/SAP/ZGTPPF010_SRV';
    var sOrderIssueSet = '/OrderIssueSet';
    return Controller.extend('ns.bsp01.controller.Detail', {
    onInit: function() {
        var oRouter = UIComponent.getRouterFor(this);
        oRouter.getRoute('detail').attachMatched(this._onRouteMatched, this);
    },
    _onRouteMatched: function(oEvent) {
        // Set bUpdate
        var that = this;
        bUpdate = false;
        var oI18n = this.getView().getModel('i18n').getResourceBundle();
        this.fRemoveValue();
        var oArgs = oEvent.getParameter('arguments');
        Aufnr = oArgs.Aufnr;
        Matnr = oArgs.Matnr;
        Werks = oArgs.Werks;
        Flag = oArgs.flag;;
        sCeil1 = oArgs.Ceil1;
        this.getView().byId('lgpro').setValue(oArgs.Lgpro);
        if (Flag == "true") {
        var values = oArgs.Scan;
        var aResult = values.split(',');
        this.getView().byId('idnrk').setValue(aResult[0]);
        sCharg = aResult[5];
        sMenge = aResult[2];
        sMeins = aResult[1];
        this.fShowBusyIndicator();
        var oTimeStap = new Date();
        var oModel = new ODataModel(sZGTPPF010_SRV, true);
        var aFilter = [];
        // Matnr
        var oMatnr = new Filter({
            path: 'Matnr',
            operator: FilterOperator.EQ,
            value1: oArgs.Matnr,
            value2: ''
        });
        aFilter.push(oMatnr);
        // Idnrk
        var oIdnrk = new Filter({
            path: 'Idnrk',
            operator: FilterOperator.EQ,
            value1: aResult[0],
            value2: ''
        });
        aFilter.push(oIdnrk);
        oModel.read(sOrderIssueSet + '?' + oTimeStap, {
            async : false,
            filters: aFilter,
            success: function(oData){
                var values = oData.results;
                if(values.length > 0){
                    that.getView().byId('maktx').setValue(values[0].Maktx);
                    var sLabst = values[0].Labst;
                    var JsonModel = new JSONModel({
                        "results": [{
                              "Charg": aResult[5],
                              "Labst": sLabst,
                              "Menge": aResult[2],
                              "Meins": aResult[1]
                          }
                        ]
                      });
                  that.getView().byId("tableid").setModel(JsonModel);
                    if (oArgs.Meins == NULL || $.trim(oArgs.Meins) == EMPTY){
                        that.getView().byId('meins').setValue(values[0].Meins);
                    }
                }
                else{
                    that.fShowMessageBox('warning', oI18n.getText('NoData'));
                }
                that.fHideBusyIndicator();
            },
            error: function(){
                that.fHideBusyIndicator();
                that.fShowMessageBox('error', oI18n.getText('SystemError'));
            }
        });
        }
        else{
            navModel = this.getOwnerComponent().getModel('navModel');
            navData = navModel.getData();
            QuantityPlan = navData.MengePlan;
            var smaterid = navData.Idnrk;
            that.getView().byId('idnrk').setValue(smaterid);
            var oTimeStap = new Date();
            var oModel = new ODataModel(sZGTPPF010_SRV, true);
            var aFilter = [];
            // Matnr
            var oMatnr = new Filter({
                path: 'Matnr',
                operator: FilterOperator.EQ,
                value1: oArgs.Matnr,
                value2: ''
            });
            aFilter.push(oMatnr);
            var oIdnrk = new Filter({
                path: 'Idnrk',
                operator: FilterOperator.EQ,
                value1: smaterid,
                value2: ''
            });
            aFilter.push(oIdnrk);
            var oAufnr = new Filter({
                path: 'Aufnr',
                operator: FilterOperator.EQ,
                value1: oArgs.Aufnr,
                value2: ''
            });
            aFilter.push(oAufnr);
            var oCrate = new Filter({
                path: 'Crate',
                operator: FilterOperator.EQ,
                value1: sCeil1,
                value2: ''
            });
            aFilter.push(oCrate);
            oModel.read(sOrderIssueSet + '?' + oTimeStap, {
                async : false,
                filters: aFilter,
                success: function(oData){
                    var values = oData.results;
                    if(values.length > 0){
                        var oJSONModel = new JSONModel(oData);
                        that.getView().byId('maktx').setValue(values[0].Maktx);
                        var acquanty = values[0].Menge;
                        var oModel = new JSONModel(oData);
                        that.getView().byId("tableid").setModel(oModel);
                    }
                    else{
//                        that.fShowMessageBox('warning', oI18n.getText('NoData'),{duration:50000});
                    }
                    that.fHideBusyIndicator();
                },
                error: function(){
                    that.fHideBusyIndicator();
                    that.fShowMessageBox('error', oI18n.getText('SystemError'));
                }
            });
        }
    },
    onConsume: function(oEvent) {
        var oI18n = this.getView().getModel('i18n').getResourceBundle();
        this.fClearMessage();
        // check item
        if(!this.fCheckItems()){
            return;
        }
        if(clickflag == true){
            this.fShowMessageBox('error', oI18n.getText("Norepeat"));
            return;
        }
        clickflag = true;
        var oEntry = {};
        oEntry.Matnr = Matnr;
        oEntry.Aufnr = Aufnr;
        oEntry.Charg = "";
        oEntry.Idnrk = this.getView().byId('idnrk').getValue();
        oEntry.Lgpro = this.getView().byId('lgpro').getValue();
        oEntry.Meins = "";
        oEntry.Menge = "0";
        oEntry.Werks = Werks;
        oEntry.Crate = sCeil1;
        oEntry.Button = EMPTY;
        var oModel = this.getView().byId("tableid").getModel();
        var tableData = oModel.getData();
        var additemSet = oModel.getData().results;
        var sLength = additemSet.length;
        sMenge = tableData.results[0].Menge;
        if (Flag == "true"){
            oEntry.Charg = sCharg;
            oEntry.Menge = sMenge;
            oEntry.Meins = sMeins;
        } else {
            var sItems = [];
            for(var i in additemSet){
                var sCharg = additemSet[i].Charg;
                var sMenge = additemSet[i].Menge;
                var sMeins = additemSet[i].Meins;
                var line = sCharg + ";" + sMenge + ";" + sMeins;
                sItems[i] = line;
            }
            var sLine = sItems.join("-");
            oEntry.Batchqty = sLine;
        }
        // loading
        this.fShowBusyIndicator();
        var oTimeStap = new Date();
        var that = this;
        var oModel = new ODataModel(sZGTPPF010_SRV, true);
        var aFilter = [];
        var aFilter1 = [];
        // Matnr
        var oMatnr = new Filter({
            path: 'Matnr',
            operator: FilterOperator.EQ,
            value1: Matnr,
            value2: ''
        });
        aFilter.push(oMatnr);
        aFilter1.push(oMatnr);
        // Idnrk
        var oIdnrk = new Filter({
            path: 'Idnrk',
            operator: FilterOperator.EQ,
            value1: this.getView().byId('idnrk').getValue(),
            value2: ''
        });
        aFilter.push(oIdnrk);
        aFilter1.push(oIdnrk);
        // Button
        var oButton = new Filter({
            path: 'Button',
            operator: FilterOperator.EQ,
            value1: '',
            value2: ''
        });
        aFilter.push(oButton);
        oModel.create(sOrderIssueSet + '?' + oTimeStap, oEntry, {
            async : false,
            filters: aFilter,
            success : function(data) {
                that.fHideBusyIndicator();
                if(data.Type == 'W'){
                    var oCheckDialog = new sap.m.Dialog({
                        title: oI18n.getText('confirm'),
                        type: 'Message',
                        state: 'Warning',
                        content: [ new sap.m.Label({
                            text: data.Message
                        }) ]
                    });
                    oCheckDialog.open();
                    oCheckDialog.addButton(new sap.m.Button({
                        text : oI18n.getText('btnOK'),
                        press : function() {
                            oCheckDialog.close();
                            // loading
                            that.fShowBusyIndicator();
                            // Button
                            var oButton = new Filter({
                                path: 'Button',
                                operator: FilterOperator.EQ,
                                value1: 'YES',
                                value2: ''
                            });
                            aFilter1.push(oButton);
                            oEntry.Button = 'YES';
                            var oTimeStap = new Date();
                            oModel.create(sOrderIssueSet + '?' + oTimeStap, oEntry, {
                                async : false,
                                filters: aFilter1,
                                success : function(data){
                                    that.fHideBusyIndicator();
                                    if(data.Type == 'E'){
                                        that.fShowMessageBox('error', data.Message);
                                        clickflag = false;
                                    }
                                    else {
                                        var oCheckDialog = new sap.m.Dialog({
                                            title: oI18n.getText('SUCCESS'),
                                            type: 'Message',
                                            state: 'Success',
                                            content: [ new sap.m.Label({
                                                text: oI18n.getText(data.Message)
                                            }) ]
                                        });
                                        oCheckDialog.open();
                                        oCheckDialog.addButton(new sap.m.Button({
                                            text : oI18n.getText('btnOK'),
                                            press : function() {
                                                oCheckDialog.close();
                                                clickflag = false;
                                                bUpdate = true;
                                                var bUpdateModel = new JSONModel({
                                                    bUpdate: bUpdate
                                                });
                                                that.getOwnerComponent().setModel(bUpdateModel, 'bUpdateModelppf010');
                                                history.go(-1);
                                            }
                                        }));
                                    }
                                },
                                error : function(data) {
                                    that.fHideBusyIndicator();
                                    clickflag = false;
                                    that.fShowMessageBox('error', data.Message);
                                }
                            });
                        }
                    }));
                    oCheckDialog.addButton(new sap.m.Button({
                        text : oI18n.getText('btnCancel'),
                        press : function() {
                            clickflag = false;
                            oCheckDialog.close();
                        }
                    }));
                }else if(data.Type == 'S'){
                    var oSuccessDialog = new sap.m.Dialog({
                        title: oI18n.getText('SUCCESS'),
                        type: 'Message',
                        state: 'Success',
                        content: [ new sap.m.Label({
                            text: data.Message
                        }) ]
                    });
                    oSuccessDialog.open();
                    oSuccessDialog.addButton(new sap.m.Button({
                        text : oI18n.getText('btnOK'),
                        press : function() {
                            oSuccessDialog.close();
                            that.fRemoveValue();
                            clickflag = false;
                            bUpdate = true;
                            var bUpdateModel = new JSONModel({
                                bUpdate: bUpdate
                            });
                            that.getOwnerComponent().setModel(bUpdateModel, 'bUpdateModelppf010');
                            history.go(-1);
                            }
                    }));
                }
                else{//TODO
                    var oErrorDialog = new sap.m.Dialog({
                        title: oI18n.getText('ERROR'),
                        type: 'Message',
                        state: 'Error',
                        content: [ new sap.m.Label({
                            text: oI18n.getText(data.Message)
                        }) ]
                    });
                    oErrorDialog.open();
                    oErrorDialog.addButton(new sap.m.Button({
                        text : oI18n.getText('btnOK'),
                        press : function() {
                            oErrorDialog.close();
                            that.fRemoveValue();
                            clickflag = false;
                            bUpdate = true;
                            var bUpdateModel = new JSONModel({
                                bUpdate: bUpdate
                            });
                            that.getOwnerComponent().setModel(bUpdateModel, 'bUpdateModelppf010');
                            history.go(-1);
                        }
                    }));
                }
            },
            error : function(data) {
                that.fHideBusyIndicator();
                clickflag = false;
                that.fShowMessageBox('error', data.Message);
            }
        });
    },
    mengeChange: function(oEvent){
        var oI18n = this.getView().getModel("i18n").getResourceBundle();
        var that = this;
        var aTable = this.getView().byId("tableid");
        var allItems = aTable.getItems();
        var qtyInputItems = aTable.getModel();
        var qtyData = qtyInputItems.getData();
        var eventSource = oEvent.getSource();
        var QtyCurrentVal = oEvent.getParameters().value;
        var currentId = eventSource.sId;
        var QtyIds = [], QrQtyIds = [];
        var QtyVals = [], QRQtyVals = [], qrNum = [];
            for(var i = 0; i < allItems.length; i++){
                QtyIds[i] = allItems[i].mAggregations.cells[2].sId;
                QtyVals[i] = that.getView().byId(QtyIds[i]).getValue();
                    that.getView().byId(QtyIds[i]).setValue(QtyCurrentVal);
            }
    },
    // confirm, alert, error, information, warning, success
    fShowMessageBox: function(type, content){//TODO
        var oI18n = this.getView().getModel('i18n').getResourceBundle();
        var bCompact = !!this.getView().$().closest('.sapUiSizeCozy').length;
        var Options = NULL;
        if(type == 'error'){
            Options = {
                    icon: sap.m.MessageBox.Icon.ERROR,
                    title: oI18n.getText('ERROR'),
                    actions: sap.m.MessageBox.Action.OK,
                    onClose: null,
                    styleClass: bCompact? "sapUiSizeCozy" : "",
                    initialFocus: null,
                    textDirection: sap.ui.core.TextDirection.Inherit
            };
        }
        else if(type == 'warning'){
            Options = {
                    icon: sap.m.MessageBox.Icon.WARNING,
                    title: oI18n.getText('WARNING'),
                    actions: sap.m.MessageBox.Action.OK,
                    onClose: null,
                    styleClass: bCompact? "sapUiSizeCozy" : "",
                    initialFocus: null,
                    textDirection: sap.ui.core.TextDirection.Inherit
            };
        }
        else if(type == 'success'){
            Options = {
                    icon: sap.m.MessageBox.Icon.SUCCESS,
                    title: oI18n.getText('SUCCESS'),
                    actions: sap.m.MessageBox.Action.OK,
                    onClose: null,
                    styleClass: bCompact? "sapUiSizeCozy" : "",
                    initialFocus: null,
                    textDirection: sap.ui.core.TextDirection.Inherit
            };
        }
        sap.m.MessageBox.show(content, Options);
    },
    fCheckItems: function(){
        var sIdnrk = this.getView().byId('idnrk').getValue();
        if (sIdnrk == NULL || $.trim(sIdnrk) == EMPTY) {
            this.getView().byId('idnrk').setValueState(ERROR);
            this.getView().byId('idnrk').focus();
            return false;
        }
        var sMaktx = this.getView().byId('maktx').getValue();
        if (sMaktx == NULL || $.trim(sMaktx) == EMPTY) {
            this.getView().byId('maktx').setValueState(ERROR);
            this.getView().byId('maktx').focus();
            return false;
        }
        var sLgpro = this.getView().byId('lgpro').getValue();
        if (sLgpro == NULL || $.trim(sLgpro) == EMPTY) {
            this.getView().byId('lgpro').setValueState(ERROR);
            this.getView().byId('lgpro').focus();
            return false;
        }
        return true;
    },
    fClearMessage: function(){
        this.getView().byId('idnrk').setValueState(NONE);
        this.getView().byId('maktx').setValueState(NONE);
        this.getView().byId('lgpro').setValueState(NONE);
    },
    fRemoveValue: function(){
        this.getView().byId('idnrk').setValue(EMPTY);
        this.getView().byId('maktx').setValue(EMPTY);
        this.getView().byId('lgpro').setValue(EMPTY);
        this.getView().byId("tableid").setModel(new JSONModel([]));
    },
    fHideBusyIndicator: function(){
        var oDialog = sap.ui.getCore().byId('BusyDialog');
        if(oDialog){
            oDialog.close();
        }
    },
    fShowBusyIndicator: function(){
        var oDialog = sap.ui.getCore().byId('BusyDialog');
        if(!oDialog){
            oDialog = new BusyDialog('BusyDialog');
        }
        oDialog.open();
    },
    onNavBack: function() {
        this.fRemoveValue();
        var bUpdateModel = new JSONModel({
            bUpdate: bUpdate
        });
        this.getOwnerComponent().setModel(bUpdateModel, 'bUpdateModelppf010');
        history.go(-1);
    }
  });
});