sap.ui.define([
    'sap/ui/core/mvc/Controller',
    'sap/ui/core/routing/History',
    'sap/ui/model/json/JSONModel',
    'sap/ui/model/odata/ODataModel',
    'sap/ui/model/Filter',
    './Formatter',
    'sap/m/BusyDialog',
    'sap/ui/core/routing/Route',
    'sap/m/MessageBox',
    'sap/ui/model/FilterOperator',
    'sap/ui/core/UIComponent',
    'sap/ui/layout/VerticalLayout',
    'sap/ui/layout/form/SimpleForm'
    ],
    function(
        Controller,
        History,
        JSONModel,
        ODataModel,
        Filter,
        Formatter,
        BusyDialog,
        Route,
        MessageBox,
        FilterOperator,
        UIComponent,
        VerticalLayout,
        SimpleForm
        ) {
    'use strict';
    jQuery.sap.require("sap.ndc.BarcodeScanner");
    var EMPTY = '';
    var NULL = null;
    var ERROR = 'Error';
    var NONE = 'None';
    var oUserParaModel = null;
    var newDefaultData = {};
    var settingModel;
    var tabledata = {};
    var rowcolorid;
    var flag = false;
    var bUpdate = false;
    var workCenterData = {};
    var materialData = {};
//    var sZGTPPF010_SRV = 'proxy/http/160.21.205.176:8001/sap/opu/odata/SAP/ZGTPPF010_SRV?sap-client=331';
    var sZGTPPF010_SRV = '/nsbsp01/sap/opu/odata/SAP/ZGTPPF010_SRV';
    var sUserParaSet = '/UserParaSet';
    var sWorkCenterSet = '/WorkCenterSet';
    var sMaterialSet = '/MaterialSet';
    var sOrderHeaderSet = '/OrderHeaderSet';
    var sOrderComponentSet = '/OrderComponentSet';
    return Controller.extend('ns.bsp01.controller.Home', {
    onInit: function() {
        var oRouter = UIComponent.getRouterFor(this);
        oRouter.getRoute('appHome').attachMatched(this.fRouteMatched, this);
    },
    fRouteMatched: function(oEvent){
//        var oI18n = this.getView().getModel('i18n').getResourceBundle();
        // Get Model
        var bUpdateModel = this.getOwnerComponent().getModel('bUpdateModelppf010');
        if(bUpdateModel != NULL && bUpdateModel != EMPTY){
            var oData = bUpdateModel.getData();
            var bUpdate = this.bUpdate = oData.bUpdate;
            if(bUpdate){
                this.onSearch();
//                $('#' + rowcolorid).css("background-color","#007cc0");
            }
        }
        var that = this;
        this.fShowBusyIndicator();
        var oTimeStap = new Date();
        var oModel = new ODataModel(sZGTPPF010_SRV, true);
        oModel.read(sUserParaSet + '?' + oTimeStap, {
            async : false,
            success: function(oData){
                var values = oData.results;
                if(values.length > 0){
                    that.getView().byId('workCenter').setValue(oData.results[0].Arbpl);
                    that.getView().byId('searchBtn').setEnabled(true);
                    oUserParaModel = oData;
                    newDefaultData.werks = oData.results[0].Werks;
                    newDefaultData.lgort = oData.results[0].Lgpro;
                    newDefaultData.arbpl = oData.results[0].Arbpl;
                    var sArbpl = oData.results[0].Arbpl;
                    var sWerks = oData.results[0].Werks;
                    if (sArbpl != NULL && $.trim(sArbpl) != EMPTY && 
                                    sWerks != NULL && $.trim(sWerks) != EMPTY){
                        // MaterialSet
                        var aFilter = [];
                        // Arbpl
                        var oArbpl = new Filter({
                            path: 'Arbpl',
                            operator: FilterOperator.EQ,
                            value1: oData.results[0].Arbpl,
                            value2: ''
                        });
                        aFilter.push(oArbpl);
                        // Werks
                        var oWerks = new Filter({
                            path: 'Werks',
                            operator: FilterOperator.EQ,
                            value1: oData.results[0].Werks,
                            value2: ''
                        });
                        aFilter.push(oWerks);
                        oModel.read(sMaterialSet + '?' + oTimeStap, {
                            async : false,
                            filters: aFilter,
                            success: function(oData){
                                var values = oData.results;
                                if(values.length > 0){
                                    materialData = oData;
                                }
                                else{
                                    materialData = {};
                                }
                            },
                            error: function(){
                                materialData = {};
                                that.fShowMessageBox('error', oI18n.getText('NoData'));
                            }
                        });
                        var aFilter = [];
                        // Werks
                        var oWerks = new Filter({
                            path: 'Werks',
                            operator: FilterOperator.EQ,
                            value1: oData.results[0].Werks,
                            value2: ''
                        });
                        aFilter.push(oWerks);
                        oModel.read(sWorkCenterSet + '?' + oTimeStap, {
                            async : false,
                            filters: aFilter,
                            success: function(oData){
                                var values = oData.results;
                                if(values.length > 0){
                                    workCenterData = oData;
                                }
                                else{
                                    workCenterData = {};
                                    that.getView().byId('workCenter').setValueState(ERROR);
                                    that.getView().byId('workCenter').focus();
                                }
                                that.fHideBusyIndicator();
                            },
                            error: function(){
                                workCenterData = {};
                                that.fHideBusyIndicator();
                                that.fShowMessageBox('error',oI18n.getText('SystemError'));
                            }
                        });
                    }
                }
                else{
                    that.getView().byId('searchBtn').setEnabled(false);
                    oUserParaModel = null;
                    newDefaultData = {};
                    //that.fShowMessageBox('warning', oI18n.getText('NoData'));
                }
                that.fHideBusyIndicator();
            },
            error: function(){
                oUserParaModel = null;
                newDefaultData = {};
                that.fHideBusyIndicator();
                that.fShowMessageBox('error',oI18n.getText('SystemError'));
            }
        });
        var aTable = that.getView().byId("rawlistTable");
        aTable.addEventDelegate({
            onAfterRendering: function() {
                if(that.bUpdate && rowcolorid){
                    var allItems = aTable.getItems();
                    $('#' + rowcolorid).addClass("customBgColor");
                    $('#' + rowcolorid).css("background-color","#007cc0");
                }
            }
        }, that);
    },
    onAfterRendering: function() {
        this.fSetDate();
        this.getView().byId('moId').setEnabled(false);
        this.getView().byId('multiid').setEnabled(false);
        this.getView().byId('scanBtn').setEnabled(false);
    },
    onNavnext: function(oEvent){
//        this.fShowBusyIndicator();
        var that = this;
        var aTable = this.getView().byId("rawlistTable");
        var allItems = aTable.getItems();
        var itemsId = [];
        var rowid = that.rowid = oEvent.getParameters().id;
        var oI18n = this.getView().getModel('i18n').getResourceBundle();
        var ogoalquanty = this.getView().byId('deliveryquantiId').getValue();
        if (ogoalquanty == null || ogoalquanty == ''){
            that.fShowMessageBox('warning', oI18n.getText('quantyermsg'));
            return;
            } else {
        var oItem, oCtx, oProperty;
        oItem = oEvent.getSource();
        oCtx = oItem.getBindingContext();
        oProperty = oCtx.getProperty();
        if(oProperty.Rgekz == 'X'){
            for(var i = 0; i < allItems.length; i++){
                itemsId[i] = allItems[i].sId;
                $('#' + itemsId[i]).css("background-color","rgba(255,255,255,0.8)");
             }
            rowcolorid = rowid;
             $('#' + rowid).css("background-color","#007cc0");
            var oPropertyModel = new JSONModel(oProperty);
            this.getOwnerComponent().setModel(oPropertyModel,'navModel');
            var oRouter = UIComponent.getRouterFor(this);
            var smoId = that.getView().byId('moId').getSelectedKey();
            var oItem = that.getView().byId('moId').getSelectedItem();
            var otarquantity = this.getView().byId('targetId').getText();
            var sCeil = Math.abs(ogoalquanty/otarquantity);
            var navModel = this.getOwnerComponent().getModel('navModel');
            var navData = navModel.getData();
            var oplanQuantity = navData.MengePlan;
            var sCeil1 = Math.abs(sCeil*oplanQuantity);
            var ogoalquanty = this.getView().byId('deliveryquantiId').getValue();
            var sPath = oItem.getBindingContext().getPath();
            var oModel = that.getView().byId('moId').getModel();
            var sflag = false;
            var sMatnr = that.getView().byId('Matnr').getValue();
            var oRouter = UIComponent.getRouterFor(that);
            oRouter.navTo('detail', {
                Aufnr: smoId,
                Matnr: sMatnr,
                Ceil1: sCeil1,
                flag: sflag,
                Werks: oUserParaModel.results[0].Werks,
                Lgpro: oUserParaModel.results[0].Lgpro,
                Meins: oModel.getProperty(sPath).Meins,
                Scan: "123"
            });
        } else{
            return;
        }
            }
    },
    onSelectionChange: function(oControlEvent){
        var oI18n = this.getView().getModel('i18n').getResourceBundle();
        this.fClearMessage();
        this.getView().byId('moId').setEnabled(false);
        this.getView().byId('moId').setSelectedKey(EMPTY);
        this.getView().byId('targetId').setText(0);
        this.getView().byId('dayId').setValue("");
        this.getView().byId('delieverId').setText(0);
        this.getView().byId('multiid').setEnabled(false);
        this.getView().byId('rawlistTable').setModel(new JSONModel([]));
        this.getView().byId('scanBtn').setEnabled(false);
        // check item
        var sDatePicker = this.getView().byId('datePicker').getValue();
        var sArbpl = this.getView().byId('workCenter').getValue();
        if (sDatePicker == NULL || $.trim(sDatePicker) == EMPTY) {
            this.getView().byId('datePicker').setValueState(ERROR);
            this.getView().byId('datePicker').focus();
            return;
        }
        var sMatnr = this.getView().byId('Matnr').getValue();
        if (sMatnr == NULL || $.trim(sMatnr) == EMPTY) {
            this.getView().byId('Matnr').setValueState(ERROR);
            this.getView().byId('Matnr').focus();
            return;
        }
        this.fShowBusyIndicator();
        var that = this;
        var oModel = new ODataModel(sZGTPPF010_SRV, true);
        var aFilter = [];
        // Werks
        var sWerks = oUserParaModel.results[0].Werks;
        var oWerks = new Filter({
            path: 'Werks',
            operator: FilterOperator.EQ,
            value1: sWerks,
            value2: ''
        });
        aFilter.push(oWerks);
        // datePicker
        var oGstrp = new Filter({
            path: 'Gstrp',
            operator: FilterOperator.EQ,
            value1: sDatePicker,
            value2: ''
        });
        aFilter.push(oGstrp);
        // Matnr
        var oMatnr = new Filter({
            path: 'Matnr',
            operator: FilterOperator.EQ,
            value1: sMatnr,
            value2: ''
        });
        aFilter.push(oMatnr);
        var oArbpl = new Filter({
            path: 'Arbpl',
            operator: FilterOperator.EQ,
            value1: sArbpl,
            value2: ''
        });
        aFilter.push(oArbpl);
        var oTimeStap = new Date();
        oModel.read(sOrderHeaderSet + '?' + oTimeStap, {
            async: false,
            filters: aFilter,
            success: function(oData){
                var values = oData.results;
                if(values.length > 0){
                    that.getView().byId('moId').setEnabled(true);
                    var oJSONModel = new JSONModel(oData);
                    that.getView().byId('moId').setModel(oJSONModel);
                }
                else{
                    that.getView().byId('moId').setEnabled(false);
                    that.getView().byId('moId').setModel(new JSONModel([]));
                    that.fShowMessageBox('warning',oI18n.getText('SystemError'));
                }
                that.getView().byId('moId').setSelectedKey(EMPTY);
                that.getView().byId('targetId').setText(0);
                that.getView().byId('dayId').setValue("");
                that.getView().byId('delieverId').setText(0);
                that.fHideBusyIndicator();
            },
            error: function(){
                that.getView().byId('moId').setEnabled(false);
                that.getView().byId('moId').setModel(new JSONModel([]));
                that.getView().byId('moId').setSelectedKey(EMPTY);
                that.getView().byId('targetId').setText(0);
                that.getView().byId('dayId').setValue("");
                that.getView().byId('delieverId').setText(0);
                that.fHideBusyIndicator();
                that.fShowMessageBox('error',oI18n.getText('SystemError'));
            }
        });
    },
    onSetValue: function(oEvent){
        var oItem = oEvent.getParameters().selectedItem;
        var sPath = oItem.getBindingContext().getPath();
        var oModel = this.getView().byId('moId').getModel();
        this.getView().byId('targetId').setText(oModel.getProperty(sPath).Gamng);
        this.getView().byId('dayId').setValue(oModel.getProperty(sPath).Asttx);
        this.getView().byId('delieverId').setText(oModel.getProperty(sPath).Wemng);
    },
    onSearch: function() {
        this.fClearMessage();
        var oI18n = this.getView().getModel('i18n').getResourceBundle();
        // check item
        if(!this.fCheckItems()){
            return;
        }
        var smoId = this.getView().byId('moId').getSelectedKey();
        this.fShowBusyIndicator();
        var that = this;
        var oModel = new ODataModel(sZGTPPF010_SRV, true);
        var aFilter = [];
        // moId
        var oAufnr = new Filter({
            path: 'Aufnr',
            operator: FilterOperator.EQ,
            value1: smoId,
            value2: ''
        });
        aFilter.push(oAufnr);
        var oTimeStap = new Date();
        oModel.read(sOrderComponentSet + '?' + oTimeStap, {
            async: false,
            filters: aFilter,
            success: function(oData){
                for ( var i in oData.results) {
                    var sMengePlan = oData.results[i].MengePlan;
                    var sMenge = oData.results[i].Menge;
                    var sIdnrk = oData.results[i].Idnrk;
                    var sMaktx = oData.results[i].Maktx;
                    var sPunit = oData.results[i].Punit;
                    var sRgekz = oData.results[i].Rgekz;
                }
                var values = oData.results;
                tabledata = oData.results;
                if(values.length > 0){
                    var tarqty = that.getView().byId("targetId").getText();
                    var deliqty = that.getView().byId("delieverId").getText();
                    if(bUpdate){
                       that.ontest();
                    }
                    for ( var i in oData.results) {
                        var sMengePlan = oData.results[i].MengePlan;
                        var sUnit = oData.results[i].Punit;
                        var logqty = Math.abs(sMengePlan/tarqty * deliqty);
                        if (sUnit != "EA") {
                            logqty = logqty.toFixed(3);
                        }
                       
                        oData.results[i].LoMenge = logqty;
                        var smenge = oData.results[i].Menge-"";
                        if (smenge < logqty) {
                            oData.results[i].signal = "1";
                        } else if (smenge > logqty) {
                            oData.results[i].signal = "-1";
                        } else {
                            oData.results[i].signal = "0";
                        }
                        logqty = ""+logqty;
                    }
                    that.getView().byId('multiid').setEnabled(true);
                    var oJSONModel = new JSONModel(oData);
                    that.getView().byId('rawlistTable').setModel(oJSONModel);
                    
                    that.getView().byId('scanBtn').setEnabled(true);
                }
                else{
                    that.getView().byId('multiid').setEnabled(false);
                    that.getView().byId('rawlistTable').setModel(new JSONModel([]));
                    that.getView().byId('scanBtn').setEnabled(false);
                    that.fShowMessageBox('warning', oI18n.getText('NoData'));
                }
                that.fHideBusyIndicator();
            },
            error: function(){
                that.getView().byId('multiid').setEnabled(false);
                that.getView().byId('rawlistTable').setModel(new JSONModel([]));
                that.getView().byId('scanBtn').setEnabled(false);
                that.fHideBusyIndicator();
                that.fShowMessageBox('error',oI18n.getText('SystemError'));
            }
        });
    },
    onFilterGlobally: function(){
        var sQuery = this.getView().byId('multiid').getValue();
        var oFilter = null;
        if (sQuery){
            oFilter = new Filter([
                                  new Filter('Idnrk', FilterOperator.Contains, sQuery),
                                  new Filter('Maktx', FilterOperator.Contains, sQuery),
                                  new Filter('MengePlan', FilterOperator.Contains, sQuery),
                                  new Filter('LoMenge', FilterOperator.Contains, sQuery),
                                  new Filter('Menge', FilterOperator.Contains, sQuery),
                                  new Filter('Punit', FilterOperator.Contains, sQuery)
                                  ], false);
        }
        this.getView().byId('rawlistTable').getBinding('items').filter(oFilter, 'Application');
    },
    onScan: function(evt) {//ScanResult : "100020630,EA,600.000,4501991108,TEST,1005115919"
        var oI18n = this.getView().getModel('i18n').getResourceBundle();
        var that = this;
        // check item
        if(!this.fCheckItems()){
            return;
        }
//        var result = {};
//        result.text = "100020630,EA,2.000,4501991108,TEST,1005115919";
        if(true){
            sap.ndc.BarcodeScanner.scan(
                    function(result){

                        var values = result.text;
                        var aResult = values.split(',');
                        if(aResult.length != 6){
                            this.fShowMessageBox('error', oI18n.getText('ScanFailed'));
                            return;
                        }
                        var aTable = that.getView().byId("rawlistTable");
                        var itemsId = [];
                        var allItems = aTable.getItems();
                        var smater = aResult[0];
                        for (var i in tabledata){
                            var oRgekz = tabledata[i].Rgekz;
                            var oIdnrk = tabledata[i].Idnrk;
//                            rowcolorid = "__item14-__xmlview1--rawlistTable-" + [i];
                            if(smater == oIdnrk){
                                var flag2 = oRgekz;
                                rowcolorid = allItems[i].sId;
                                break;
                            } 
                        }
                         for(var i = 0; i < allItems.length; i++){
                                        itemsId[i] = allItems[i].sId;
                                        $('#' + itemsId[i]).css("background-color","rgba(255,255,255,0.8)");
                                     }
                                     $('#' + rowcolorid).css("background-color","#007cc0");
                        if(smater != oIdnrk){
                            that.fShowMessageBox('error', oI18n.getText('NoMaterial'));
                            return;
                        } 
                        if(flag2 == "X"){
                            that.fShowMessageBox('error', oI18n.getText('Issueintable'));
                        } else {
                        var smoId = that.getView().byId('moId').getSelectedKey();
                        var oItem = that.getView().byId('moId').getSelectedItem();
                        var sflag = true;
                        var oRouter = UIComponent.getRouterFor(this);
                        var otarquantity = "1"
                        var ogoalquanty = "2"
                        var sCeil1 = Math.abs(ogoalquanty/otarquantity);
                        var sPath = oItem.getBindingContext().getPath();
                        var oModel = that.getView().byId('moId').getModel();
                        var sMatnr = that.getView().byId('Matnr').getValue();
                        var oRouter = UIComponent.getRouterFor(that);
                        oRouter.navTo('detail', {
                            Aufnr: smoId,
                            Matnr: sMatnr,
                            Ceil1: sCeil1,
                            flag: sflag,
                            Werks: oUserParaModel.results[0].Werks,
                            Lgpro: oUserParaModel.results[0].Lgpro,
                            Meins: oModel.getProperty(sPath).Meins,
                            Scan: result.text
                        });
                        }
                          },
                    function(error){
                        that.fShowMessageBox('error', oI18n.getText('ScanFailed'));
                    }
            );
        }
        else{
            that.fShowMessageBox('error', oI18n.getText('ScanFailed'));
        }
    },
    onNavBack: function (oEvent) {
        history.go(-1);
    },
    fCheckItems: function(){
        var sDatePicker = this.getView().byId('datePicker').getValue();
        if (sDatePicker == NULL || $.trim(sDatePicker) == EMPTY) {
            this.getView().byId('datePicker').setValueState(ERROR);
            this.getView().byId('datePicker').focus();
            return false;
        }
        var sWorkCenter = this.getView().byId('workCenter').getValue();
        if(sWorkCenter == NULL || $.trim(sWorkCenter) == EMPTY){
            this.getView().byId('workCenter').setValueState(ERROR);
            this.getView().byId('workCenter').focus();
            return false;
        }
        var sMatnr = this.getView().byId('Matnr').getValue();
        if (sMatnr == NULL || $.trim(sMatnr) == EMPTY) {
            this.getView().byId('Matnr').setValueState(ERROR);
            this.getView().byId('Matnr').focus();
            return false;
        }
        var smoId = this.getView().byId('moId').getValue();
        if (smoId == NULL || $.trim(smoId) == EMPTY) {
            this.getView().byId('moId').setValueState(ERROR);
            this.getView().byId('moId').focus();
            return false;
        }
        return true;
    },
    fHideBusyIndicator: function(){
        var oDialog = sap.ui.getCore().byId('BusyDialog');
        if(oDialog){
            oDialog.close();
        }
    },
    fShowBusyIndicator: function(){
        var oDialog = sap.ui.getCore().byId('BusyDialog');
        if(!oDialog){
            oDialog = new sap.m.BusyDialog('BusyDialog');
        }
        oDialog.open();
    },
    // confirm, alert, error, information, warning, success
    fShowMessageBox: function(type, content){
        var oI18n = this.getView().getModel('i18n').getResourceBundle();
        var bCompact = !!this.getView().$().closest('.sapUiSizeCozy').length;
        var Options = NULL;
        if(type == 'error'){
            Options = {
                    icon: sap.m.MessageBox.Icon.ERROR,
                    title: oI18n.getText('ERROR'),
                    actions: sap.m.MessageBox.Action.OK,
                    onClose: null,
                    styleClass: bCompact? "sapUiSizeCozy" : "",
                    initialFocus: null,
                    textDirection: sap.ui.core.TextDirection.Inherit
            };
        }
        else if(type == 'warning'){
            Options = {
                    icon: sap.m.MessageBox.Icon.WARNING,
                    title: oI18n.getText('WARNING'),
                    actions: sap.m.MessageBox.Action.OK,
                    onClose: null,
                    styleClass: bCompact? "sapUiSizeCozy" : "",
                    initialFocus: null,
                    textDirection: sap.ui.core.TextDirection.Inherit
            };
        }
        else if(type == 'success'){
            Options = {
                    icon: sap.m.MessageBox.Icon.SUCCESS,
                    title: oI18n.getText('SUCCESS'),
                    actions: sap.m.MessageBox.Action.OK,
                    onClose: null,
                    styleClass: bCompact? "sapUiSizeCozy" : "",
                    initialFocus: null,
                    textDirection: sap.ui.core.TextDirection.Inherit
            };
        }
        sap.m.MessageBox.show(content, Options);
    },
    fSetDate: function(){
        var dDate = new Date();
        if(dDate.getHours() < 8){
            dDate.setDate(dDate.getDate() - 1);
            this.getView().byId('datePicker').setDateValue(dDate);
        }
        else{
            this.getView().byId('datePicker').setDateValue(dDate);
        }
    },
    fClearMessage: function(){
        this.getView().byId('datePicker').setValueState(NONE);
        this.getView().byId('workCenter').setValueState(NONE);
        this.getView().byId('Matnr').setValueState(NONE);
        this.getView().byId('moId').setValueState(NONE);
    },
    onClear: function(){
        this.fClearMessage();
        this.fSetDate();
        this.getView().byId('workCenter').setValue(oUserParaModel.results[0].Arbpl);
        this.getView().byId('Matnr').setValue(EMPTY);
        this.getView().byId('deliveryquantiId').setValue(EMPTY);
        this.getView().byId('moId').setEnabled(false);
        this.getView().byId('moId').setSelectedKey(EMPTY);
        this.getView().byId('targetId').setText(0);
        this.getView().byId('dayId').setValue("");
        this.getView().byId('delieverId').setText(0);
        this.getView().byId('multiid').setEnabled(false);
        this.getView().byId("rawlistTable").setModel(new JSONModel([]));
        this.getView().byId('scanBtn').setEnabled(false);
    },
    onSetting : function() {
        var oI18n = this.getView().getModel('i18n').getResourceBundle();
        var that = this;
        if (!that._settingDialog) {
            settingModel = {
                            werks : newDefaultData.werks,
                            lgort : newDefaultData.lgort,
                            arbpl : newDefaultData.arbpl
            }
            sap.ui.getCore().setModel(new JSONModel(settingModel), "settingData")
            that._settingDialog = new sap.m.Dialog({
                title : oI18n.getText("Picking.defaultTitle"),
                icon : "sap-icon://employee",
                state : 'Success',
                content : [
                    new SimpleForm({
                content : [ new VerticalLayout({
                    width : '350px',
                    content : [ 
                        new sap.m.Label({
                                    text : oI18n.getText("Picking.Plant"),
                                    required : true
                        }), 
                        new sap.m.Input("plant", {
                                    value : "{settingData>/werks}",
                                    valueLiveUpdate : true,
                                    maxLength : 4
                        }),
                        new sap.m.Label({
                            text : oI18n.getText("Picking.Storaloc"),
                            required : true
                        }), 
                        new sap.m.Input("storage", {
                            value : "{settingData>/lgort}",
                            valueLiveUpdate : true,
                            maxLength : 4
                        }),
                        new sap.m.Label({
                            text : oI18n.getText("workCenter"),
                            required : true
                        }), 
                        new sap.m.Input("center", {
                            value : "{settingData>/arbpl}",
                            valueLiveUpdate : true,
                            maxLength : 8
                        })
                    ]
                        }) ]
                }) ]
            });
            that._settingDialog.addButton(new sap.m.Button({
                            text : oI18n.getText("Picking.save"),
                            type : "Accept",
                            icon : "sap-icon://save",
                            press : function() {
                                if (!that.emptyCheckSet()) {
                                    return;
                                } else {
                                    settingModel.werks = sap.ui.getCore().byId('plant').getValue();
                                    settingModel.lgort = sap.ui.getCore().byId('storage').getValue();
                                    settingModel.arbpl = sap.ui.getCore().byId('center').getValue();
                                    sap.ui.getCore().setModel(new JSONModel(settingModel),
                                                    "settingData");
                                    var oTimeStap = new Date();
                                    // OData
                                    var oData = {};
                                    oData.Werks = sap.ui.getCore().byId('plant').getValue();
                                    oData.Lgpro = sap.ui.getCore().byId('storage').getValue();
                                    oData.Arbpl = sap.ui.getCore().byId('center').getValue();
                                    var oModel = new ODataModel(sZGTPPF010_SRV, true);
                                    // create
                                    oModel.create(sUserParaSet + '?' + oTimeStap, oData, {
                                                    success : function(oResult, oResponse) {
                                                        if (oResult.Type == "E") {
                                                            that.fShowMessageBox('error', oResult.Message);
                                                        } else {
                                                            that._settingDialog.close();
                                                            that.fRouteMatched();
                                                        }
                                                    },
                                                    error : function(oError) {
                                                        that.fShowMessageBox('error', oError.Message);
                                                    }
                                    });
                                }
                            }
            }));
            that._settingDialog.insertButton(new sap.m.Button({
                            text : oI18n.getText("Picking.cancelBtn"),
                            press : function() {
                                that._settingDialog.close();
                            }
            }));
        }
        that._settingDialog.open();
    },
    emptyCheckSet : function() {
        var owerks = sap.ui.getCore().byId('plant');
        var olgort = sap.ui.getCore().byId("storage");
        var oarbpl = sap.ui.getCore().byId("center");
        owerks.setValueState("None");
        olgort.setValueState("None");
        oarbpl.setValueState("None")
        var swerks = owerks.getValue();
        var slgort = olgort.getValue();
        var sarbpl = oarbpl.getValue();
        if (swerks == null || swerks == '') {
            owerks.setValueState("Error");
            owerks.focus();
            return false;
        } else if (slgort == null || slgort == '') {
            olgort.setValueState("Error");
            olgort.focus();
            return false;
        } else if (sarbpl == null || sarbpl == '') {
            oarbpl.setValueState("Error");
            oarbpl.focus();
            return false;
        }
        return true;
    },
    handleValueHelp: function (oEvent) {
        var sInputValue = oEvent.getSource().getValue();
        this.inputId = oEvent.getSource().getId();
        // create value help dialog
        if (!this._valueHelpDialog) {
           this._valueHelpDialog = sap.ui.xmlfragment("ns.bsp01.view.Dialog",this);
            this.getView().addDependent(this._valueHelpDialog);
        }
        this._valueHelpDialog.setModel(new JSONModel(workCenterData));
        // create a filter for the binding
        this._valueHelpDialog.getBinding("items").filter([new Filter( "Arbpl",  sap.ui.model.FilterOperator.Contains, sInputValue )]);
        // open value help dialog filtered by the input value
        this._valueHelpDialog.open(sInputValue);
    },
    handleValueHelp1: function (oEvent) {
        var sInputValue = oEvent.getSource().getValue();
        this.inputId = oEvent.getSource().getId();
        // create value help dialog
        if (!this._valueHelpDialog1) {
           this._valueHelpDialog1 = sap.ui.xmlfragment("ns.bsp01.view.MaterialDialog",this);
            this.getView().addDependent(this._valueHelpDialog1);
        }
        this._valueHelpDialog1.setModel(new JSONModel(materialData));
        // create a filter for the binding
        this._valueHelpDialog1.getBinding("items").filter([new Filter( "Matnr",  sap.ui.model.FilterOperator.Contains, sInputValue )]);
        // open value help dialog filtered by the input value
        this._valueHelpDialog1.open(sInputValue);
    },
    _handleValueHelpSearch: function (evt) {
        var sValue = evt.getParameter("value");
        var oFilter = new Filter( "Arbpl", sap.ui.model.FilterOperator.Contains, sValue);
        evt.getSource().getBinding("items").filter([oFilter]);
    },
    _handleValueHelpSearch1: function (evt) {
        var sValue = evt.getParameter("value");
        var oFilter = new Filter( "Matnr", sap.ui.model.FilterOperator.Contains, sValue);
        evt.getSource().getBinding("items").filter([oFilter]);
    },
    _handleValueHelpClose: function (evt) {
        var oSelectedItem = evt.getParameter("selectedItem");
        if (oSelectedItem) {
            var productInput = this.getView().byId(this.inputId);
            productInput.setValue(oSelectedItem.getTitle());
            $("#V1").html(oSelectedItem.getTitle());
        }
        evt.getSource().getBinding("items").filter([]);
        var oSelectedContexts = evt.getParameters().selectedContexts;
        if(oSelectedContexts != NULL && $.trim(oSelectedContexts) != EMPTY){
            this.getView().byId('Matnr').setValue(EMPTY);
            this.getView().byId('moId').setEnabled(false);
            this.getView().byId('moId').setSelectedKey(EMPTY);
            this.getView().byId('targetId').setText(0);
            this.getView().byId('dayId').setValue("");
            this.getView().byId('delieverId').setText(0);
            this.getView().byId('multiid').setEnabled(false);
            this.getView().byId('rawlistTable').setModel(new JSONModel([]));
            this.getView().byId('scanBtn').setEnabled(false);
            var sPath = oSelectedContexts[0].getPath();
            var oModel = oSelectedContexts[0].getModel();
            var sValue = oModel.getProperty(sPath).Arbpl;
            // MaterialSet
            var that = this;
            var aFilter = [];
            // Arbpl
            var oArbpl = new Filter({
                path: 'Arbpl',
                operator: FilterOperator.EQ,
                value1: sValue,
                value2: ''
            });
            aFilter.push(oArbpl);
            // Werks
            var oWerks = new Filter({
                path: 'Werks',
                operator: FilterOperator.EQ,
                value1: oUserParaModel.results[0].Werks,
                value2: ''
            });
            aFilter.push(oWerks);
            this.fShowBusyIndicator();
            var oTimeStap = new Date();
            var oModel = new ODataModel(sZGTPPF010_SRV, true);
            oModel.read(sMaterialSet + '?' + oTimeStap, {
                async : false,
                filters: aFilter,
                success: function(oData){
                    var values = oData.results;
                    if(values.length > 0){
                        materialData = oData;
                    }
                    else{
                        materialData = {};
                        that.getView().byId('moId').setEnabled(false);
                        that.getView().byId('moId').setModel(new JSONModel([]));
                    }
                    that.fHideBusyIndicator();
                },
                error: function(){
                    that.fHideBusyIndicator();
                    materialData = {};
                    that.getView().byId('moId').setEnabled(false);
                    that.getView().byId('moId').setModel(new JSONModel([]));
                    that.fShowMessageBox('error', oI18n.getText('SystemError'));
                }
            });
        }
    },
    _handleValueHelpClose1: function (evt) {
        var oSelectedItem = evt.getParameter("selectedItem");
        if (oSelectedItem) {
            var productInput = this.getView().byId(this.inputId);
            productInput.setValue(oSelectedItem.getTitle());
            $("#V1").html(oSelectedItem.getTitle());
        }
        evt.getSource().getBinding("items").filter([]);
        var oSelectedContexts = evt.getParameters().selectedContexts;
        if(oSelectedContexts != NULL && $.trim(oSelectedContexts) != EMPTY){
            var sPath = oSelectedContexts[0].getPath();
            var oModel = oSelectedContexts[0].getModel();
            var sValue = oModel.getProperty(sPath).Matnr;
            // OrderHeaderSet
            var oI18n = this.getView().getModel('i18n').getResourceBundle();
            this.fClearMessage();
            this.getView().byId('moId').setEnabled(false);
            this.getView().byId('moId').setSelectedKey(EMPTY);
            this.getView().byId('targetId').setText(0);
            this.getView().byId('dayId').setValue("");
            this.getView().byId('delieverId').setText(0);
            this.getView().byId('multiid').setEnabled(false);
            this.getView().byId('rawlistTable').setModel(new JSONModel([]));
            this.getView().byId('scanBtn').setEnabled(false);
            // check item
            var sDatePicker = this.getView().byId('datePicker').getValue();
            var sArbpl = this.getView().byId('workCenter').getValue();
            if (sDatePicker == NULL || $.trim(sDatePicker) == EMPTY) {
                this.getView().byId('datePicker').setValueState(ERROR);
                this.getView().byId('datePicker').focus();
                return;
            }
            var sMatnr = sValue;
            if (sMatnr == NULL || $.trim(sMatnr) == EMPTY) {
                this.getView().byId('Matnr').setValueState(ERROR);
                this.getView().byId('Matnr').focus();
                return;
            }
            this.fShowBusyIndicator();
            var that = this;
            var oModel = new ODataModel(sZGTPPF010_SRV, true);
            var aFilter = [];
            // Werks
            var sWerks = oUserParaModel.results[0].Werks;
            var oWerks = new Filter({
                path: 'Werks',
                operator: FilterOperator.EQ,
                value1: sWerks,
                value2: ''
            });
            aFilter.push(oWerks);
            // datePicker
            var oGstrp = new Filter({
                path: 'Gstrp',
                operator: FilterOperator.EQ,
                value1: sDatePicker,
                value2: ''
            });
            aFilter.push(oGstrp);
            // Matnr
            var oMatnr = new Filter({
                path: 'Matnr',
                operator: FilterOperator.EQ,
                value1: sMatnr,
                value2: ''
            });
            aFilter.push(oMatnr);
            var oArbpl = new Filter({
                path: 'Arbpl',
                operator: FilterOperator.EQ,
                value1: sArbpl,
                value2: ''
            });
            aFilter.push(oArbpl);
            var oTimeStap = new Date();
            oModel.read(sOrderHeaderSet + '?' + oTimeStap, {
                async: false,
                filters: aFilter,
                success: function(oData){
                    var values = oData.results;
                    if(values.length > 0){
                        that.getView().byId('moId').setEnabled(true);
                        var oJSONModel = new JSONModel(oData);
                        that.getView().byId('moId').setModel(oJSONModel);
                    }
                    else{
                        that.getView().byId('moId').setEnabled(false);
                        that.getView().byId('moId').setModel(new JSONModel([]));
                        that.getView().byId('moId').setValueState(ERROR);
                        that.getView().byId('moId').focus();
                        that.fShowMessageBox('warning', oI18n.getText('NoData'));
                    }
                    that.getView().byId('moId').setSelectedKey(EMPTY);
                    that.getView().byId('targetId').setText(0);
                    that.getView().byId('dayId').setValue("");
                    that.getView().byId('delieverId').setText(0);
                    that.fHideBusyIndicator();
                },
                error: function(){
                    that.getView().byId('moId').setEnabled(false);
                    that.getView().byId('moId').setModel(new JSONModel([]));
                    that.getView().byId('moId').setSelectedKey(EMPTY);
                    that.getView().byId('targetId').setText(0);
                    that.getView().byId('dayId').setValue("");
                    that.getView().byId('delieverId').setText(0);
                    that.fHideBusyIndicator();
                    that.fShowMessageBox('error', oI18n.getText('SystemError'));
                }
            });
        }
    }
  });
});