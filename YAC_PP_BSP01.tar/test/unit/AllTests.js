sap.ui.define([
	"ns/bsp01/test/unit/controller/App.controller"
], function () {
	"use strict";
});
