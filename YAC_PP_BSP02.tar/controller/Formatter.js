sap.ui.define(function() {
    "use strict";

    var Formatter = {

        status : function(sStatus) {
            if (sStatus === 'F' || sStatus === '') {
                return 'Navigation';
            } else {
                return 'Inactive';
            }
        },
        valueState: function(sValueState){
            if (sValueState === 'F' || sValueState === '') {
                return 'Success';
            } else {
                return 'Error';
            }
        },
        valueColor: function(FlgShort){
            if (FlgShort === 'X') {
                return 'Error';
            } else {}
        }
    };

    return Formatter;

}, /* bExport= */true);