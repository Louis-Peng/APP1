sap.ui.define([
    'ns/bsp02/controller/App.controller',
    'sap/ui/model/json/JSONModel',
    'sap/ui/model/odata/ODataModel',
    'sap/ui/core/routing/History',
    'sap/ui/core/routing/Route',
    'sap/m/MessageBox',
    'sap/ui/model/Filter',
    'sap/ui/model/FilterOperator',
    'sap/ui/core/UIComponent',
    './Formatter',
    "sap/ui/layout/form/SimpleForm",
    "sap/ui/layout/VerticalLayout"

    ], function(
            Controller,
            JSONModel,
            ODataModel,
            History,
            Route,
            MessageBox,
            Filter,
            FilterOperator,
            UIComponent,
            Formatter,
            SimpleForm,
            VerticalLayout) {
    'use strict';
    var EMPTY = '';
    var NULL = null;
    var ERROR = 'Error';
    var NONE = 'None';
    var centerData;
    var materialData;
    var Material = {};
    var Supervisor = {};
    var Rounding = {};
    var searchData = {};
    var SAPBATCH = {};
    var fistpagefilter = {};
    //var sZGTPPF020_SRV = 'proxy/http/160.21.205.176:8001/sap/opu/odata/SAP/ZGTPPF020_SRV?sap-client=331';
    // /sap/opu/odata/SAP/ZGTPPF020_SRV
    var sZGTPPF020_SRV = '/nsbsp02/sap/opu/odata/SAP/ZGTPPF020_SRV';
    var oModel = new ODataModel(sZGTPPF020_SRV,true);
    var sProductionOrderSet = '/ProductionOrderSet';
    return Controller.extend('ns.bsp02.controller.MOConfirmHome', {
        onInit: function() {
            var oRouter = UIComponent.getRouterFor(this);
            oRouter.getRoute('moconfirmhome').attachMatched(this.fRouteMatched, this);
        },
        onAfterRendering: function() {
            this.fSetDate();
            this.getView().byId('searchField').setEnabled(false);
            this.getView().byId('setBtn').setType("Emphasized");
        },
        fRouteMatched: function(oEvent){
           var that = this;
           oModel.read("/UserParaSet/",{
               async : false,
               success: function(oData){
                   if(oData.results[0].Type == "E"){
                       return;
                   }else{
                       searchData.Werks = oData.results[0].Werks;//plant
                       searchData.Arbpl = oData.results[0].Arbpl;//work center
                       searchData.Name = oData.results[0].Name;//work center
                       searchData.Matnr = that.getView().byId("materialid").getValue();
                       searchData.Wempf = that.getView().byId("productionLine").getValue();
                       searchData.Gstrp = that.byId("datePicker").getDateValue();
                       //that.getView().byId("datePicker").getValue();
                       that.getView().byId("filterid").setModel(new JSONModel(searchData),"searchData");
                       var aFilter = [];
                       aFilter[0] = new sap.ui.model.Filter({
                           path : "Werks",
                           operator : sap.ui.model.FilterOperator.EQ,
                           value1 : searchData.Werks,
                           value2 : ""
                       });
                       oModel.read("/WorkCenterSet/",{
                           async : false,
                           filters : aFilter,
                           success: function(oData){
                               centerData = oData;
                           },
                           error: function(oError){
                               that.fShowMessageBox('error', oError.message);
                           }
                       });
                       var mFilter = [];
                       mFilter[0] = new sap.ui.model.Filter({
                           path : "Werks",
                           operator : sap.ui.model.FilterOperator.EQ,
                           value1 : searchData.Werks,
                           value2 : ""
                       });
                       mFilter[1] = new sap.ui.model.Filter({
                           path : "Arbpl",
                           operator : sap.ui.model.FilterOperator.EQ,
                           value1 : searchData.Arbpl,
                           value2 : ""
                       });
                       oModel.read("/MaterialSet/",{
                           async : false,
                           filters : mFilter,
                           success: function(oData){
                               materialData = oData;
                               that.getView().byId("materialid").setModel(new JSONModel(materialData));
                           },
                           error: function(oError){
                               that.fShowMessageBox('error', oError.message);
                           }
                       });
                   }
               },
               error: function(oError){
                   that.fShowMessageBox('error', oError.message);
               }
           });
           var refreshFlagModel = this.getOwnerComponent().getModel('refreshFlag');
           if(refreshFlagModel == undefined){

           }else{
               if(refreshFlagModel.getData().refreshFlag == true){
                   var homeFilterModel = this.getOwnerComponent().getModel('homeFilter');
                   var homeFilter = homeFilterModel.getData();
                   fistpagefilter = homeFilter;
                   var hFilter = [];
                   hFilter[0] = new Filter({
                       path: 'Gstrp',//Date
                       operator: FilterOperator.EQ,
                       value1: homeFilter.Gstrp,
                       value2: ''
                   });
                   hFilter[1] = new Filter({
                       path: 'Matnr',//material
                       operator: FilterOperator.EQ,
                       value1: homeFilter.Matnr,
                       value2: ''
                   });
                   hFilter[2] = new Filter({
                       path: 'Wempf',//production line
                       operator: FilterOperator.Contains,
                       value1: homeFilter.Wempf,
                       value2: ''
                   });
                   hFilter[3] = new Filter({
                       path: 'Werks',//plant
                       operator: FilterOperator.EQ,
                       value1: homeFilter.Werks,
                       value2: ''
                   });
                   hFilter[4] = new Filter({
                       path: 'Show',//state
                       operator: FilterOperator.EQ,
                       value1: homeFilter.Show,
                       value2: ''
                   });
                   /*hFilter[5] = new Filter({
                       path: 'Arbpl',//Work Center
                       operator: FilterOperator.EQ,
                       value1: homeFilter.Arbpl,
                       value2: ''
                   });*/
                   var oTimeStap = new Date();
                   //  + '?' + oTimeStap
                   oModel.read(sProductionOrderSet, {
                       async: false,
                       filters: hFilter,
                       success: function(oData){
                           var values = oData.results;
                           that.getView().byId('searchField').setEnabled(true);
                           var oJSONModel = new JSONModel(oData);
                           that.getView().byId('table').setModel(oJSONModel);
                           that.getView().byId('materialid').setValue(fistpagefilter.Matnr);
                           that.getView().byId('productionLine').setValue(fistpagefilter.Wempf);
                       },
                       error: function(){
                           that.fShowMessageBox('error', 'System Error.');
                       }
                   });
               }
           }

        },
        getMaterial: function(){
            var that = this;
            var sWorkcenter = that.getView().byId("workcenterid").getValue();
            var length = sWorkcenter.length;
            if(length == 8){
                that.getView().byId("materialid").setValue("");
                var mFilter = [];
                 mFilter[0] = new sap.ui.model.Filter({
                     path : "Werks",
                     operator : sap.ui.model.FilterOperator.EQ,
                     value1 : searchData.Werks,
                     value2 : ""
                 });
                 mFilter[1] = new sap.ui.model.Filter({
                     path : "Arbpl",
                     operator : sap.ui.model.FilterOperator.EQ,
                     value1 : searchData.Arbpl,
                     value2 : ""
                 });
                 oModel.read("/MaterialSet/",{
                     async : false,
                     filters : mFilter,
                     success: function(oData){
                         materialData = oData;
                         that.getView().byId("materialid").setModel(new JSONModel(materialData));
                     },
                     error: function(oError){
                         that.fShowMessageBox('error', oError.message);
                     }
                 });
            }else{
                that.getView().byId("materialid").setModel(new JSONModel());
            }
        },
        handleValueHelp: function (oEvent) {
            var sInputValue = oEvent.getSource().getValue();
            this.inputId = oEvent.getSource().getId();
            // create value help dialog
            if (!this._valueHelpDialog) {
                this._valueHelpDialog = sap.ui.xmlfragment("ns.bsp02.view.CenterDialog",this);
                this.getView().addDependent(this._valueHelpDialog);
            }
            //setModel for dialog
            this._valueHelpDialog.setModel(new JSONModel(centerData));
            // create a filter for the binding
            this._valueHelpDialog.getBinding("items").filter([new Filter( "Arbpl",  sap.ui.model.FilterOperator.Contains, sInputValue )]);
            // open value help dialog filtered by the input value
            this._valueHelpDialog.open(sInputValue);
        },
        _handleValueHelpSearch: function (evt) {
            var sValue = evt.getParameter("value");
            var oFilter = new Filter( "Arbpl", sap.ui.model.FilterOperator.Contains, sValue);
            evt.getSource().getBinding("items").filter([oFilter]);
        },
        _handleValueHelpClose: function (evt) {
            var that = this;
            var oSelectedItem = evt.getParameter("selectedItem");
            if (oSelectedItem) {
                var productInput = this.getView().byId(this.inputId);
                productInput.setValue(oSelectedItem.getTitle());
                that.getMaterial();
                $("#V1").html(oSelectedItem.getTitle());
            }
            evt.getSource().getBinding("items").filter([]);
        },
        materialhandleValueHelp: function (oEvent) {
            var sInputValue = oEvent.getSource().getValue();
            this.inputId = oEvent.getSource().getId();
            // create value help dialog
            if (!this._materialvalueHelpDialog) {
                this._materialvalueHelpDialog = sap.ui.xmlfragment("ns.bsp02.view.MaterialDialog",this);
                this.getView().addDependent(this._materialvalueHelpDialog);
            }
            //setModel for dialog
            this._materialvalueHelpDialog.setModel(new JSONModel(materialData));
            // create a filter for the binding
            this._materialvalueHelpDialog.getBinding("items").filter([new Filter( "Matnr",  sap.ui.model.FilterOperator.Contains, sInputValue )]);
            // open value help dialog filtered by the input value
            this._materialvalueHelpDialog.open(sInputValue);
        },

        _materialhandleValueHelpSearch: function (evt) {
            var sValue = evt.getParameter("value");
            var oFilter = new Filter( "Matnr", sap.ui.model.FilterOperator.Contains, sValue);
            evt.getSource().getBinding("items").filter([oFilter]);
        },
        _materialhandleValueHelpClose: function (evt) {
            var that = this;
            var oSelectedItem = evt.getParameter("selectedItem");
            if (oSelectedItem) {
                var productInput = this.getView().byId(this.inputId);
                productInput.setValue(oSelectedItem.getTitle());
                $("#V1").html(oSelectedItem.getTitle());
            }
            evt.getSource().getBinding("items").filter([]);
        },
        fSetDate: function(){
            var dDate = new Date();
            if(dDate.getHours() < 8){
                dDate.setDate(dDate.getDate() - 1);
                this.getView().byId('datePicker').setDateValue(dDate);
            }
            else{
                this.getView().byId('datePicker').setDateValue(dDate);
            }
        },
        onNavBack: function(oEvent) {
            if(sap.ui.getCore().byId('settingplantid')){
                sap.ui.getCore().byId('settingplantid').destroy();
                 sap.ui.getCore().byId('settingworkcenterid').destroy();
                 sap.ui.getCore().byId('settingNameid').destroy();
            }
            history.go(-1);
        },
        emptyCheckSave: function(){
            this.fClearMessage();
            var sPostingDate = this.getView().byId('datePicker').getValue();
            if (sPostingDate == null || sPostingDate == '') {
                this.getView().byId('postingDate').setValueState("Error");
                this.getView().byId('postingDate').focus();
                return false;
            }
            var sworkcenterid = this.getView().byId('workcenterid').getValue();
            if (sworkcenterid == null || sworkcenterid == '') {
                this.getView().byId('workcenterid').setValueState("Error");
                this.getView().byId('workcenterid').focus();
                return false;
            }
            var smaterialid = this.getView().byId('materialid').getValue();
            if (smaterialid == null || smaterialid == '') {
                this.getView().byId('materialid').setValueState("Error");
                this.getView().byId('materialid').focus();
                return false;
            }
            return true;
        },
        onSearch: function() {
            this.fClearMessage();
            if(!this.emptyCheckSave()){
                return;
            }
            var oI18n = this.getView().getModel('i18n').getResourceBundle();
            searchData.Gstrp = this.getView().byId("datePicker").getValue();
            var scenter = this.getView().byId('workcenterid').getValue();
            var state = this.getView().byId("status").getState();
            if(state){
                searchData.Show = "X";
            }else {
                searchData.Show = "";
            }
            this.fShowBusyIndicator();
            var that = this;
            var oTimeStap = new Date();
            var oModel = new ODataModel(sZGTPPF020_SRV, true);
            var aFilter = [];
            aFilter[0] = new Filter({
                path: 'Gstrp',//Date
                operator: FilterOperator.EQ,
                value1: searchData.Gstrp,
                value2: ''
            });
            aFilter[1] = new Filter({
                path: 'Matnr',//material
                operator: FilterOperator.EQ,
                value1: searchData.Matnr,
                value2: ''
            });
            aFilter[2] = new Filter({
                path: 'Wempf',//production line
                operator: FilterOperator.Contains,
                value1: searchData.Wempf,
                value2: ''
            });
            aFilter[3] = new Filter({
                path: 'Werks',//plant
                operator: FilterOperator.EQ,
                value1: searchData.Werks,
                value2: ''
            });
            aFilter[4] = new Filter({
                path: 'Show',//state
                operator: FilterOperator.EQ,
                value1: searchData.Show,
                value2: ''
            });
            aFilter[5] = new Filter({
                path: 'Arbpl',//Work Center
                operator: FilterOperator.EQ,
                value1: scenter,
                value2: ''
            });
            oModel.read(sProductionOrderSet + '?' + oTimeStap, {
                async: false,
                filters: aFilter,
                success: function(oData){
                    var values = oData.results;
                    that.fHideBusyIndicator();
                    if(values.length > 0){
                        that.getView().byId('searchField').setEnabled(true);
                        var oJSONModel = new JSONModel(oData);

                        that.getView().byId('table').setModel(oJSONModel);
                    }
                    else{
                        that.getView().byId('searchField').setEnabled(false);
                        that.getView().byId('table').setModel(new JSONModel([]));
                        that.fShowMessageBox('error', oI18n.getText('ZGTPPF020.NoData'));
                    }
                },
                error: function(){
                    that.fHideBusyIndicator();
                    that.fShowMessageBox('error', 'System Error.');
                }
            });
        },
        onFilterGlobally: function(){
            var sQuery = this.getView().byId('searchField').getValue();
            var oFilter = null;
            if (sQuery){
                oFilter = new Filter([
                                      new Filter('Ddtext', FilterOperator.Contains, sQuery),
                                      new Filter('Aufnr', FilterOperator.Contains, sQuery),
                                      new Filter('Maktx', FilterOperator.Contains, sQuery),
                                      new Filter('Gamng', FilterOperator.Contains, sQuery),
                                      new Filter('Gmnga', FilterOperator.Contains, sQuery),
                                      new Filter('Ztime1', FilterOperator.Contains, sQuery),
                                      new Filter('Iasmg', FilterOperator.Contains, sQuery),
                                      new Filter('Obcha', FilterOperator.Contains, sQuery)
                                      ], false);
            }
            this.getView().byId('table').getBinding('items').filter(oFilter, 'Application');
        },
        onSelectionChange: function(oEvent){
            var oTable = this.getView().byId('table');
            var sPath = oEvent.getSource().getBindingContext().getPath();
            var oModel = oTable.getModel();
            var sValue = oModel.getProperty(sPath).Cnfst;
            if(sValue == 'F' || $.trim(sValue) == EMPTY){
                var _MOConfirmHomeModel = new JSONModel({
                    Gamng: oModel.getProperty(sPath).Gamng,
                    Gmnga: oModel.getProperty(sPath).Gmnga
                });
                this.getOwnerComponent().setModel(_MOConfirmHomeModel, 'MOConfirmHomeModel');

                SAPBATCH.Batch = oModel.getProperty(sPath).Obcha;
                this.getOwnerComponent().setModel(new JSONModel(SAPBATCH), 'SAPBATCHModel');
                Rounding.Bstrf = oModel.getProperty(sPath).Bstrf;
                this.getOwnerComponent().setModel(new JSONModel(Rounding), 'RoundingModel');
                Supervisor.Super = oModel.getProperty(sPath).Supervisor;
                this.getOwnerComponent().setModel(new JSONModel(Supervisor), 'SupervisorModel');
                var homeFilter = {};
                homeFilter.Gstrp = searchData.Gstrp;
                homeFilter.Matnr = searchData.Matnr;
                homeFilter.Wempf = searchData.Wempf;
                homeFilter.Werks = searchData.Werks;
                homeFilter.Show = searchData.Show;
                homeFilter.Arbpl = searchData.Arbpl;
                this.getOwnerComponent().setModel(new JSONModel(homeFilter), 'homeFilter');
                var oRouter = UIComponent.getRouterFor(this);
                oRouter.navTo('moconfirm', {Aufnr: oModel.getProperty(sPath).Aufnr});
            }
        },
        // confirm, alert, error, information, warning, success
        fShowMessageBox: function(type, content){
            var oI18n = this.getView().getModel('i18n').getResourceBundle();
            var bCompact = !!this.getView().$().closest('.sapUiSizeCozy').length;
            var Options = NULL;
            if(type == 'error'){
                Options = {
                        icon: sap.m.MessageBox.Icon.ERROR,
                        title: oI18n.getText('ZGTPPF020.ERROR'),
                        actions: sap.m.MessageBox.Action.OK,
                        onClose: null,
                        styleClass: bCompact? 'sapUiSizeCozy' : '',
                        initialFocus: null,
                        textDirection: sap.ui.core.TextDirection.Inherit
                };
            }
            else if(type == 'warning'){
                Options = {
                        icon: sap.m.MessageBox.Icon.WARNING,
                        title: oI18n.getText('ZGTPPF020.WARNING'),
                        actions: sap.m.MessageBox.Action.OK,
                        onClose: null,
                        styleClass: bCompact? 'sapUiSizeCozy' : '',
                        initialFocus: null,
                        textDirection: sap.ui.core.TextDirection.Inherit
                };
            }
            else if(type == 'success'){
                Options = {
                        icon: sap.m.MessageBox.Icon.SUCCESS,
                        title: oI18n.getText('ZGTPPF020.SUCCESS'),
                        actions: sap.m.MessageBox.Action.OK,
                        onClose: null,
                        styleClass: bCompact? 'sapUiSizeCozy' : '',
                        initialFocus: null,
                        textDirection: sap.ui.core.TextDirection.Inherit
                };
            }
            sap.m.MessageBox.show(content, Options);
        },
        fHideBusyIndicator: function(){
            var oDialog = sap.ui.getCore().byId('BusyDialog');
            if(oDialog){
                oDialog.close();
            }
        },
        fShowBusyIndicator: function(){
            var oDialog = sap.ui.getCore().byId('BusyDialog');
            if(!oDialog){
                oDialog = new sap.m.BusyDialog('BusyDialog');
            }
            oDialog.open();
        },
        fClearMessage: function(){
            this.getView().byId('datePicker').setValueState(NONE);
            this.getView().byId('workcenterid').setValueState(NONE);
            this.getView().byId('materialid').setValueState(NONE);
        },
        onClear: function(){
            this.fClearMessage();
            this.fSetDate();
            this.fRouteMatched();
            this.getView().byId('table').setModel(new JSONModel());
        },
        onSetting: function(){//TODO
            var oI18n = this.getView().getModel('i18n').getResourceBundle();
            var that = this;
            if(!that._settingDialog){
                //Werks//plant
                //work//center
                sap.ui.getCore().setModel(new JSONModel(searchData),"settingData")
                that._settingDialog = new sap.m.Dialog({
                    title: oI18n.getText("ZGTPPF020.defaultTitle"),
                    icon: "sap-icon://employee",
                    state: 'Success',
                    content: [new SimpleForm({
                        content:[
                                      new sap.m.Label({text : oI18n.getText("ZGTPPF020.plantid"),required:true}),
                                      new sap.m.Input("settingplantid",{value : "{settingData>/Werks}",
                                          valueLiveUpdate:true,maxLength:4}),
                                       new sap.m.Label({text : oI18n.getText("ZGTPPF020.workcenterid"),required:true}),
                                       new sap.m.Input("settingworkcenterid",{value : "{settingData>/Arbpl}",
                                           valueLiveUpdate:true,maxLength:8}),
                                       new sap.m.Label({text : oI18n.getText("ZGTPPF020.Nameid"),required:true}),
                                      new sap.m.Input("settingNameid",{value : "{settingData>/Name}",
                                          valueLiveUpdate:true,maxLength:100})
                                 ]
                            })]
                      });
                that._settingDialog.addButton(new sap.m.Button({
                    text: oI18n.getText("ZGTPPF020.save"),
                    type: "Accept",
                    icon: "sap-icon://save",
                    press: function() {
                        if(!that.emptyCheckSet()){
                            return;
                        }else{
                            searchData.Werks= sap.ui.getCore().byId('settingplantid').getValue();
                            searchData.Arbpl= sap.ui.getCore().byId('settingworkcenterid').getValue();
                            searchData.Name= sap.ui.getCore().byId('settingNameid').getValue();
                            sap.ui.getCore().setModel(new JSONModel(searchData),"settingData");
                            var oTimeStap = new Date();
                            var oData = {};
                            oData.Werks= sap.ui.getCore().byId('settingplantid').getValue();
                            oData.Arbpl= sap.ui.getCore().byId('settingworkcenterid').getValue();
                            oData.Name= sap.ui.getCore().byId('settingNameid').getValue();
                            oModel.create("/UserParaSet/" + '?' + oTimeStap , oData,{
                                  success: function(oResult, oResponse){
                                      if(oResult.msgty == "E"){
                                          that.fShowMessageBox('error', oResult.msg);
                                      }else {
                                          that.fRouteMatched();
                                          that.onAfterRendering();
                                      }
                                },
                                error: function(oError){
                                        that.fShowMessageBox('error', oError.message);
                                }
                            });
                            that._settingDialog.close();
                        }
                     }
                }));
                that._settingDialog.insertButton(new sap.m.Button({
                    text: oI18n.getText("ZGTPPF020.cancelBtn"),
                    press: function() {
                        that._settingDialog.close();
                    }
                }));
            }
            that._settingDialog.open();
},
        emptyCheckSet: function(){
            var oSettingplantid = sap.ui.getCore().byId('settingplantid');
            oSettingplantid.setValueState(NONE);
            var sSettingplantid= oSettingplantid.getValue();
            if ( sSettingplantid == null ||  sSettingplantid== '') {
                oSettingplantid.setValueState(ERROR);
                oSettingplantid.focus();
                return false;
            }
            var oSettingworkcenterid = sap.ui.getCore().byId('settingworkcenterid');
            oSettingworkcenterid.setValueState(NONE);
            var sSettingworkcenterid= oSettingworkcenterid.getValue();
            if ( sSettingworkcenterid == null ||  sSettingworkcenterid== '') {
                oSettingworkcenterid.setValueState(ERROR);
                oSettingworkcenterid.focus();
                return false;
            }
            var oSettingNameid = sap.ui.getCore().byId('settingNameid');
            oSettingNameid.setValueState(NONE);
            var sSettingNameid= oSettingNameid.getValue();

            if ( sSettingNameid == null ||  sSettingNameid== '') {
                oSettingNameid.setValueState(ERROR);
                oSettingNameid.focus();
                return false;
            }
            return true;
        }
    });
});