sap.ui.define([
    'ns/bsp02/controller/App.controller',
    'sap/ui/model/json/JSONModel',
    'sap/ui/model/odata/ODataModel',
    'sap/ui/core/routing/History',
    'sap/ui/core/UIComponent',
    'sap/ui/core/routing/Route',
    'sap/ui/model/Filter',
    'sap/ui/model/FilterOperator',
    "sap/ui/layout/form/SimpleForm",
    ], function(
            Controller,
            JSONModel,
            ODataModel,
            History,
            UIComponent,
            Route,
            Filter,
            FilterOperator,
            SimpleForm) {
    'use strict';
    var EMPTY = '';
    var NULL = null;
    var ERROR = 'Error';
    var NONE = 'None';
    var sAufnr = '';
    var sMatnr = '';
    var sRoundingvalue = '';
    var iWorkTime = '';
    var sWorkUnit = '';
    var bUpdate = false;
    var clickflag = false;
    var Batch = '';
    var successMsg = '';
    //var sZGTPPF020_SRV = 'proxy/http/160.21.205.176:8001/sap/opu/odata/SAP/ZGTPPF020_SRV?sap-client=331';
    // /sap/opu/odata/SAP/ZGTPPF020_SRV
    var sZGTPPF020_SRV = '/nsbsp02/sap/opu/odata/SAP/ZGTPPF020_SRV';
    var sWorkTimeSet = '/WorkTimeSet';
    var sReasonSet = '/ReasonSet';
    var sMOConfirmationSet = '/MOConfirmationSet';
    var sDefaultLocationSet = '/DefaultLocationSet'
    return Controller.extend('ns.bsp02.controller.MOConfirm', {
                    onInit : function() {
                        var oRouter = UIComponent.getRouterFor(this);
                        oRouter.getRoute('moconfirm').attachMatched(this.fRouteMatched, this);
                    },
                    fRouteMatched : function(oEvent) {
                        // Set bUpdate
                        bUpdate = false;
                        var that = this;
                        // Get Model
                        this.getView().byId('productionorderfinish').setEnabled(false);
                        this.getView().byId('productionorderfinish').setSelected(false);
                        this.getView().byId('vendorbatch').setEnabled(false);
                        var _MOConfirmHomeModel = this.getOwnerComponent().getModel('MOConfirmHomeModel');
                        var SAPBATCHModel = this.getOwnerComponent().getModel('SAPBATCHModel');
                        Batch = SAPBATCHModel.getData().Batch;
                        var SupervisorModel = this.getOwnerComponent().getModel('SupervisorModel');
                        var sSupervisor = SupervisorModel.getData().Super;
                        this.getView().byId("supervisor").setValue(sSupervisor);
                        var RoundingModel = this.getOwnerComponent().getModel('RoundingModel');
                        sRoundingvalue = RoundingModel.getData().Bstrf;
                        var homeFilterModel = this.getOwnerComponent().getModel('homeFilter');
                        sMatnr = homeFilterModel.getData().Matnr;
                        var sWerks = homeFilterModel.getData().Werks;
                        var oData = _MOConfirmHomeModel.getData();
                        var iGamng = parseInt(oData.Gamng);
                        var iGmnga = parseInt(oData.Gmnga);
                        this.getView().byId('yield').setValue(EMPTY);
                        this.getView().byId('commentplan').setValue(EMPTY);
                        // Get Router of Args.
                        var oArgs = oEvent.getParameter('arguments');
                        sAufnr = oArgs.Aufnr;
                        var oI18n = this.getView().getModel('i18n').getResourceBundle();
                        this.getView().byId('page').setTitle(
                                        oI18n.getText('ZGTPPF020.materialid') + ' ' + sMatnr + ' ' + '-' + ' '
                                                        + oI18n.getText('ZGTPPF020.appTitle') + ' ' + sAufnr + ' '
                                                        + oI18n.getText('ZGTPPF020.appDescription'));
                        // Set Date
                        this.fSetDate('post-date', EMPTY);
                        this.fSetDate('actual-start', 'actual-end');
                        // Set Time
                        this.fSetTime('start-time', 'end-time');
                        // loading
                        if (sWerks == "1900") {
                            var JsonModel = new JSONModel({
                                "WorkTime" : [ {
                                                "starttime" : "08:00",
                                                "endtime" : "10:00"
                                },{
                                                "starttime" : "10:00",
                                                 "endtime" : "11:20"
                                },{
                                                "starttime" : "10:00",
                                                "endtime" : "11:50"
                                },{
                                                "starttime" : "12:05",
                                                "endtime" : "14:00"
                                },{
                                                "starttime" : "12:35",
                                                "endtime" : "14:00"
                                },{
                                                "starttime" : "12:35",
                                                "endtime" : "14:30"
                                }, {
                                                "starttime" : "14:30",
                                                "endtime" : "16:45"
                                }, {
                                                "starttime" : "17:05",
                                                "endtime" : "20:05"
                                }, {
                                                "starttime" : "20:05",
                                                "endtime" : "22:00"
                                }, {
                                                "starttime" : "22:00",
                                                "endtime" : "00:00"
                                }, {
                                                "starttime" : "00:45",
                                                "endtime" : "02:50"
                                }, {
                                                "starttime" : "02:50",
                                                "endtime" : "04:50"
                                }, {
                                                "starttime" : "05:00",
                                                "endtime" : "08:00"
                                } ]
                            });
                            that.getView().byId('worktimeid').setModel(JsonModel);
                            that.getView().byId("worktimeid").setValue("08:00-10:00");
                        } else {
                            that.getView().byId('worktimeid').setModel(new JSONModel([]));
                        }
                        this.fShowBusyIndicator();
                        var oTimeStap = new Date();
                        var oModel = new ODataModel(sZGTPPF020_SRV, true);
                        var aFilter = [];
                        var oAufnr = new Filter({
                                        path : 'Aufnr',
                                        operator : FilterOperator.EQ,
                                        value1 : oArgs.Aufnr,
                                        value2 : ''
                        });
                        aFilter.push(oAufnr);
                        // WorkTime OData
                        oModel.read(sWorkTimeSet + '?' + oTimeStap, {
                                        async : false,
                                        filters : aFilter,
                                        success : function(oData) {
                                            var values = oData.results;
                                            if (values.length > 0) {
                                                // Start Date
                                                that.getView().byId('actual-start').setDateValue(values[0].Startdate);
                                                that.getView().byId('post-date').setDateValue(values[0].Startdate);
                                                // End Date
                                                that.getView().byId('actual-end').setDateValue(values[0].Enddate);
                                                /*
                                                 * // Start Time var sStartTime =
                                                 * values[0].Starttime;
                                                 * if(sStartTime != EMPTY){
                                                 * sStartTime =
                                                 * sStartTime.substring(0, 2) +
                                                 * ':' + sStartTime.substring(2,
                                                 * 4);
                                                 * that.getView().byId('start-time').setValue(sStartTime); } //
                                                 * End Time var sFinTime =
                                                 * values[0].Endtime;
                                                 * if(sFinTime != EMPTY){
                                                 * sFinTime =
                                                 * sFinTime.substring(0, 2) +
                                                 * ':' + sFinTime.substring(2,
                                                 * 4);
                                                 * that.getView().byId('end-time').setValue(sFinTime); }
                                                 */
                                                // Work Time
                                                if (values[0].Worktime != EMPTY) {
                                                    iWorkTime = values[0].Worktime;
                                                    sWorkUnit = values[0].Worktimeunit;
                                                    var iTotal = (iGamng - iGmnga) * values[0].Worktime;
                                                    that.getView().byId('work-input').setValue(iTotal);
                                                    that.getView().byId('work-input').setDescription(
                                                                    values[0].Worktimeunit);
                                                }
                                                // Break Time
                                                if (values[0].Breaktime != EMPTY && values[0].Breaktime > 0) {
                                                    that.getView().byId('break-time').setValue(values[0].Breaktime);
                                                }
                                                if (values[0].Breaktimeunit != EMPTY) {
                                                    that.getView().byId('break-time').setDescription(
                                                                    values[0].Breaktimeunit);
                                                }
                                            }
                                            that.fHideBusyIndicator();
                                        },
                                        error : function() {
                                            that.fHideBusyIndicator();
                                            that.fShowMessageBox('error', 'System Error.');
                                            return;
                                        }
                        });
                        // loading
                        this.fShowBusyIndicator();
                        // Reason OData
                        oModel.read(sReasonSet + '?' + oTimeStap, {
                                        async : false,
                                        filters : aFilter,
                                        success : function(oData) {
                                            var values = oData.results;
                                            if (values.length > 0) {
                                                values.push({
                                                                Aufnr : EMPTY,
                                                                Grdtx : EMPTY,
                                                                Grund : EMPTY,
                                                                Werks : EMPTY
                                                });
                                                var templete = {
                                                    ReasonSet : oData.results
                                                };
                                                var oJSONModel = new JSONModel(templete);
                                                that.getView().byId('reason').setModel(oJSONModel);
                                                that.getView().byId('batch').setValue(Batch);
                                                that.getView().byId('vendorbatch').setValue(Batch);
                                            }
                                            that.fHideBusyIndicator();
                                        },
                                        error : function() {
                                            that.fHideBusyIndicator();
                                            that.fShowMessageBox('error', 'System Error.');
                                        }
                        });
                        // loading
                        this.fShowBusyIndicator();
                        // Reason OData
                        oModel.read(sDefaultLocationSet + '?' + oTimeStap, {
                                        async : false,
                                        filters : aFilter,
                                        success : function(oData) {
                                            var values = oData.results;
                                            if (values.length > 0) {
                                                var oJSONModel = new JSONModel(oData);
                                                that.getView().byId('location').setModel(oJSONModel);
                                                that.getView().byId("employee").setValue(0);
                                                that.getView().byId("work-input").setValue(0);
                                            }
                                            that.fHideBusyIndicator();
                                        },
                                        error : function() {
                                            that.fHideBusyIndicator();
                                            that.fShowMessageBox('error', 'System Error.');
                                        }
                        });
                    },
                    fSetDate : function(id, endId) {
                        var dDate = new Date();
                        if (dDate.getHours() < 8) {
                            dDate.setDate(dDate.getDate() - 1);
                            this.getView().byId(id).setDateValue(dDate);
                            if (endId != EMPTY) {
                                this.getView().byId(endId).setDateValue(new Date());
                            }
                        } else {
                            this.getView().byId(id).setDateValue(new Date());
                            if (endId != EMPTY) {
                                dDate.setDate(dDate.getDate() + 1);
                                this.getView().byId(endId).setDateValue(dDate);
                            }
                        }
                    },
                    fSetTime : function(id, endId) {
                        var dDate = new Date();
                        if (dDate.getHours() < 8) {
                            this.getView().byId(id).setValue('1000');
                            this.getView().byId(endId).setValue('0800');
                        } else {
                            this.getView().byId(id).setValue('0800');
                            this.getView().byId(endId).setValue('1000');
                        }
                    },
                    onNavBack : function(oEvent) {
                        this.fRemoveValue();
                        this.fClearMessage();
                        history.go(-1);
                    },
                    timeChange : function() {
                        var worktime = this.getView().byId("worktimeid").getValue();
                        var result = worktime.split('-');
                        var start = result[0];
                        var startformat = start.split(':');
                        var starttime = startformat[0] + startformat[1];
                        this.getView().byId("start-time").setValue(starttime);
                        var end = result[1];
                        var endformat = end.split(':');
                        var endtime = endformat[0] + endformat[1];
                        this.getView().byId("end-time").setValue(endtime);
                    },
                    createConfirmation : function() {
                        var that = this;
                        var oI18n = this.getView().getModel('i18n').getResourceBundle();
                        var sPostDate = this.getView().byId('post-date').getValue();
                        var sLocation = this.getView().byId('location').getSelectedKey();
                        var nYieldId = this.getView().byId('yield').getValue();
                        var sStartTime = this.getView().byId('start-time').getValue();
                        var nWorkInput = this.getView().byId('work-input').getValue();
                        var sWorktimeunit = this.getView().byId('work-input').getDescription();
                        var sStartDate = this.getView().byId('actual-start').getValue();
                        var sEndDate = this.getView().byId('actual-end').getValue();
                        var nDefectInput = this.getView().byId('defect-input').getValue();
                        var sEndTime = this.getView().byId('end-time').getValue();
                        var nNoOfEmployee = this.getView().byId('employee').getValue();
                        var nBreakTime = this.getView().byId('break-time').getValue();
                        var sBreaktimeunit = this.getView().byId('break-time').getDescription();
                        var sReasonVal = this.getView().byId('reason').getSelectedKey();
                        var sVendorbatch = this.getView().byId('vendorbatch').getValue();
                        var sProductionOrderFinish = this.getView().byId('productionorderfinish').getSelected();
                        var sBatchFinsh = this.getView().byId('batchfinsh').getSelected();
                        var oMoId = sAufnr;
                        var sBatch = this.getView().byId('batch').getValue();
                        var sCommentInput = this.getView().byId('commentplan').getValue();
                        var sSuperVisor = this.getView().byId('supervisor').getValue();
                        var sQrcodenum = this.getView().byId('qrcodenumid').getValue();
                        if (sProductionOrderFinish == true) {
                            sProductionOrderFinish = 'X';
                        } else {
                            sProductionOrderFinish = ' ';
                        }
                        ;
                        if (sBatchFinsh == true) {
                            sBatchFinsh = 'X';
                        } else {
                            sBatchFinsh = ' ';
                        }
                        ;
                        if (nBreakTime == '') {
                            nBreakTime = '0';
                        }
                        /*
                         * var aStartTime = sStartTime.split(/:| /); if
                         * (aStartTime[2] == 'PM') { aStartTime[0] =
                         * parseInt(aStartTime[0]) + 12; } if (aStartTime[0] <
                         * 10) { aStartTime[0] = '0' + aStartTime[0]; }
                         *
                         * var aEndTime = sEndTime.split(/:| /); if (aEndTime[2] ==
                         * 'PM') { aEndTime[0] = parseInt(aEndTime[0]) + 12; }
                         * if (aEndTime[0] < 10) { aEndTime[0] = '0' +
                         * aEndTime[0]; } var sStartTime = aStartTime[0] + ':' +
                         * aStartTime[1]; var sEndTime = aEndTime[0] + ':' +
                         * aEndTime[1];
                         */
                        var oEntry = {};
                        oEntry.Orderid = oMoId;
                        oEntry.Operation = '0010';
                        oEntry.PostgDate = sPostDate;
                        oEntry.Location = sLocation;
                        oEntry.Yield = nYieldId;
                        oEntry.Scrap = nDefectInput;
                        oEntry.DevReason = sReasonVal;
                        oEntry.ConfActivity1 = nWorkInput;
                        oEntry.ConfActiUnit1 = sWorktimeunit;
                        oEntry.StartTime = sStartTime;
                        oEntry.EndTime = sEndTime;
                        if (sCommentInput != '' || nDefectInput != '') {
                            oEntry.ConfText = 'Plan:' + sCommentInput + ', ' + 'Defect:' + nDefectInput + ', '
                                            + sSuperVisor;
                        }
                        oEntry.NoOfEmployee = nNoOfEmployee;
                        oEntry.Vchag = sVendorbatch;
                        oEntry.Batch = sBatch;
                        oEntry.BreakTime = nBreakTime;
                        oEntry.BreakUnit = sBreaktimeunit;
                        oEntry.StartDate = sStartDate;
                        oEntry.EndDate = sEndDate;
                        oEntry.BatchFinish = sBatchFinsh;
                        oEntry.FinConf = sProductionOrderFinish;
                        oEntry.Num = sQrcodenum;
                        // loading
                        this.fShowBusyIndicator();
                        var oTimeStap = new Date();
                        var oModel = new ODataModel(sZGTPPF020_SRV, true);
                        var that = this;
                        oModel.create(sMOConfirmationSet + '?' + oTimeStap, oEntry, {
                                        async : false,
                                        success : function(data) {
                                            bUpdate = true;
                                            clickflag = false;
                                            that.fHideBusyIndicator();
                                            if (data.MsgTyp == 'E') {
                                                that.fShowMessageBox('error', data.Message);
                                            } else if (data.MsgTyp == 'W') {
//                                                that.fShowMessageBox('warning', data.Message);
                                                var oSubDialog = new sap.m.Dialog({
                                                    title : oI18n.getText('ZGTPPF020.WARNING'),
                                                    state : 'Error',
                                                    content : [ new SimpleForm({
                                                        content : [ new sap.m.Text({
                                                            text : data.Message
                                                        }) ]
                                                    }) ]
                                    });
                                    oSubDialog.open();
                                    oSubDialog.addButton(new sap.m.Button({
                                                    text : "OK",
                                                    press : function() {
                                                        var refreshFlagModel = {// TODO
                                                            refreshFlag : false
                                                        };
                                                        that.getView().byId('productionorderfinish')
                                                                        .setSelected(false);
                                                        that.getView().byId('productionorderfinish')
                                                                        .setEnabled(false);
                                                        that.getOwnerComponent().setModel(
                                                                        new JSONModel(refreshFlagModel),
                                                                        'refreshFlag');
                                                        that.onNavBack();
                                                    }
                                    }));
                                            } else {
                                                successMsg = data.Message
                                                var oSubDialog = new sap.m.Dialog({
                                                                title : oI18n.getText('ZGTPPF020.SUCCESS'),
                                                                state : 'Success',
                                                                content : [ new SimpleForm({
                                                                    content : [ new sap.m.Text({
                                                                        text : successMsg
                                                                    }) ]
                                                                }) ]
                                                });
                                                oSubDialog.open();
                                                oSubDialog.addButton(new sap.m.Button({
                                                                text : "OK",
                                                                press : function() {
                                                                    var refreshFlagModel = {// TODO
                                                                        refreshFlag : true
                                                                    };
                                                                    that.getView().byId('productionorderfinish')
                                                                                    .setSelected(false);
                                                                    that.getView().byId('productionorderfinish')
                                                                                    .setEnabled(false);
                                                                    that.getOwnerComponent().setModel(
                                                                                    new JSONModel(refreshFlagModel),
                                                                                    'refreshFlag');
                                                                    that.onNavBack();
                                                                }
                                                }));
                                            }
                                        },
                                        error : function(data) {
                                            clickflag = false;
                                            that.fHideBusyIndicator();
                                            that.fShowMessageBox('error', data.Message);
                                        }
                        });
                    },
                    onSave : function(evt) {
                        this.fClearMessage();
                        var oI18n = this.getView().getModel('i18n').getResourceBundle();
                        // Post Date
                        if(clickflag == true) {
                            this.fShowMessageBox('error', oI18n.getText("ZGTPPF020.Norepeat"));
                            return;
                        }

                        var sPostDate = this.getView().byId('post-date').getValue();
                        if (sPostDate == NULL || sPostDate == EMPTY) {
                            this.getView().byId('post-date').setValueState(ERROR);
                            this.getView().byId('post-date').focus();
                            return;
                        }
                        // batch
                        var sBatch = this.getView().byId('batch').getValue();
                        if (sBatch == NULL || sBatch == EMPTY) {
                            this.getView().byId('batch').setValueState(ERROR);
                            this.getView().byId('batch').focus();
                            return;
                        }
                        // location
                        var slocation = this.getView().byId('location').getSelectedKey();
                        if (slocation == NULL || slocation == EMPTY) {
                            this.getView().byId('location').focus();
                            return;
                        }
                        // yield
                        var sYield = this.getView().byId('yield').getValue();
                        if (sYield == NULL || sYield == EMPTY) {
                            this.getView().byId('yield').setValueState(ERROR);
                            this.getView().byId('yield').focus();
                            return;
                        }
                        // Work Time
                        var sWorkTime = this.getView().byId('work-input').getValue();
                        if (sWorkTime == NULL || sWorkTime == EMPTY) {
                            this.getView().byId('work-input').setValueState(ERROR);
                            this.getView().byId('work-input').focus();
                            return;
                        }
                        var sQRcodenum = this.getView().byId('qrcodenumid').getValue();
                        if (sQRcodenum == NULL || sQRcodenum == EMPTY) {
                            this.getView().byId('qrcodenumid').setValueState(ERROR);
                            this.getView().byId('qrcodenumid').focus();
                            return;
                        }
                        // start date and end date
                        var oStartDate = this.getView().byId('actual-start').getDateValue();
                        var oEndDate = this.getView().byId('actual-end').getDateValue();
                        var checkD = this.compareDate(oStartDate, oEndDate);
                        if (checkD == 0) {
                            this.getView().byId('actual-start').setValueState(ERROR);
                            this.getView().byId('actual-end').setValueState(ERROR);
                            this.getView().byId('actual-start').focus();
                            return;
                        }
                        // start time and end time
                        var sStartTime = this.getView().byId('start-time').getValue();
                        var sEndTime = this.getView().byId('end-time').getValue();
                        var sworkInput = this.getView().byId('work-input').getValue();
                        if (checkD == 1) {
                            if (sworkInput < 0 || sStartTime >= sEndTime) {
                                this.getView().byId('start-time').setValueState(ERROR);
                                this.getView().byId('end-time').setValueState(ERROR);
                                this.getView().byId('start-time').focus();
                                return;
                            }
                        }
                        var that = this;
                        var oCheckDialog = new sap.m.Dialog({
                                        title : oI18n.getText('ZGTPPF020.confirm'),
                                        type : 'Message',
                                        state : 'Warning',
                                        content : [ new sap.m.Label({
                                            text : oI18n.getText('ZGTPPF020.questionMessage')
                                        }) ]
                        });
                        oCheckDialog.open();
                        oCheckDialog.addButton(new sap.m.Button({
                                        text : oI18n.getText('ZGTPPF020.btnOK'),
                                        press : function() {
                                            oCheckDialog.close();
                                            clickflag = true;
                                            that.createConfirmation();
                                        }
                        }));
                        oCheckDialog.addButton(new sap.m.Button({
                                        text : oI18n.getText('ZGTPPF020.btnCancel'),
                                        press : function() {
                                            clickflag = false;
                                            oCheckDialog.close();
                                        }
                        }));
                    },
                    compareDate : function(beginT, endT) {
                        beginT = beginT.toString();
                        endT = endT.toString();
                        var sbeginT = beginT.substr(4, 11);
                        var sendT = endT.substr(4, 11);
                        var beginTs = sbeginT.split(' ');
                        var endTs = sendT.split(' ');
                        beginT = beginTs[0] + ' ' + beginTs[1] + ', ' + beginTs[2];
                        endT = endTs[0] + ' ' + endTs[1] + ', ' + endTs[2];
                        var beginTL = Date.parse(beginT);
                        var endTL = Date.parse(endT);
                        if (beginTL > endTL) {
                            return 0;
                        } else if (beginTL == endTL) {
                            return 1;
                        } else {
                            return 2;
                        }
                    },
                    changeDateTime : function(oEvent) {/*
                     * // count worktime var
                     * nHour; var nNewValue =
                     * oEvent.getParameter('value');
                     * var sStartTime =
                     * this.getView().byId('start-time').getValue();
                     * var sEndTime =
                     * this.getView().byId('end-time').getValue();
                     * var sStartDate =
                     * this.getView().byId('actual-start').getDateValue();
                     * var sEndDate =
                     * this.getView().byId('actual-end').getDateValue();
                     * var sDes =
                     * this.getView().byId('work-input').getDescription();
                     * var aStartTime =
                     * sStartTime.split(/:|
                     * /); var aEndTime =
                     * sEndTime.split(/:|
                     * /); if (sStartDate !=
                     * sEndDate &&
                     * sStartDate != '' &&
                     * sEndDate != '') { var
                     * nTotal =
                     * (sEndDate.getTime() -
                     * sStartDate.getTime()) /
                     * 1000; nHour =
                     * parseInt(nTotal / (60 *
                     * 60)); } if
                     * (aStartTime[2] ==
                     * 'PM') { aStartTime[0] =
                     * parseInt(aStartTime[0]) +
                     * 12; } if (aEndTime[2] ==
                     * 'PM') { aEndTime[0] =
                     * parseInt(aEndTime[0]) +
                     * 12; } if (sEndTime != '' &&
                     * sStartTime != '') {
                     * nNewValue =
                     * aEndTime[0] -
                     * aStartTime[0] +
                     * (aEndTime[1] -
                     * aStartTime[1]) / 60;
                     * nNewValue = nNewValue +
                     * nHour; if (sDes ==
                     * 'MIN') { nNewValue =
                     * nNewValue * 60; }
                     * else if (sDes == 'S') {
                     * nNewValue = nNewValue +
                     * 3600; } nNewValue =
                     * Math.ceil(nNewValue *
                     * Math.pow(10, 3)) /
                     * Math.pow(10, 3);
                     * this.getView().byId('work-input').setValue(nNewValue); }
                     * var nEmpNo =
                     * this.getView().byId('employee').getValue();
                     * nNewValue = nNewValue *
                     * nEmpNo; //
                     * this.getView().byId('work-input').setValue(nNewValue);
                     */
                        this.fClearMessage();
                        var startDate = this.getView().byId("actual-start").getDateValue();
                        var endDate = this.getView().byId("actual-end").getDateValue();
                        var sDate_string = startDate.toString().substr(4, 11);
                        var eDate_string = endDate.toString().substr(4, 11);
                        var startDateArr = sDate_string.split(' ');
                        var endDateArr = eDate_string.split(' ');
                        var sDate_L = startDateArr[0] + ' ' + startDateArr[1] + ', ' + startDateArr[2];
                        var eDate_L = endDateArr[0] + ' ' + endDateArr[1] + ', ' + endDateArr[2];
                        var startD_ms = Date.parse(sDate_L);
                        var endD_ms = Date.parse(eDate_L);
                        var e_sDate_min = (endD_ms - startD_ms) / 60000;
                        var checkDate = this.compareDate(startDate, endDate);
                        var startTime = this.getView().byId("start-time").getDateValue();
                        var endTime = this.getView().byId("end-time").getDateValue();
                        var nEmpNo = this.getView().byId('employee').getValue();
                        if (checkDate == 0) {
                            this.getView().byId("actual-start").setValueState(ERROR);
                            this.getView().byId("actual-end").setValueState(ERROR);
                            this.getView().byId('actual-end').focus();
                            if (endTime <= startTime) {
                                this.getView().byId('start-time').setValueState(ERROR);
                                this.getView().byId('end-time').setValueState(ERROR);
                                this.getView().byId('end-time').focus();
                                return;
                            }
                            return;
                        } else if (checkDate == 1) {
                            if (endTime <= startTime) {
                                this.getView().byId('start-time').setValueState(ERROR);
                                this.getView().byId('end-time').setValueState(ERROR);
                                this.getView().byId('end-time').focus();
                                return;
                            }
                        }
                        if (nEmpNo == "" || nEmpNo == null) {
                            nEmpNo = 0;
                            this.getView().byId('employee').setValue(nEmpNo);
                        }
                        var sDate = endTime - startTime;
                        // min
                        var sDate_min = parseInt(e_sDate_min) + parseInt(sDate / 60000);
                        var sDate_total = sDate_min * nEmpNo;
                        this.getView().byId('work-input').setValue(sDate_total);
                        this.getView().byId('work-input').setDescription("MIN")
                    },
                    handleValueHelp : function(oEvent) {
                        var sInputValue = oEvent.getSource().getValue();
                        this.inputId = oEvent.getSource().getId();
                        // create value help dialog
                        if (!this._valueHelpDialog) {
                            this._valueHelpDialog = sap.ui.xmlfragment('ns.bsp02.view.Dialog', this);
                            this.getView().addDependent(this._valueHelpDialog);
                        }
                        this._valueHelpDialog.open(sInputValue);
                    },
                    _getDialog : function() {
                        // create dialog lazily
                        if (!this._valueHelpDialog) {
                            // create dialog via fragment factory
                            this._valueHelpDialog = sap.ui.xmlfragment('ns.bsp02.view.Dialog', this);
                            // connect dialog to view (models, lifecycle)
                            this.getView().addDependent(this._valueHelpDialog);
                        }
                        return this._valueHelpDialog;
                    },
                    _handleValueHelpClose : function(evt) {
                        this._getDialog().close();
                    },
                    changeTotal : function(oEvent) {
                        var oYield = this.getView().byId('yield');
                        var oWorkInput = this.getView().byId('work-input');
                        var oEmployee = this.getView().byId('employee');
                        var iValue = oYield.getValue();
                        if (oEmployee.getValue() == 1 || oEmployee.getValue() == 0) {
                            oWorkInput.setValue(iValue * iWorkTime);
                        } else {
                            oWorkInput.setValue(iValue * iWorkTime * oEmployee.getValue());
                        }
                        this.getView().byId('work-input').setDescription(sWorkUnit);
                    },
                    changeHour : function(evt) {
                        var sId = this.inputId
                        var aId = sId.split('--');
                        var nValue = this.getView().byId(aId[1]).getValue();
                        var sDes = this.getView().byId(aId[1]).getDescription();
                        if (sDes == 'S') {
                            nValue = nValue / 3600;
                        } else if (sDes == 'MIN') {
                            nValue = nValue / 60;
                        }
                        nValue = Math.ceil(nValue * Math.pow(10, 3)) / Math.pow(10, 3);
                        this.getView().byId(aId[1]).setValue(nValue);
                        this.getView().byId(aId[1]).setDescription('H');
                        this._getDialog().close();
                    },
                    changeMinutes : function(evt) {
                        var sId = this.inputId
                        var aId = sId.split('--');
                        var nValue = this.getView().byId(aId[1]).getValue();
                        var sDes = this.getView().byId(aId[1]).getDescription();
                        if (sDes == 'H') {
                            nValue = nValue * 60;
                        } else if (sDes == 'S') {
                            nValue = nValue / 60;
                        }
                        nValue = Math.ceil(nValue * Math.pow(10, 3)) / Math.pow(10, 3);
                        this.getView().byId(aId[1]).setValue(nValue);
                        this.getView().byId(aId[1]).setDescription('MIN');
                        this._getDialog().close();
                    },
                    changeSeconds : function(evt) {
                        var sId = this.inputId
                        var aId = sId.split('--');
                        var nValue = this.getView().byId(aId[1]).getValue();
                        var sDes = this.getView().byId(aId[1]).getDescription();
                        if (sDes == 'H') {
                            nValue = nValue * 3600;
                        } else if (sDes == 'MIN') {
                            nValue = nValue * 60;
                        }
                        nValue = Math.ceil(nValue * Math.pow(10, 3)) / Math.pow(10, 3);

                        this.getView().byId(aId[1]).setValue(nValue);
                        this.getView().byId(aId[1]).setDescription('S');
                        this._getDialog().close();
                    },
                    fRemoveValue : function() {
                        // one
                        this.getView().byId('post-date').setDateValue(new Date());
                        this.getView().byId('supervisor').setValue(EMPTY);
                        this.getView().byId('batch').setValue(EMPTY);
                        this.getView().byId('vendorbatch').setValue(EMPTY);
                        // two
                        this.getView().byId('actual-start').setDateValue(new Date());
                        this.getView().byId('actual-end').setDateValue(new Date());
                        this.getView().byId('start-time').setValue(EMPTY);
                        this.getView().byId('worktimeid').setValue(EMPTY);
                        this.getView().byId('end-time').setValue(EMPTY);
                        // three
                        this.getView().byId('location').setSelectedKey(EMPTY);
                        this.getView().byId('yield').setValue(EMPTY);
                        this.getView().byId('commentplan').setValue(EMPTY);
                        this.getView().byId('defect-input').setValue(0);
                        this.getView().byId('reason').setSelectedItemId(EMPTY);
                        // four
                        this.getView().byId('employee').setValue(0);
                        this.getView().byId('work-input').setValue(0);
                        this.getView().byId('break-time').setValue(0);
                        // five
                        this.getView().byId('productionorderfinish').setSelected(false);
                        this.getView().byId('batchfinsh').setSelected(false);
                    },
                    // none, question, error, information, warning, success
                    fShowMessageBox : function(type, content) {
                        var oI18n = this.getView().getModel('i18n').getResourceBundle();
                        var bCompact = !!this.getView().$().closest(".sapUiSizeCozy").length;
                        var Options = NULL;
                        if (type == 'error') {
                            Options = {
                                            icon : sap.m.MessageBox.Icon.ERROR,
                                            title : oI18n.getText('ZGTPPF020.ERROR'),
                                            actions : sap.m.MessageBox.Action.OK,
                                            onClose : null,
                                            styleClass : bCompact ? "sapUiSizeCozy" : "",
                                            initialFocus : null,
                                            textDirection : sap.ui.core.TextDirection.Inherit
                            };
                        } else if (type == 'warning') {
                            Options = {
                                            icon : sap.m.MessageBox.Icon.WARNING,
                                            title : oI18n.getText('ZGTPPF020.WARNING'),
                                            actions : sap.m.MessageBox.Action.OK,
                                            onClose : null,
                                            styleClass : bCompact ? "sapUiSizeCozy" : "",
                                            initialFocus : null,
                                            textDirection : sap.ui.core.TextDirection.Inherit
                            };
                        } else if (type == 'success') {
                            Options = {
                                            icon : sap.m.MessageBox.Icon.SUCCESS,
                                            title : oI18n.getText('ZGTPPF020.SUCCESS'),
                                            actions : sap.m.MessageBox.Action.OK,
                                            onClose : null,
                                            styleClass : bCompact ? "sapUiSizeCozy" : "",
                                            initialFocus : null,
                                            textDirection : sap.ui.core.TextDirection.Inherit
                            };
                        }
                        sap.m.MessageBox.show(content, Options);
                    },
                    fClearMessage : function() {
                        this.getView().byId('post-date').setValueState(NONE);
                        this.getView().byId('batch').setValueState(NONE);
                        this.getView().byId('yield').setValueState(NONE);
                        this.getView().byId('work-input').setValueState(NONE);
                        this.getView().byId('actual-start').setValueState(NONE);
                        this.getView().byId('actual-end').setValueState(NONE);
                        this.getView().byId('start-time').setValueState(NONE);
                        this.getView().byId('end-time').setValueState(NONE);
                    },
                    fHideBusyIndicator : function() {
                        var oDialog = sap.ui.getCore().byId('BusyDialog');
                        if (oDialog) {
                            oDialog.close();
                        }
                    },
                    fShowBusyIndicator : function() {
                        var oDialog = sap.ui.getCore().byId('BusyDialog');
                        if (!oDialog) {
                            oDialog = new sap.m.BusyDialog('BusyDialog');
                        }
                        oDialog.open();
                    },
                    QuantityChange : function() {
                        var that = this;
                        var oI18n = this.getView().getModel('i18n').getResourceBundle();
                        var sMenge = this.getView().byId("yield").getValue();
                        if (sRoundingvalue == '0' || sRoundingvalue == null || sRoundingvalue == '') {
                            that.getView().byId('qrcodenumid').setValue("1");
                        } else {
                            var sQRnumbers = Math.ceil(sMenge / sRoundingvalue);
                            this.getView().byId('qrcodenumid').setValue(sQRnumbers);
                        }
                    },
                    NumberChange : function(event) {
                        var that = this;
                        var oI18n = that.getView().getModel('i18n').getResourceBundle();
                        var sValue = that.getView().byId('qrcodenumid').getValue();
                        var eValue = parseInt(sValue);
                        this.getView().byId('qrcodenumid').setValue(eValue);
                        if (sValue < 0 || sValue == '') {
                            that.getView().byId('qrcodenumid').setValueState('Error');
                            that.getView().byId('qrcodenumid').setValueStateText(
                                            oI18n.getText('ZGTPPF020.QRpositivenumber'));
                            that.getView().byId('qrcodenumid').focus();
                            return false;
                        } else {
                            that.getView().byId('qrcodenumid').setValueState('None');
                        }
                        return true;
                    },
                    batchChange : function() {
                        var oI18n = this.getView().getModel('i18n').getResourceBundle();
                        var ssapbatch = this.getView().byId("batch").getValue();
                        this.getView().byId("vendorbatch").setValue(ssapbatch);
                    }
    });
});