sap.ui.define([
	"ns/bsp02/test/unit/controller/App.controller"
], function () {
	"use strict";
});
