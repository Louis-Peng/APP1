sap.ui.define([
		"sap/ui/core/mvc/Controller"
	],
	/**
     * @param {typeof sap.ui.core.mvc.Controller} Controller
     */
	function (Controller) {
		"use strict";

		return Controller.extend("ns.launchpad.controller.View1", {
			onInit: function () {

            },
            onApprove: function(){
                var apprurl = 'https://demo02.alidemo01-approuter.autoloopup.com/workwx/apply';
                window.open(apprurl,"_self");
            },
            onPress: function(){
                var newUrl = 'https://accenture-company-limited.ap1.sapanalytics.cloud/sap/fpa/ui/tenants/044/app.html#;view_id=story;storyId=AFEB2AF56DA66B1622E3687E3AB256BF';
                // var newUrl = 'https://accenture.us2.sapbusinessobjects.cloud/sap/fpa/ui/tenants/022/app.html#;view_id=story;storyId=594A62F47DF053C79C105150EA72F8DB';
                window.open(newUrl,"_self");
            },
            onSales: function(){
                var pooUrl3 = 'https://accenture-company-limited.ap1.sapanalytics.cloud/sap/fpa/ui/tenants/044/app.html#;view_id=story;storyId=BB8DBAF32591352CEDD14D52939598C4';
                window.open(pooUrl3,'_self');
            },
            goShift: function(){
                // var shiftUrl = 'https://flexible.alidemo01-approuter.autoloopup.com/nsYAC_FLEXIBLE/index.html';
                var shiftUrl = "https://demo02.alidemo01-approuter.autoloopup.com/nsYacWorkSchedule/index.html";
                window.open(shiftUrl,"_self");
            },
            goPOmgt: function(){
                var pooUrl2 = 'https://demo02.alidemo01-approuter.autoloopup.com/nsBSP11/index.html';
                window.open(pooUrl2,'_self');
            },
            goPOWF: function(){
                var pooUrl = 'https://demo02.alidemo01-approuter.autoloopup.com/nsdelivery/index.html';
                window.open(pooUrl,'_self');
            },
            goStock: function(){
                var moveUrl2 = 'https://demo02.alidemo01-approuter.autoloopup.com/nsbsp05/index.html';
                window.open(moveUrl2,"_self");
            },
            goMove: function(){
                var moveUrl = 'https://demo02.alidemo01-approuter.autoloopup.com/nsbsp03/index.html';
                window.open(moveUrl,"_self");
            },
            goMo: function(){
                var moUrl = 'https://demo02.alidemo01-approuter.autoloopup.com/nsbsp01/index.html';
                window.open(moUrl,"_self");
            },
            goPo: function(){
                var poUrl = 'https://demo02.alidemo01-approuter.autoloopup.com/nsbsp02/index.html';
                window.open(poUrl,"_self");
            },
            goAsset: function(){
                var assetUrl = 'https://demo02.alidemo01-approuter.autoloopup.com/nsfiasset/index.html';
                window.open(assetUrl,"_self");
            },
            goOcr: function(){
                var ocrUrl = 'https://demo02.alidemo01-approuter.autoloopup.com/nsVATInvoiceRecognize/index.html';
                window.open(ocrUrl,'_self');
            },
            goOcr2: function(){
                var ocrUrl2 = 'https://demo02.alidemo01-approuter.autoloopup.com/nsVATInvoiceMgmt/index.html';
                window.open(ocrUrl2,'_self');
            }
		});
	});
