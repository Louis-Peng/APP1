sap.ui.define([
	"ns/delivery/test/unit/controller/View1.controller"
], function () {
	"use strict";
});
