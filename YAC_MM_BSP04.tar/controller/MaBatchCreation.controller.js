sap.ui.define([
  "ns/delivery/controller/BaseController",
  "sap/ui/core/UIComponent",
  "sap/ui/model/json/JSONModel",
  "sap/ui/model/Filter",
  "sap/ui/model/FilterOperator",
  "sap/m/MessageToast",
  "sap/m/MessageBox",
  "sap/m/TablePersoController",
  "sap/ui/layout/VerticalLayout",
  "sap/ui/layout/form/SimpleForm",
  "sap/ui/model/odata/ODataModel",
  "sap/ui/model/resource/ResourceModel",
  "sap/m/Dialog",
  "sap/ui/core/routing/History",
  "./Formatter",
  "sap/m/Text",
  "sap/m/TextArea",
  "sap/m/Button"
], function(
  BaseController,
  UIComponent,
  JSONModel,
  Filter,
  FilterOperator,
  MessageToast,
  MessageBox,
  TablePersoController,
  VerticalLayout,
  SimpleForm,
  ODataModel,
  ResourceModel,
  Dialog,
  History,
  Formatter,
  Text,
  TextArea,
  Button){
  'use strict';
  var flag = false;
  var itemChangeType = false;
  var aTable;
  var scanTimes = 0;
  var scanTotalQty;
  var sDividendVal;
  var sXCHPF, sMATEDSC, sMATEQTY, sSAPBATCH, sLocation, sMoveTypeVal, sItemObj, sQRNUM;
  var sPoEBELN, sMATELNUM, sUnitMEINS, sQtyVal, vdBatchVal;
  var PrinterHelpData = "";
  var defaultData = {};
    var newDefaultData = {};
    var navModel;
    // jQuery.sap.require("sap.ndc.BarcodeScanner");
//    var oModel = new ODataModel("proxy/http/160.21.205.176:8001/sap/opu/odata/SAP/ZGTMMF100_SRV/?sap-client=331");
    var oModel = new ODataModel("/nsdelivery/sap/opu/odata/SAP/ZGTMMF100_SRV/");
    return BaseController.extend('ns.delivery.controller.MaBatchCreation', {
      onInit : function () {
        var that = this;
        aTable = this.getView().byId("table");
        scanTimes = 0;
            this.fSetDate();
            flag = false;
            var sModel = new JSONModel([]);
            aTable.setModel(sModel);
            var i18nModel = new ResourceModel({
                bundleName : "ns.delivery.i18n.i18n"
            });
            this.getView().setModel(i18nModel, "i18n");

            if(sap.ui.getCore().byId('dialogPlantNId')){
              sap.ui.getCore().byId('dialogPlantNId').destroy();
            sap.ui.getCore().byId('dialogLocationNId').destroy();
            }
      //refresh the page when nav back
        var oRouter = UIComponent.getRouterFor(this);
        oRouter.getRoute('maBatchCreation').attachMatched(this._onRouteMatched, this);
    },   
    onNavBack: function (oEvent) {
        history.go(-1);
    },
    _onRouteMatched : function(){
      var that = this;
      var bUpdateModel = this.getOwnerComponent().getModel('bUpdateModelmmf110');
          if(bUpdateModel != null && bUpdateModel != ""){
              var oData = bUpdateModel.getData();
              var bUpdate = oData.bUpdate;
              if(bUpdate){
                  this.onClear();
              }
          }
    },
    /**When the page rendered, the function excuted*/
    onAfterRendering : function(){
      var that = this;
      flag = false;
      scanTimes = 0;
            this.fSetDate();
            aTable.setModel(new JSONModel([]));
      var oI18n = this.getView().getModel('i18n').getResourceBundle();
      var sMoveItemId = this.getView().byId('movementType').getSelectedKey();
      sMoveTypeVal = this.getView().byId('movementType').getItemByKey(sMoveItemId).mProperties.text;

      var rFilter = [];
            rFilter[0] = new sap.ui.model.Filter({
                path : 'SCAN',
                operator : sap.ui.model.FilterOperator.EQ,
                value1 : "X"
            });
            oModel.read("/UserParameters/", {
                async : false,
                filters : rFilter,
                success : function(oERP, oResponse){
                    var sPlant = oERP.results[0].WERKS;
                    var sLocation = oERP.results[0].LGORT;
                    var sPrinterName = oERP.results[0].NAME;
                    if($.trim(sPlant) == "" || sPlant == null || sPlant == undefined ||
                    $.trim(sLocation) == "" || sLocation == null || sLocation == undefined){
                        //that._setBtnEnableF();
                        that._setInputEnableF();
                        that.fShowMessageBox('error', that.getModel("i18n").getResourceBundle().getText("defaultEmpty"));
                    }else{
                        that.getView().byId('scanId').setEnabled(true);
                        defaultData.WERKS = oERP.results[0].WERKS;
                        defaultData.LGORT = oERP.results[0].LGORT;
                        defaultData.NAME = oERP.results[0].NAME;
                        that.getView().setModel((new JSONModel({
                            BDATU: new Date(), //postingDate
                            WERKS: oERP.results[0].WERKS, //plant
                            LGORT: oERP.results[0].LGORT //Storage Location
                        })), "data");
                    }
                },
                error : function(oError){
                    that.fShowMessageBox('error', oError.message);
                }
            });
        },
        /**Set the default value of Filter part*/
    onSetting : function(){
          var oI18n = this.getView().getModel('i18n').getResourceBundle();
          var that = this;
          if(!that._settingNewDialog){
            that._settingNewDialog = new sap.m.Dialog({
                    title: oI18n.getText("setDialogTitle"),
                    icon: "sap-icon://employee",
                    state: 'Success',
                    content: [
                      new sap.ui.layout.form.SimpleForm({
                      content: [
              new VerticalLayout({
                width: '350px',
                content: [
                    new sap.m.Label({text : oI18n.getText("plant"),required:true}),
                  new sap.m.Input("dialogPlantNId", {valueLiveUpdate:true,maxLength : 4}),
                  new sap.m.Label({text : oI18n.getText("locationTitle"),required:true}),
                  new sap.m.Input("dialogLocationNId", {valueLiveUpdate:true,maxLength : 8}),
                ]})
                        ]
                      })
                    ]
                });
            that._settingNewDialog.addButton(new sap.m.Button({
                    text: oI18n.getText("save"),
                    type: "Accept",
                    icon: "sap-icon://save",
                    press: function() {
                      if(!that.emptyCheckSet()){
                        return;
                      }else{
                        var oTimeStap = new Date();
                        newDefaultData.WERKS = sap.ui.getCore().byId('dialogPlantNId').getValue();
                        newDefaultData.LGORT = sap.ui.getCore().byId('dialogLocationNId').getValue();
                        newDefaultData.NAME = "";
                        newDefaultData.SCAN = "X";
                        oModel.create("/UserParameters/" + '?' + oTimeStap, newDefaultData,{
                            success: function(oData){
                              if(oData.MSGTY == "S"){
                                that.getView().byId('scanId').setEnabled(true);
                                that._setInputEnableT();
                                that._setBtnEnableT();
                                /*defaultData.WERKS = oData.WERKS;
                                defaultData.LGORT = oData.LGORT;*/
                                that.onAfterRendering();
                                that.onClear();
                        }else{// if(oData.MSGTY == "E")
                          that.fShowMessageBox('error', oData.MSGCT);
                          return;
                        }
                              },
                              error: function(oError){
                                  that.fShowMessageBox('error', oError.message);
                                  return;
                              }
                          });
                        that.getView().byId("table").setModel(new JSONModel([]));
                        that._settingNewDialog.close();
                      }
                     }
                }));
            that._settingNewDialog.insertButton(new sap.m.Button({
                    text: oI18n.getText("cancelBtn"),
                    press: function() {
                      that._settingNewDialog.close();
                    }
                }));
          }
          that._settingNewDialog.open();
          sap.ui.getCore().byId('dialogPlantNId').setValue(defaultData.WERKS);
          sap.ui.getCore().byId('dialogLocationNId').setValue(defaultData.LGORT);
        },
        /**
         *Scan get value of 0:material NO. 1:Unit 2:Qty 3:PO/MO 4:Vender Batch 5:Sap Batch
         */
        onScan : function(){
            jQuery.sap.require("sap.ndc.BarcodeScanner");
      flag = true;
      scanTimes += 1;
      var that = this;
      var oData = this.getView().getModel('data');
      var oI18n = this.getView().getModel("i18n").getResourceBundle();
      if(true){
//      if(sap.ui.Device.os.ios){
        //call method to scan
        sap.ndc.BarcodeScanner.scan(
          function(sResult){
            //scan normally by user
                      if(sResult.cancelled == false){
                        //test data
                        //var sResult = {};
                          //sResult.text = "100020772,EA,72.000,4502294340,TEST,2016072101";
                        var result = sResult.text.split(',');
                        if(result.length != 6){
                          //that.onScanError();
                              that.onSubmitDialog(
                                'sap-icon://message-error',
                                oI18n.getText("boxError"),
                                oI18n.getText("codeError") + sResult.text
                            );
                              return;
                        }
                        sPoEBELN = result[3];//PO Number
                        sMATELNUM = result[0];//Material NO.
                        sUnitMEINS = result[1];//Unit
                        sQtyVal = result[2];//Qty
                        vdBatchVal = result[4];//Vender Batch
                        sSAPBATCH = result[5];//Sap Batch
                        var prePoNum = that.getView().byId('PoNumId').getValue();
                        if($.trim(prePoNum) == "" || prePoNum == null || prePoNum == undefined){
                          scanTimes = 1;
                        }
                        if($.trim(sPoEBELN) == "" || sPoEBELN == null || sPoEBELN == undefined){
                          that.fShowMessageBox('error', oI18n.getText("codeError"));
                          return;
                        }else{
                          if(scanTimes == 1){
                            that.getView().byId('PoNumId').setValue(sPoEBELN);
                            if(aTable.getItems().length > 0){
                              if(that._checkMaNum()){
                                that.onAddItemFuc();
                              }else{
                                that.fShowMessageBox('error', oI18n.getText('codeError'));
                                return;
                              }
                            }else{
                              that.onReadItems();
                            }
                          }else{
                            if(prePoNum != sPoEBELN){
                              that.fShowMessageBox('error', oI18n.getText('poNumError'));
                              return;
                            }else{
                              if(that._checkMaNum()){
                                that.onAddItemFuc();
                              }else{
                                that.fShowMessageBox('error', oI18n.getText('codeError'));
                                return;
                              }
                              /*if(!that._checkVdBatch()){
                                that.onAddItemFuc();
                              }else{
                                that.fShowMessageBox('error', oI18n.getText('batchRepeat') + vdBatchVal);
                              }*/
                            }
                          }
                        }
                      }else{
                        //that.onScanError();
                          that.fShowMessageBox('error', oI18n.getText("scanCancel"));
                          return;
                      }
          },
          function(error){
            if(scanTimes == 1){
              that.onClear();
            }
            that.onSubmitDialog(
                    'sap-icon://message-error',
                    oI18n.getText("boxError"),
                    oI18n.getText("scanError")
                );
          }
        )
      }else{
        //that.onScanError();
        that.onSubmitDialog(
                'sap-icon://message-error',
                oI18n.getText("boxError"),
                oI18n.getText("scanError")
            );
      }
    },
    /**Error Dialog for scan with submit*/
    onSubmitDialog: function (iconUrl,typeDecs,msgContent) {
      var oData = this.getView().getModel('data');
      var that = this;
      var oI18n = this.getView().getModel("i18n").getResourceBundle();
      var _TextArea = "";
      var dialog = new Dialog({
        icon: iconUrl,
        title: typeDecs,
        type: "Message",
        state: "Error",
        content: [
          new Text({ text: msgContent }),
          _TextArea = new TextArea(that.createId('submitDialogTextarea'), {
            liveChange: function(oEvent) {
              var sText = oEvent.getParameter('value');
              var parent = oEvent.getSource().getParent();
              parent.getBeginButton().setEnabled(sText.length > 0);
            },
            width: '100%',
            placeholder: oI18n.getText("enterQrInfor")
          }),
          _TextArea.addStyleClass("sapUiTinyMarginTop")
        ],
        beginButton: new Button({
          text: oI18n.getText("okBtn"),
          enabled: false,
          press: function () {
            var sText = sap.ui.getCore().byId(that.createId('submitDialogTextarea')).getValue();
            var result = {};
            result.text = sText;
            var values = result.text;
                    var aResult = values.split(',');
                    sPoEBELN = aResult[3];//PO NO.
                      sMATELNUM = aResult[0];//material number
                      sUnitMEINS = aResult[1];//Unit
                      sQtyVal = aResult[2];//Qty
                      vdBatchVal = aResult[4];//Vender Batch
                      sSAPBATCH = aResult[5];//Sap Batch
                      var prePoNum = that.getView().byId('PoNumId').getValue();
                      if($.trim(prePoNum) == "" || prePoNum == null || prePoNum == undefined){
                        scanTimes = 1;
                      }
                      if($.trim(sPoEBELN) == "" || sPoEBELN == null || sPoEBELN == undefined){
                        that.fShowMessageBox('error', oI18n.getText("codeError"));
                        return;
                      }else{
                        if(scanTimes == 1){
                          that.getView().byId('PoNumId').setValue(sPoEBELN);
                          if(aTable.getItems().length > 0){
                            if(that._checkMaNum()){
                              that.onAddItemFuc();
                            }else{
                              that.fShowMessageBox('error', oI18n.getText('codeError'));
                              return;
                            }
                          }else{
                            that.onReadItems();
                          }
                        }else{
                          if(prePoNum != sPoEBELN){
                            that.fShowMessageBox('error', oI18n.getText('poNumError'));
                            return;
                          }else{
                            if(that._checkMaNum()){
                              that.onAddItemFuc();
                            }else{
                              that.fShowMessageBox('error', oI18n.getText('codeError'));
                              return;
                            }
                          }
                        }
                      }
            dialog.close();
          }
        }),
        endButton: new Button({
          text: oI18n.getText("cancelBtn"),
          press: function () {
            dialog.close();
          }
        }),
        afterClose: function() {
          dialog.destroy();
        }
      });
      dialog.open();
    },
    /**When PO changed,Item change*/
        onReadItems : function(){
          var that = this;
          var oI18n = this.getView().getModel("i18n").getResourceBundle();
          var sItemVal;
          var aFilter = [];
      aFilter[0] = new sap.ui.model.Filter({
        path: "EBELN",
        operator: sap.ui.model.FilterOperator.EQ,
        value1: sPoEBELN,
        value2: ""
      });
      aFilter[1] = new sap.ui.model.Filter({
        path: "WERKS",
        operator: sap.ui.model.FilterOperator.EQ,
        value1: defaultData.WERKS,
        value2: ""
      });
      aFilter[2] = new sap.ui.model.Filter({
        path: "LGORT",
        operator: sap.ui.model.FilterOperator.EQ,
        value1: defaultData.LGORT,
        value2: ""
      });
      aFilter[3] = new sap.ui.model.Filter({
        path: "BWART",
        operator: sap.ui.model.FilterOperator.EQ,
        value1: sMoveTypeVal,
        value2: ""
      });
      aFilter[4] = new sap.ui.model.Filter({
        path: "MATNR",
        operator: sap.ui.model.FilterOperator.EQ,
        value1: sMATELNUM,
        value2: ""
      });
      oModel.read("/ItemsSet", {
        async : false,
        filters: aFilter,
        success: function(oERP, oResponse){
          //check result: success
          if(oERP.results[0].MSGTY == 'S'){
            //oERP.results[0].EBELP = '00020';//Test Item Value
            //var sItemVal = oERP.results[0].EBELP;
            that.getView().byId('itemId').setEnabled(true);
            //that.getView().byId('movementType').setEnabled(true);
            var itemModel = new JSONModel(oERP);
            if(!itemChangeType){
              that.getView().byId('itemId').setModel(itemModel);
              sItemVal = that.getView().byId('itemId').getFirstItem().mProperties.text;
            }else{
              sItemVal = that.getView().byId('itemId').getSelectedItem().mProperties.text;
            }
            that.onRead(sItemVal);
          }else{
            scanTimes = 0;
            that.getView().byId('PoNumId').setValue("");
            that.getView().byId('itemId').setSelectedKey(undefined);
            that.getView().byId('itemId').setModel(new JSONModel([]));
            that.getView().byId('itemId').setEnabled(false);
            that.getView().byId('table').setModel(new JSONModel([]));
            that.getView().byId('userEntryForm').setVisible(false);
            //that.getView().byId('movementType').setEnabled(false);
            that.fShowMessageBox('error', oERP.results[0].MSGCT);
            return;
          }
        },
        error: function(oError){
          //error message output
          scanTimes = 0;
          that.getView().byId('PoNumId').setValue("");
          that.getView().byId('itemId').setSelectedKey(undefined);
          that.getView().byId('itemId').setModel(new JSONModel([]));
          that.getView().byId('itemId').setEnabled(false);
          that.getView().byId('table').setModel(new JSONModel([]));
          that.getView().byId('userEntryForm').setVisible(false);
          that.fShowMessageBox('error', oError.message);
          return;
        }
      });
        },
    /**Read oData after Scan*/
    onRead : function(sItemVal){
      var that = this;
      var oItemVal = sItemVal;
            this.fClearMessage();
            var oI18n = this.getView().getModel("i18n").getResourceBundle();
            var plant =  defaultData.WERKS;
            var location = defaultData.LGORT;
            var aFilter = [];
            aFilter[0] = new sap.ui.model.Filter({
                path : "WERKS",//Plant
                operator : sap.ui.model.FilterOperator.EQ,
                value1 : plant,
                value2 : ""
            });
          aFilter[1] = new sap.ui.model.Filter({
                path : "LGORT",//Storage Location
                operator : sap.ui.model.FilterOperator.EQ,
                value1 : location,
                value2 : ""
            });
          aFilter[2] = new sap.ui.model.Filter({
                path : "EBELN",//PO NUM
                operator : sap.ui.model.FilterOperator.EQ,
                value1 : sPoEBELN,
                value2 : ""
            });
          aFilter[3] = new sap.ui.model.Filter({
              path : "EBELP",//Item NUM
              operator : sap.ui.model.FilterOperator.EQ,
              value1 : oItemVal,
              value2 : ""
            });
          aFilter[4] = new sap.ui.model.Filter({
              path : "BWART",//Movement Type
              operator : sap.ui.model.FilterOperator.EQ,
              value1 : sMoveTypeVal,
              value2 : ""
            });
          aFilter[5] = new sap.ui.model.Filter({
        path: "MATNR",
        operator: sap.ui.model.FilterOperator.EQ,
        value1: sMATELNUM,
        value2: ""
      });
          that.fShowBusyIndicator();
          oModel.read("/GRGetSet/", {
            async : false,
                filters : aFilter,
                success : function(oERP){
                  that.fHideBusyIndicator();
                  if(oERP.results[0].MSGTY == "S"){
                    var fstSuccessMATELNUM = that.fstSuccessMATELNUM = sMATELNUM;
                    sQRNUM = oERP.results[0].QRNUM;//Qr Qty
                    sXCHPF = oERP.results[0].XCHPF;//Status Value for showing Sap Batch or not
                    sMATEDSC = oERP.results[0].MAKTX;//Material Dec.
                    sMATEQTY = oERP.results[0].MENGE;//the total qty of material
                    sDividendVal = oERP.results[0].BSTRF;//rounding value Qty
                    if(parseFloat(sQtyVal) > parseFloat(sMATEQTY)){
                      scanTimes = 0;
                      that.getView().byId('table').setModel(new JSONModel([]));
                      that.getView().byId('userEntryForm').setVisible(false);
                      that.getView().byId('tableHeader').setText(oI18n.getText("materialList"));
                      that.fShowMessageBox(
                      'error',
                      oI18n.getText("itemqtyError") + ' ' + oItemVal + ' ' +
                      oI18n.getText("totalQtyError") + '\n' +
                      oI18n.getText("totalqty") + '[' +sMATEQTY + ']' + ' ' + '<' + ' ' +
                      oI18n.getText("scaningtotalqty") + '[' + sQtyVal + ']'
                  );
                      return;
                    }
                    that._setBtnEableTafterSrch();
                    if(oERP.results[0].LGORT != "" && oERP.results[0].LGORT != null){
                      sLocation = oERP.results[0].LGORT;
                    }else{
                      sLocation = defaultData.LGORT;
                    }
                    that.getView().byId('tableHeader').setText(
                  oI18n.getText("materialList") + ' ' + '[' + oI18n.getText("materialQty") + ':' + ' ' + sMATEQTY + ']'
                );
                    that.getView().byId('userEntryForm').setVisible(true);
                    if(sXCHPF == 'X'){
                      that.getView().byId('sapbatchId').setEnabled(false);
                    }else{
                      that.getView().byId('sapbatchId').setEnabled(false);
                    }

                    oERP.results[0].MATNR = sMATELNUM;//Material Num
                    oERP.results[0].MEINS = sUnitMEINS;//Unit
                    oERP.results[0].MENGE = sQtyVal;//Material Qty
                    oERP.results[0].CHARG = sSAPBATCH;//Sap Batch
                    oERP.results[0].SGTXT = vdBatchVal;//Vender Batch
                    /* oERP.results[0].MENGE = "";
                     * oERP.results[0].SGTXT = "";
                     * if(flag){
                    }*/

                  var oTable = that.getView().byId('table');
                        var oModel = new JSONModel(oERP);
                        oTable.setModel(oModel);
                        aTable.selectAll();//Select all items in "MultiSelection" mode.
                  }else{
                    scanTimes = 0;
                    that._setBtnEableTafterClr();
                    that.getView().byId('tableHeader').setText(oI18n.getText("materialList"));
                    that.getView().byId('userEntryForm').setVisible(false);
                    that.getView().byId("table").setModel(new JSONModel([]));
                    //that.getView().setModel(new JSONModel([]));
                    that.fShowMessageBox('error', oERP.results[0].MSGCT);
                        return;
                  }
                },
                error : function(oError){
                  scanTimes = 0;
                  that.fHideBusyIndicator();
                    that._setBtnEableTafterClr();
                    that.getView().byId('tableHeader').setText(oI18n.getText("materialList"));
                    that.getView().byId('userEntryForm').setVisible(false);
                    that.getView().byId('userEntryForm').setVisible(false);
                that.getView().byId("table").setModel(new JSONModel([]));
                    //that.getView().setModel(new JSONModel([]));
                    that.fShowMessageBox('error', oError.message);
                    return;
                }
          });
    },
    /**LiveChange of Item*/
        itemChange : function(oEvent){
          scanTimes = 0;
          flag = false;
          itemChangeType = true;
          var that = this;
          var sItemVal = oEvent.getParameters().selectedItem.getText();
          that.onRead(sItemVal);
        },
        /**When Movement Type change,Table changes*/
        movementChange : function(oEvent){
          var that = this;
          //Code optimization:get the value of id in table's td when nodata in Table
          //id="__xmlview1--table-nodata-text"
          var tableNodataId = '#' + aTable.sId;
          var tdNodataSelector = $(tableNodataId + '>table>tbody>tr>td').selector;
          var noDataTdId = $(tdNodataSelector).attr('id');//end
          sMoveTypeVal = oEvent.getParameters().selectedItem.getText();
          if(sMoveTypeVal == 103){
            sMoveTypeVal = oEvent.getParameters().selectedItem.getText();
            that.getView().byId('sapbatchColumn').setHAlign('Right');
            that.getView().byId('locationColumn').setVisible(false);
            if(document.getElementById(noDataTdId)){
              document.getElementById(noDataTdId).colSpan = '7';
            }
          }else if(sMoveTypeVal == 101){
            sMoveTypeVal = oEvent.getParameters().selectedItem.getText();
            that.getView().byId('sapbatchColumn').setHAlign('Center');
            that.getView().byId('locationColumn').setVisible(true);
          }
        },
    /**Add items insert table*/
        onAddItemFuc : function(){
          var that = this;
          var oI18n = this.getView().getModel("i18n").getResourceBundle();
          var oItemVal = that.getView().byId('itemId').getSelectedItem().mProperties.text;
          var aItems;
          var oItems = [];
          var addItemModel = aTable.getModel();
          var addItemDataInsert = addItemModel.getData().results;
          aItems = aTable.getItems();
          //var qtyIdFirst = aItems[0].mAggregations.cells[3].sId;
          //this.getView().byId(qtyIdFirst).setValue(sMATEQTY);
          if(that._checkQtyTotal()){
            if(aItems.length){
              var newItem = {
                  "MATNR": sMATELNUM, //Material Num
                  "MAKTX": sMATEDSC, //Material description
                  "MEINS": sUnitMEINS,//Unit
                  "MENGE": sQtyVal, //Material Qty
                  "BSTRF": sDividendVal, //rounding value Qty
                  "QRNUM": "", //Qr code number
                  "SGTXT": vdBatchVal, //Vendor batch
                  "CHARG": sSAPBATCH, //Sap batch
                  "LGORT": sLocation //Storage Location
              };
              addItemDataInsert.push(newItem);
              addItemModel.refresh();
              //that._checkQtyPlus();
            }else{
              that.fShowMessageBox('error', oI18n.getText("nodata"));
              return;
            }
            aTable.selectAll();//Select all items in "MultiSelection" mode.
            //aTable.removeSelections(true);//Removes visible selections of the current selection mode.
          }else{
            that.fShowMessageBox(
          'error',
          oI18n.getText("itemqtyError") + ' ' + oItemVal + ' ' +
          oI18n.getText("totalQtyError") + '\n' +
          oI18n.getText("totalqty") + '[' +sMATEQTY + ']' + ' ' + '<' + ' ' +
          oI18n.getText("scaningtotalqty") + '[' + scanTotalQty + ']'
        );
            return;
          }
        },
    /**Delete table-items when selected*/
        onDeleteItems : function(){
          var that = this;
          var aSelectedItems, i, oSelected, oSelectedLists;
          var delSelectedType = [], delSelectIndex = [];
          var delItemModel = aTable.getModel();
          var delItemData = delItemModel.getData();
          var delItemDataInsert = delItemData.results;//Need change
          aSelectedItems = aTable.getSelectedItems();
          if (aSelectedItems.length) {
        for (i = 0; i < aSelectedItems.length; i++) {
          oSelected = aSelectedItems[i];
          delSelectedType[i] = oSelected.getBindingContext().getPath();
          delSelectIndex[i] = delSelectedType[i].split('/')[2];
        }
        delSelectIndex = delSelectIndex.sort(function(a, b) {
              return b - a;
          });
        for (var i = 0; i < delSelectIndex.length; i++){
          if(Number(delSelectIndex[i]) == 0 && delSelectIndex.length == 1){
            that.fShowMessageBox('error', this.getModel("i18n").getResourceBundle().getText("notAllowDel"));
            return;
          }else if(Number(delSelectIndex[i]) == 0 && delSelectIndex.length != 1){
            if(Number(delSelectIndex[i]) == 0){
              delItemDataInsert.splice(delSelectIndex[i], 0);
            }else{
              delItemDataInsert.splice(delSelectIndex[i], 1);
            }
          }else{
            delItemDataInsert.splice(delSelectIndex[i], 1);
          }
        }
        delItemModel.refresh();
        aTable.selectAll();//Select all items in "MultiSelection" mode.
      } else {
        this.fShowMessageBox('warning', this.getModel("i18n").getResourceBundle().getText("TableSelectProduct"));
        return;
      }
        },
    /**
     * Get Data of selected items
     * */
    _getSelectItemsData : function(){
      var that = this;
      var oSelectedLists = [],oSelectedListsDB = [];
      var oI18n = this.getView().getModel('i18n').getResourceBundle();
      this.emptyCheckPoItem();
      if(that.emptyCheckPoItem()){
        that.emptyCheckUserEntry();
      }
      if(that.emptyCheckUserEntry()){
        var aSelectedItems = this.getView().byId("table").getSelectedItems();
        if(aSelectedItems.length > 0){
          if(that.emptyCheckTableInput()){
            flag = true;
            for(var i in aSelectedItems){
              oSelectedLists[i] = aSelectedItems[i].getBindingContext().getProperty();
              oSelectedListsDB[i] = {
                EBELN:that.getView().byId('PoNumId').getValue(),
                EBELP:that.getView().byId('itemId').getSelectedItem().mProperties.text,
                BWART:sMoveTypeVal,
                WERKS:defaultData.WERKS,
                BUDAT:that.getView().byId('postingDate').getValue(),
                XBLNR:that.getView().byId('deliveryNoteId').getValue(),
                MATNR:oSelectedLists[i].MATNR,
                MAKTX:oSelectedLists[i].MAKTX,
                MENGE:oSelectedLists[i].MENGE,
                MEINS:oSelectedLists[i].MEINS,
                LGORT:oSelectedLists[i].LGORT,
                CHARG:oSelectedLists[i].CHARG,
                SGTXT:oSelectedLists[i].SGTXT,
                QRNUM:oSelectedLists[i].QRNUM,
                NAME:defaultData.NAME,
                BSTRF:oSelectedLists[i].BSTRF
              }
            }
            navModel = new JSONModel(oSelectedListsDB);
          }
        }else{
          flag = false;
          this.fShowMessageBox('warning', oI18n.getText("TableSelectProduct"));
          return;
        }
      }else{
        flag = false;
        return;
      }
    },
    /**
     * Nav to confirmed page
     * */
    onNavConfirmPage : function(){
      this._getSelectItemsData();
      if(flag){
        var oRouter = UIComponent.getRouterFor(this);
        this.getOwnerComponent().setModel(navModel, 'navModel');
//        oRouter.navTo('mabatchconfirmed',{},false);
        oRouter.navTo('mabatchconfirmed',{});
      }else{
        return;
      }
    },
    /**
     * Change ValueState of Delivery Note when the value be change
     **/
        _deliveryNtChange : function(oEvent){
          this.getView().byId('deliveryNoteId').setValueState("None");
        },
        /**Material Qty be changed when input is changed*/
        _maQtyAutoChange : function(oEvent){
          var oI18n = this.getView().getModel("i18n").getResourceBundle();
          var that = this;
          var oData = this.getView().getModel('data');
          var allItems = aTable.getItems();
          var qtyInputItems = aTable.getModel();
          var qtyData = qtyInputItems.getData();
          var eventSource = oEvent.getSource();
          this.getView().byId(eventSource.sId).setValueState("None");
          var QtyCurrentVal = oEvent.getParameters().value;
          var currentId = eventSource.sId;
          if(QtyCurrentVal.toString().indexOf(".") > -1){
            if(QtyCurrentVal.toString().split(".")[1].length > 3){
                that.getView().byId(eventSource.sId).setValueState("Error");
                that.getView().byId(eventSource.sId).setValueStateText(oI18n.getText("checkByteText"));
                that.getView().byId(eventSource.sId).focus();
                flag = false;
                return false;
              }else{
                flag = true;
              }
          }else{
            flag = true;
          }
          var QtyIds = [], QrQtyIds = [];
          var QtyVals = [], QRQtyVals = [], qrNum = [];
          if(sMoveTypeVal == 101){
            for(var i = 0; i < allItems.length; i++){
              QtyIds[i] = allItems[i].mAggregations.cells[3].sId;
              QrQtyIds[i] = allItems[i].mAggregations.cells[5].sId;
              QtyVals[i] = that.getView().byId(QtyIds[i]).getValue();
              QRQtyVals[i] = that.getView().byId(QrQtyIds[i]).getValue();
              if(currentId == QtyIds[i]){
                qrNum[i] = Math.ceil(Number(QtyVals[i]/sDividendVal));
                that.getView().byId(QrQtyIds[i]).setValue(qrNum[i]);
              }
            }
          }
          if(flag){
            this._checkQtyPlus();
          }
        },
        /**Check Qty-plus whether greater than total Qty*/
        _checkQtyPlus : function(){
          var that = this;
          var oI18n = this.getView().getModel("i18n").getResourceBundle();
          var oItemVal = that.getView().byId('itemId').getSelectedItem().mProperties.text;
          var QtyIds = [];
          var itemsQtyVals = [];
          var tableItems = aTable.getItems();
          var QtyPlusNoFirst = 0;
          var QtyPlus = 0;
          for(var i = 0; i < tableItems.length; i++){
            var singleItem = tableItems[i];
            QtyIds[i] = singleItem.mAggregations.cells[3].sId;
            that.getView().byId(QtyIds[i]).setValueState("None");
            itemsQtyVals[i] = that.getView().byId(QtyIds[i]).getValue();
          }
          for(var j = 0; j < itemsQtyVals.length; j++){
            QtyPlus += Number(itemsQtyVals[j]);
          }
          if(QtyPlus > parseFloat(sMATEQTY)){
            this.getView().byId(QtyIds[tableItems.length - 1]).setValueStateText(undefined);
            this.getView().byId(QtyIds[tableItems.length - 1]).setValueState("Error");
            this.getView().byId(QtyIds[tableItems.length - 1]).focus();
            that.fShowMessageBox(
          'error',
          oI18n.getText("itemqtyError") + ' ' + oItemVal + ' ' +
          oI18n.getText("totalQtyError") + '\n' +
          oI18n.getText("totalqty") + '[' +sMATEQTY + ']' + ' ' + '<' + ' ' +
          oI18n.getText("scaningtotalqty") + '[' + QtyPlus + ']'
        );
            flag = false;
            return false;
          }else{
            flag = true;
            return true;
          }
        },
        /**After scan, before AddItem, check the qty of in table plus qty from scaning*/
        _checkQtyTotal : function(){
          var that = this;
          var oI18n = this.getView().getModel("i18n").getResourceBundle();
          var QtyIds = [];
          var itemsQtyVals = [];
          var tableItems = aTable.getItems();
          var QtyPlusNoFirst = 0;
          var QtyPlus = 0;
          for(var i = 0; i < tableItems.length; i++){
            var singleItem = tableItems[i];
            QtyIds[i] = singleItem.mAggregations.cells[3].sId;
            that.getView().byId(QtyIds[i]).setValueState("None");
            itemsQtyVals[i] = that.getView().byId(QtyIds[i]).getValue();
          }
          for(var j = 0; j < itemsQtyVals.length; j++){
            QtyPlus += Number(itemsQtyVals[j]);
          }
          scanTotalQty = QtyPlus + parseFloat(sQtyVal);
          if((QtyPlus + parseFloat(sQtyVal)) > parseFloat(sMATEQTY)){
            return false;
          }else{
            return true;
          }
        },
        /**
         * When the second scaning,
         * Check the material number of qr code whether match
         * the first scaning successfully
         * */
        _checkMaNum : function(){
          var that = this;
          var checkMATELNUM = that.fstSuccessMATELNUM;
          if(checkMATELNUM == sMATELNUM){
            return true;
          }else{
            return false;
          }
        },
        /**Check Vender Batch whether repeat*/
        _checkVdBatch : function(){
          var that = this;
          var oI18n = this.getView().getModel("i18n").getResourceBundle();
          var batchIds = [], itemsbatchVals = [];
          var tableItems = aTable.getItems();
          for(var i = 0; i < tableItems.length; i++){
            var singleItem = tableItems[i];
            batchIds[i] = singleItem.mAggregations.cells[6].sId;
            that.getView().byId(batchIds[i]).setValueState("None");
            itemsbatchVals[i] = that.getView().byId(batchIds[i]).getValue();
          }
          var vdBatchStr = itemsbatchVals.join();
          if(vdBatchStr.indexOf(vdBatchVal) == -1){
            return false;
          }else{
            return true;
          }
        },
        /**check filter-key:PO NUM and Item empty*/
        emptyCheckPoItem : function(){
          var poElm = this.getView().byId('PoNumId'),
            itemElm = this.getView().byId('itemId'),
            PoVal = poElm.getValue(),
            itemElmVal = itemElm.getSelectedItem().mProperties.text;
          poElm.setValueState("None");
          //itemElm.setValueState("None");
          if(PoVal == null || $.trim(PoVal) == ""){
            poElm.setValueState("Error");
            poElm.focus();
            flag = false;
            return false;
          }
          if(itemElmVal == null || $.trim(itemElmVal) == ""){
            //itemElm.setValueState("Error");
            //itemElm.focus();
            flag = false;
            return false;
          }
          flag = true;
        return true;
        },
        /**User Entry part check empty*/
        emptyCheckUserEntry : function(){
          var postDateElm = this.getView().byId('postingDate'),
          moveTypeElm = this.getView().byId('movementType'),
          noteElm = this.getView().byId('deliveryNoteId'),
          postDateVal = postDateElm.getDateValue(),
            noteElmVal = noteElm.getValue();
        postDateElm.setValueState("None");
        //moveTypeElm.setValueState("None");
        noteElm.setValueState("None");
        if($.trim(postDateVal) == "" || postDateVal == null){
          postDateElm.setValueState("Error");
          postDateElm.focus();
          flag = false;
            return false;
        }
        if($.trim(noteElmVal) == "" || noteElmVal == null){
          noteElm.setValueState("Error");
          noteElm.focus();
          flag = false;
            return false;
        }
        flag = true;
        return true;
        },
        /**check rounding value Qty empty or eq zero*/
        _roundingQtyChange: function(oEvent){
          var that = this;
          var oI18n = this.getView().getModel("i18n").getResourceBundle();
          var evtInputVal = oEvent.mParameters.value;
          if(parseFloat(evtInputVal) <= 0 || $.trim(evtInputVal) == "" || evtInputVal == null){
            this.getView().byId(oEvent.mParameters.id).setValueStateText(undefined);
            this.getView().byId(oEvent.mParameters.id).setValueState("Error");
            this.getView().byId(oEvent.mParameters.id).focus();
            flag = false;
            return false;
          }else{
            this.getView().byId(oEvent.mParameters.id).setValueState("None");
          }
        },
        /**Empty checking of input of Table items when Save*/
        emptyCheckTableInput : function(){
          var that = this;
          var oI18n = this.getView().getModel("i18n").getResourceBundle();
          var aSelectedItems, oSelected, oSelectedLists;
          var QtyIds = [], RoundingQtyIds = [], QrQtyIds = [], BatchIds = [], SpBatchIds = [],
            LocationIds = [];
          var itemsQtyVals = [], itemsRoundingQtyVals = [], itemsQrQtyVals = [], itemsBatchVals = [],
            itemsSpBatchVals = [], itemsLocationVals = [];
          aSelectedItems = aTable.getSelectedItems();
          for(var i = 0; i < aSelectedItems.length; i++){
            var singleItem = aSelectedItems[i];
            oSelectedLists = singleItem.getBindingContext().getProperty();
            QtyIds[i] = singleItem.mAggregations.cells[3].sId;
            RoundingQtyIds[i] = singleItem.mAggregations.cells[4].sId;
            QrQtyIds[i] = singleItem.mAggregations.cells[5].sId;
            BatchIds[i] = singleItem.mAggregations.cells[6].sId;
            SpBatchIds[i] = singleItem.mAggregations.cells[7].sId;
            // LocationIds[i] = singleItem.mAggregations.cells[8].sId;
            that.getView().byId(QtyIds[i]).setValueState("None");
            that.getView().byId(RoundingQtyIds[i]).setValueState("None");
            that.getView().byId(QrQtyIds[i]).setValueState("None");
            that.getView().byId(BatchIds[i]).setValueState("None");
            that.getView().byId(SpBatchIds[i]).setValueState("None");
            // that.getView().byId(LocationIds[i]).setValueState("None");
            itemsQtyVals[i] = that.getView().byId(QtyIds[i]).getValue();
            itemsRoundingQtyVals[i] = that.getView().byId(RoundingQtyIds[i]).getValue();
            itemsQrQtyVals[i] = that.getView().byId(QrQtyIds[i]).getValue();
            itemsBatchVals[i] = that.getView().byId(BatchIds[i]).getValue();
            itemsSpBatchVals[i] = that.getView().byId(SpBatchIds[i]).getValue();
            // itemsLocationVals[i] = that.getView().byId(LocationIds[i]).getValue();
            if($.trim(itemsQtyVals[i]) == "" || itemsQtyVals[i] == null || itemsQtyVals[i] == 0){
            that.getView().byId(QtyIds[i]).setValueState("Error");
            that.getView().byId(QtyIds[i]).focus();
              flag = false;
              return false;
            }
            if(itemsQtyVals[i] != "" && itemsQtyVals[i] != null && itemsQtyVals[i] != 0){
              if(itemsQtyVals[i].toString().indexOf(".") > -1){
                    if(itemsQtyVals[i].toString().split(".")[1].length > 3){
                        that.getView().byId(QtyIds[i]).setValueState("Error");
                        that.getView().byId(QtyIds[i]).focus();
                        flag = false;
                        return false;
                      }
                  }
            }
            if($.trim(itemsBatchVals[i]) == "" || itemsBatchVals[i] == null){
              that.getView().byId(BatchIds[i]).setValueState("Error");
              that.getView().byId(BatchIds[i]).focus();
              //that.fShowMessageBox('error', oI18n.getText("batchEmpty"));
              flag = false;
              return false;
            }
            /*if(sMoveTypeVal == '103'){
              if($.trim(itemsRoundingQtyVals[i]) == "" || itemsRoundingQtyVals[i] == null ||
              parseFloat(itemsRoundingQtyVals[i]) <= 0){
                that.getView().byId(RoundingQtyIds[i]).setValueState("Error");
                  that.getView().byId(RoundingQtyIds[i]).focus();
                  flag = false;
                  return false;
              }
            }*/
            if(sMoveTypeVal == '101'){
            //   if($.trim(itemsLocationVals[i]) == "" || itemsLocationVals[i] == null){
            //     that.getView().byId(LocationIds[i]).setValueState("Error");
            //     that.getView().byId(LocationIds[i]).focus();
            //     flag = false;
            //     return false;
            //   }
            }
          }
          flag = true;
        return true;
        },
        /**Empty checking of Dialog that set default value*/
        emptyCheckSet : function() {
            var oplantelm = sap.ui.getCore().byId('dialogPlantNId');
            var omovementelm = sap.ui.getCore().byId("dialogLocationNId");
            oplantelm.setValueState("None");
            omovementelm.setValueState("None");
            var splantval = oplantelm.getValue();
            var smovementval = omovementelm.getValue();
            if (splantval == null || $.trim(splantval) == "") {
              oplantelm.setValueState("Error");
              oplantelm.focus();
                return false;
            }
            if (smovementval == null || $.trim(smovementval) == "") {
              omovementelm.setValueState("Error");
              omovementelm.focus();
                return false;
            }
            return true;
        },
        /**Clear the date of the datePicker and other*/
    fClearMessage : function() {
            this.getView().byId('PoNumId').setValueState("None");
            this.getView().byId('postingDate').setValueState("None");
            this.getView().byId('deliveryNoteId').setValueState("None");
        },
    /**Rest the filter part data*/
    onClear : function(){
      scanTimes = 0;
      flag = false;
      itemChangeType = false;
      var oI18n = this.getView().getModel("i18n").getResourceBundle();
      var that = this;
      this.fClearMessage();
      var HH = sap.ui.core.format.DateFormat.getDateInstance({
                pattern : "HH"
            });
            var nowDate = new Date();
            var oDate = HH.format(nowDate);
            if (oDate <= 8) {
                nowDate.setDate(nowDate.getDate() - 1);
            }
            this.getView().byId("postingDate").setDateValue(nowDate);
            this.getView().byId("PoNumId").setValue("");
            this.getView().byId('itemId').setSelectedKey(undefined);
            this.getView().byId('itemId').setModel(new JSONModel([]));
            this.getView().byId('itemId').setEnabled(false);
            this.getView().byId("deliveryNoteId").setValue("");
            this._setBtnEableTafterClr();
            this.getView().byId('userEntryForm').setVisible(false);
            this.getView().byId('tableHeader').setText(oI18n.getText("materialList"));
            this.getView().byId("table").setModel(new JSONModel([]));
            this.getView().byId('movementType').setSelectedKey(undefined);
            //this.getView().byId('movementType').setEnabled(false);
    },
        /**Control function of Default value of DatePicker display*/
    fSetDate: function(){
            var dDate = new Date();
            if(dDate.getHours() < 8){
                dDate.setDate(dDate.getDate() - 1);
                this.getView().byId('postingDate').setDateValue(dDate);
            }
            else{
                this.getView().byId('postingDate').setDateValue(dDate);
            }
        },
        /**confirm, alert, error, information, warning, success*/
        fShowMessageBox : function(type, content) {
            var oI18n = this.getView().getModel("i18n").getResourceBundle();
            var bCompact = !!this.getView().$().closest(".sapUiSizeCozy").length;
            var Options = null;
            if (type == 'none') {
                Options = {
                    icon : sap.m.MessageBox.Icon.NONE,
                    title : oI18n.getText("noneBox"),
                    actions : sap.m.MessageBox.Action.OK,
                    onClose : null,
                    styleClass : bCompact ? "sapUiSizeCozy" : "",
                    initialFocus : null,
                    textDirection : sap.ui.core.TextDirection.Inherit
                };
            } else if (type == 'question') {
                Options = {
                    icon : sap.m.MessageBox.Icon.QUESTION,
                    title : oI18n.getText("questionBox"),
                    actions : sap.m.MessageBox.Action.OK,
                    onClose : null,
                    styleClass : bCompact ? "sapUiSizeCozy" : "",
                    initialFocus : null,
                    textDirection : sap.ui.core.TextDirection.Inherit
                };
            } else if (type == 'error') {
                Options = {
                    icon : sap.m.MessageBox.Icon.ERROR,
                    title : oI18n.getText("boxError"),
                    actions : sap.m.MessageBox.Action.OK,
                    onClose : null,
                    styleClass : bCompact ? "sapUiSizeCozy" : "",
                    initialFocus : null,
                    textDirection : sap.ui.core.TextDirection.Inherit
                };
            } else if (type == 'information') {
                Options = {
                    icon : sap.m.MessageBox.Icon.INFORMATION,
                    title : oI18n.getText("informationBox"),
                    actions : sap.m.MessageBox.Action.OK,
                    onClose : null,
                    styleClass : bCompact ? "sapUiSizeCozy" : "",
                    initialFocus : null,
                    textDirection : sap.ui.core.TextDirection.Inherit
                };
            } else if (type == 'warning') {
                Options = {
                    icon : sap.m.MessageBox.Icon.WARNING,
                    title : oI18n.getText("WARNING"),
                    actions : sap.m.MessageBox.Action.OK,
                    onClose : null,
                    styleClass : bCompact ? "sapUiSizeCozy" : "",
                    initialFocus : null,
                    textDirection : sap.ui.core.TextDirection.Inherit
                };
            } else if (type == 'success') {
                Options = {
                    icon : sap.m.MessageBox.Icon.SUCCESS,
                    title : oI18n.getText("boxSuccess"),
                    actions : sap.m.MessageBox.Action.OK,
                    onClose : null,
                    styleClass : bCompact ? "sapUiSizeCozy" : "",
                    initialFocus : null,
                    textDirection : sap.ui.core.TextDirection.Inherit
                };
            }
            sap.m.MessageBox.show(content, Options);
        },
        /**Set enabled be true of buttons() when search data not empty*/
        _setBtnEableTafterSrch : function(){
      this.getView().byId('rejectBtid').setEnabled(true);
      this.getView().byId('confirmBtid').setEnabled(true);
        },
        /**Set enabled be false of buttons when onClear be excuted or search data empty*/
        _setBtnEableTafterClr : function(){
      this.getView().byId('rejectBtid').setEnabled(false);
      this.getView().byId('confirmBtid').setEnabled(false);
        },
        /**Set enabled be false of buttons except setting when default value is empty*/
    _setBtnEnableF : function(){
      this._setBtnEableTafterClr();
      this.getView().byId('scanId').setEnabled(false);
    },
    /**Set enabled be ture of buttons when default value is seted*/
    _setBtnEnableT : function(){
      //this._setBtnEableTafterSrch();
      this.getView().byId('scanId').setEnabled(true);
    },
    /**Set enabled be false of input when default value is empty*/
    _setInputEnableF : function(){
      this.getView().byId('itemId').setEnabled(false);
      this.getView().byId('deliveryNoteId').setEnabled(false);
    },
    /**Set enabled be true of input when default value is seted*/
    _setInputEnableT : function(){
      this.getView().byId('itemId').setEnabled(true);
      this.getView().byId('deliveryNoteId').setEnabled(true);
    },
        /**BusyDialog control*/
        fHideBusyIndicator : function() {
            var oDialog = sap.ui.getCore().byId('BusyDialog');
            if (oDialog) {
                oDialog.close();
            }
        },
        fShowBusyIndicator : function() {
            var oDialog = sap.ui.getCore().byId('BusyDialog');
            if (!oDialog) {
                oDialog = new sap.m.BusyDialog('BusyDialog');
            }
            oDialog.open();
        }
    });
});