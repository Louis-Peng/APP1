sap.ui.define([
	"ns/delivery/controller/BaseController",
	"sap/ui/core/routing/History",
	"sap/ui/model/odata/v2/ODataModel",
	"sap/ui/core/UIComponent",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ui/core/routing/Route",
	"sap/ui/model/json/JSONModel",
	"sap/m/MessageBox",
	"sap/m/Text",
	"sap/m/TextArea",
	"sap/m/Button"
],function(
	BaseController,
	History,
	ODataModel,
	UIComponent,
	Filter,
	FilterOperator,
	Route,
	JSONModel,
	MessageBox,
	Text,
	TextArea,
	Button){
	"use strict";
	var bUpdate = false;
	var _navModelHome, newDataModel;
	var sPlant,sPrinterName,sPoNum,sItemNum,sMoveTypeVal,sDNVal,sPostDate;
//	var oModel = new ODataModel("proxy/http/160.21.205.176:8001/sap/opu/odata/SAP/ZGTMMF100_SRV/?sap-client=331");
	var oModel = new ODataModel("/nsdelivery/sap/opu/odata/SAP/ZGTMMF100_SRV/");
	return BaseController.extend('ns.delivery.controller.MaBatchConfirmed', {
		/**
		 * APP Opened Initialization at First Time
		 * Then into Router
		 */
         	onInit: function () {
            this.getRouter().getRoute("mabatchconfirmed").attachPatternMatched(this.fRouteMatched, this);
    	},
    	/**Router function: when nav this page,
    	 * receive the first page DB
    	 * */
    	fRouteMatched : function(){
    		var that = this;
    		// Get Model
            var navModelHome = this.getOwnerComponent().getModel('navModel');
            var osData = this.osData = navModelHome.getData();
            _navModelHome = new JSONModel({"results":osData});
            sPlant = osData[0].WERKS;
            sPrinterName = osData[0].NAME;
            sPoNum = osData[0].EBELN;
            sItemNum = osData[0].EBELP;
            sMoveTypeVal = osData[0].BWART;
            sPostDate = osData[0].BUDAT;
            sDNVal = osData[0].XBLNR;
            this._combineDBModel(osData);
            this._setTBModel();
    	},
    	/**
    	 * Combine the data of Vender Batch be equal
    	 * */
    	_combineDBModel : function(arrObj){
    		var oldArrlist = arrObj;
    		var sEBELN = [],sEBELP = [],sBWART = [],sWERKS = [],sBUDAT = [],sXBLNR = [],
    			sMATNR = [],sMAKTX = [],sMENGE = [],sMEINS = [],sLGORT = [],sCHARG = [],
    			sSGTXT = [],sQRNUM = [],sNAME = [],sBSTRF = [];
    		
    		$(oldArrlist).each(function(idx,data){
    			if($.inArray(data.SGTXT,sSGTXT)<0){
    				sSGTXT.push(data.SGTXT);
    				sEBELN.push(data.EBELN);
    				sEBELP.push(data.EBELP);
    				sBWART.push(data.BWART);
    				sWERKS.push(data.WERKS);
    				sBUDAT.push(data.BUDAT);
    				sXBLNR.push(data.XBLNR);
    				sMATNR.push(data.MATNR);
    				sMAKTX.push(data.MAKTX);
    				sMENGE.push(0);
    				sMEINS.push(data.MEINS);
    				sLGORT.push(data.LGORT);
    				sCHARG.push(data.CHARG);
    				sQRNUM.push(data.QRNUM);
    				sNAME.push(data.NAME);
    				sBSTRF.push(data.BSTRF);
    			}
    		});
    		$(sSGTXT).each(function(idx,SGTXT){
    			$(oldArrlist).each(function(subidx,data){
    				if(SGTXT == data.SGTXT){
    					sMENGE[idx] += parseFloat(data.MENGE)
    				}
    			});
    		});
    		var newDataList = [];
    		$(sSGTXT).each(function(idx,SGTXT){
    			var item={};
    			item.SGTXT=SGTXT;
    			item.EBELN=sEBELN[idx];
    			item.EBELP=sEBELP[idx];
    			item.BWART=sBWART[idx];
    			item.WERKS=sWERKS[idx];
    			item.BUDAT=sBUDAT[idx];
    			item.XBLNR=sXBLNR[idx];
    			item.MATNR=sMATNR[idx];
    			item.MAKTX=sMAKTX[idx];
    			item.MENGE=sMENGE[idx];
    			item.MEINS=sMEINS[idx];
    			item.LGORT=sLGORT[idx];
    			item.CHARG=sCHARG[idx];
    			item.QRNUM=sQRNUM[idx];
    			item.NAME=sNAME[idx];
    			item.BSTRF=sBSTRF[idx];
    			newDataList.push(item);
    		});
    		newDataModel = new JSONModel({"results":newDataList});
    	},
    	/**
    	 * Set Model for Table
    	 * */
    	_setTBModel : function(){
    		var that = this;
    		var oI18n = this.getView().getModel("i18n").getResourceBundle();
    		this.getView().byId('page').setTitle(oI18n.getText('material') + ' : ' + this.osData[0].MATNR + ' ' + this.osData[0].MAKTX);
    		this.getView().byId('table').setModel(newDataModel);
    		this.getView().byId('tableHeader').setText(oI18n.getText('poNum') + ' : ' + sPoNum);
    		this.getView().byId('tableHeaderItem').setText(oI18n.getText('itemNum') + ' : ' + sItemNum);
    	},
    	/**
    	 * Nav back and do not save
    	 * */
    	_onNavBack : function(){
    		bUpdate = false;
            var bUpdateModel = new JSONModel({
                bUpdate: bUpdate
            });
            this.getOwnerComponent().setModel(bUpdateModel, 'bUpdateModelmmf110');
            history.go(-1);
    	},
    	/**
    	 * After save successed, nav back previous page and update the data of page
    	 * */
    	createRefreshModel: function(){
			bUpdate = true;
            var bUpdateModel = new JSONModel({
                bUpdate: bUpdate
            });
            this.getOwnerComponent().setModel(bUpdateModel, 'bUpdateModelmmf110');
            history.go(-1);
		},
    	onRefresh: function() {
        	this.getView().byId("table").setModel(new JSONModel([]));
		},
    	/**
    	 * Save the data
    	 * */
		onSave : function(){
			var that = this;
			var symbol_f = '@$&', symbol_i = '^^';
        	var SelectedItemStr, submitUrl;
        	var aprSelectedItems = [];
			for (var i = 0; i < that.osData.length; i++) {
				aprSelectedItems[i] = sPoNum + symbol_f + sItemNum + symbol_f + sMoveTypeVal + symbol_f
					+ sPlant + symbol_f + sPostDate + symbol_f + sDNVal + symbol_f
					+ this.osData[i].MATNR + symbol_f + this.osData[i].MAKTX + symbol_f + this.osData[i].MENGE + symbol_f
					+ this.osData[i].MEINS + symbol_f + this.osData[i].LGORT + symbol_f + this.osData[i].CHARG + symbol_f
					+ this.osData[i].SGTXT + symbol_f + this.osData[i].QRNUM + symbol_f + sPrinterName + symbol_f + this.osData[i].BSTRF;
			}
			submitUrl = '/GRCreateSet/';
			SelectedItemStr = symbol_i + aprSelectedItems.join(symbol_i);
			this.warningMsgDialog("WARNING","ConfirmText",SelectedItemStr,submitUrl);
        },
        /**
		 * Warning before operation of reject,approve,cancel approved.
		 * @public
		 * @param sMsgTitle : Title of Dialog
				  sMsg : Warning content
				  itemsMsg : data send to DB
				  sUrl : DB's url
		 */
        warningMsgDialog : function(sMsgTitle,sMsg,itemsMsg,sUrl){
        	var that = this;
			var oI18n = this.getView().getModel('i18n').getResourceBundle();
			var dialog = new sap.m.Dialog({
				title: oI18n.getText(sMsgTitle),
				type: 'Message',
				state: 'Warning',
				content: new sap.m.Text({
					text: oI18n.getText(sMsg),
				}),
				beginButton: new sap.m.Button({
					text: oI18n.getText("ConfirmTitle"),
					type: 'Reject',
					press: function () {
						var oTimeStap = new Date();
						var sData = {
							'LINE':itemsMsg,
							'EBELN':sPoNum,
							'EBELP':sItemNum,
							'BWART':sMoveTypeVal,
							'XBLNR':sDNVal,
							'SCAN':'X'
						};
						that.fShowBusyIndicator();
						oModel.create(sUrl + '?' + oTimeStap, sData,{
							async : false,
		                    success: function(oData){
		                      that.fHideBusyIndicator();
		                  	  if(oData.MSGTY == "S"){
		                  		  //that.fShowMessageBox('success', oData.MSGCT);
		                  		  that.onRefresh();
		                  		  var osuccessMsgDialog = new sap.m.Dialog({
		                  			  title: oI18n.getText('boxSuccess'),
		                  			  type: 'Message',
		                  			  state: 'Success',
		                  			  content: [ new sap.m.Label({
		                  				  text: oData.MSGCT
		                  			  })]
		                  		  });
		                  		  osuccessMsgDialog.open();
		                  		  osuccessMsgDialog.addButton(new sap.m.Button({
		                  			  text : oI18n.getText('okBtn'),
		                  			  press : function() {
		                  				  osuccessMsgDialog.close();
		                  				  that.createRefreshModel();
		                  			  }
		                  		  }));
		                  	  }else{// if(oData.MSGTY == "E")
		                  		  //that.fShowMessageBox('error', oData.MSGCT);
		                  		  var osuccessMsgDialog = new sap.m.Dialog({
		                  			  title: oI18n.getText('boxError'),
		                  			  type: 'Message',
		                  			  state: 'Error',
		                  			  content: [ new sap.m.Label({
		                  				  text: oData.MSGCT
		                  			  })]
		                  		  });
		                  		  osuccessMsgDialog.open();
		                  		  osuccessMsgDialog.addButton(new sap.m.Button({
		                  			  text : oI18n.getText('okBtn'),
		                  			  press : function() {
		                  				  osuccessMsgDialog.close();
		                  				  that._onNavBack();
		                  			  }
		                  		  }));
		                  	  }
		                    },
		                    error: function(oError){
		                    	//that.fShowMessageBox('error', oError.message);
								var osuccessMsgDialog = new sap.m.Dialog({
									title: oI18n.getText('boxError'),
									type: 'Message',
									state: 'Error',
									content: [ new sap.m.Label({
										text: oError.message
									})]
								});
								osuccessMsgDialog.open();
								osuccessMsgDialog.addButton(new sap.m.Button({
									text : oI18n.getText('okBtn'),
									press : function() {
										osuccessMsgDialog.close();
										that._onNavBack();
									}
								}));
		                    }
						});
						dialog.close();
					}
				}),
				endButton: new sap.m.Button({
					text: oI18n.getText("cancelBtn"),
					press: function () {
						dialog.close();
					}
				}),
				afterClose: function() {
					//The delete operation of after confirm
					dialog.destroy();
				}
			});
			dialog.open();
		},
		// confirm, alert, error, information, warning, success
        fShowMessageBox : function(type, content) {
            var oI18n = this.getView().getModel("i18n").getResourceBundle();
            var bCompact = !!this.getView().$().closest(".sapUiSizeCozy").length;
            var Options = null;
            if (type == 'none') {
                Options = {
                    icon : sap.m.MessageBox.Icon.NONE,
                    title : oI18n.getText("noneBox"),
                    actions : sap.m.MessageBox.Action.OK,
                    onClose : null,
                    styleClass : bCompact ? "sapUiSizeCozy" : "",
                    initialFocus : null,
                    textDirection : sap.ui.core.TextDirection.Inherit
                };
            } else if (type == 'question') {
                Options = {
                    icon : sap.m.MessageBox.Icon.QUESTION,
                    title : oI18n.getText("questionBox"),
                    actions : sap.m.MessageBox.Action.OK,
                    onClose : null,
                    styleClass : bCompact ? "sapUiSizeCozy" : "",
                    initialFocus : null,
                    textDirection : sap.ui.core.TextDirection.Inherit
                };
            } else if (type == 'error') {
                Options = {
                    icon : sap.m.MessageBox.Icon.ERROR,
                    title : oI18n.getText("boxError"),
                    actions : sap.m.MessageBox.Action.OK,
                    onClose : null,
                    styleClass : bCompact ? "sapUiSizeCozy" : "",
                    initialFocus : null,
                    textDirection : sap.ui.core.TextDirection.Inherit
                };
            } else if (type == 'information') {
                Options = {
                    icon : sap.m.MessageBox.Icon.INFORMATION,
                    title : oI18n.getText("informationBox"),
                    actions : sap.m.MessageBox.Action.OK,
                    onClose : null,
                    styleClass : bCompact ? "sapUiSizeCozy" : "",
                    initialFocus : null,
                    textDirection : sap.ui.core.TextDirection.Inherit
                };
            } else if (type == 'warning') {
                Options = {
                    icon : sap.m.MessageBox.Icon.WARNING,
                    title : oI18n.getText("WARNING"),
                    actions : sap.m.MessageBox.Action.OK,
                    onClose : null,
                    styleClass : bCompact ? "sapUiSizeCozy" : "",
                    initialFocus : null,
                    textDirection : sap.ui.core.TextDirection.Inherit
                };
            } else if (type == 'success') {
                Options = {
                    icon : sap.m.MessageBox.Icon.SUCCESS,
                    title : oI18n.getText("boxSuccess"),
                    actions : sap.m.MessageBox.Action.OK,
                    onClose : null,
                    styleClass : bCompact ? "sapUiSizeCozy" : "",
                    initialFocus : null,
                    textDirection : sap.ui.core.TextDirection.Inherit
                };
            }
            sap.m.MessageBox.show(content, Options);
        },
        //BusyDialog control
        fHideBusyIndicator : function() {
            var oDialog = sap.ui.getCore().byId('BusyDialog');
            if (oDialog) {
                oDialog.close();
            }
        },
        fShowBusyIndicator : function() {
            var oDialog = sap.ui.getCore().byId('BusyDialog');
            if (!oDialog) {
                oDialog = new sap.m.BusyDialog('BusyDialog');
            }
            oDialog.open();
        }
	});
});