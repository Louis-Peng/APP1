sap.ui.define([
   	"sap/ui/core/mvc/Controller",
   	"sap/ui/core/routing/History",
   	'sap/ui/model/resource/ResourceModel'], function(
	Controller,
	History,
	ResourceModel){
   	"use strict";
    return Controller.extend("ns.delivery.controller.BaseController", {
        getRouter : function() {
            return sap.ui.core.UIComponent.getRouterFor(this);
        },
        /**
		 * Convenience method for getting the view model by name.
		 * @public
		 * @param {string} [sName] the model name
		 * @returns {sap.ui.model.Model} the model instance
		 */
		getModel: function(sName) {
			return this.getView().getModel(sName);
		},
        onNavBack : function(oEvent) {
        	//alert("RUN");
            var oHistory, sPreviousHash;
            oHistory = History.getInstance();
            sPreviousHash = oHistory.getPreviousHash();
            window.history.go(-1);
        }
   	});
});
