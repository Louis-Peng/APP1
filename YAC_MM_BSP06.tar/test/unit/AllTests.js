sap.ui.define([
	"ns/inventory/test/unit/controller/App.controller"
], function () {
	"use strict";
});
