sap.ui.define(['jquery.sap.global'],
    function(jQuery) {
    "use strict";

    // Very simple page-context personalization
    // persistence service, not for productive use!
    var PersoService = {

        oData : {
            _persoSchemaVersion: "1.0",
            aColumns : [
                {
                    id: "colsetting-tableid-lineid",
                    order: 0,
                    text: "{i18n>Picking.Line}",
                    visible: true
                },
                {
                    id: "colsetting-tableid-modelid",
                    order: 1,
                    text: "{i18n>Picking.Model}",
                    visible: true
                },
                {
                    id: "colsetting-tableid-partid",
                    order: 2,
                    text: "{i18n>Picking.Parts}",
                    visible: true
                },
                {
                    id: "colsetting-tableid-qtyid",
                    order: 3,
                    text: "{i18n>Picking.Qty}",
                    visible: true
                },
                {
                    id: "colsetting-tableid-pickid",
                    order: 4,
                    text: "{i18n>Picking.pick}",
                    visible: true
                },
                {
                    id: "colsetting-tableid-binid",
                    order: 5,
                    text: "{i18n>Picking.Bin}",
                    visible: true
                },
                {
                    id: "colsetting-tableid-batchid",
                    order: 6,
                    text: "{i18n>Picking.Batch}",
                    visible: true
                },
                {
                    id: "colsetting-tableid-grid",
                    order: 7,
                    text: "{i18n>Picking.GRDate}",
                    visible: true
                }
            ]
        },

        getPersData : function () {
            var oDeferred = new jQuery.Deferred();
            if (!this._oBundle) {
                this._oBundle = this.oData;
            }
            var oBundle = this._oBundle;
            oDeferred.resolve(oBundle);
            return oDeferred.promise();
        },

        setPersData : function (oBundle) {
            var oDeferred = new jQuery.Deferred();
            this._oBundle = oBundle;
            oDeferred.resolve();
            return oDeferred.promise();
        },

        resetPersData : function () {
            var oDeferred = new jQuery.Deferred();
            var oInitialData = {
                    _persoSchemaVersion: "1.0",
                    aColumns : [
                                {
                                    id: "colsetting-tableid-lineid",
                                    order: 0,
                                    text: "{i18n>Picking.Line}",
                                    visible: true
                                },
                                {
                                    id: "colsetting-tableid-modelid",
                                    order: 1,
                                    text: "{i18n>Picking.Model}",
                                    visible: true
                                },
                                {
                                    id: "colsetting-tableid-partid",
                                    order: 2,
                                    text: "{i18n>Picking.Parts}",
                                    visible: true
                                },
                                {
                                    id: "colsetting-tableid-qtyid",
                                    order: 3,
                                    text: "{i18n>Picking.Qty}",
                                    visible: true
                                },
                                {
                                    id: "colsetting-tableid-pickid",
                                    order: 4,
                                    text: "{i18n>Picking.pick}",
                                    visible: true
                                },
                                {
                                    id: "colsetting-tableid-binid",
                                    order: 5,
                                    text: "{i18n>Picking.Bin}",
                                    visible: true
                                },
                                {
                                    id: "colsetting-tableid-batchid",
                                    order: 6,
                                    text: "{i18n>Picking.Batch}",
                                    visible: true
                                },
                                {
                                    id: "colsetting-tableid-grid",
                                    order: 7,
                                    text: "{i18n>Picking.GRDate}",
                                    visible: true
                                }
                            ]
            };

            //set personalization
            this._oBundle = oInitialData;

            //reset personalization, i.e. display table as defined
    //        this._oBundle = null;

            oDeferred.resolve();
            return oDeferred.promise();
        },

        //this caption callback will modify the TablePersoDialog' entry for the 'Weight' column
        //to 'Weight (Important!)', but will leave all other column names as they are.
    /*    getCaption : function (oColumn) {
            if (oColumn.getHeader() && oColumn.getHeader().getText) {
                if (oColumn.getHeader().getText() === "Weight") {
                    return "Weight (Important!)";
                }
            }
            return null;
        },*/

        getGroup : function(oColumn) {
            if( oColumn.getId().indexOf('lineid') != -1 ||
                    oColumn.getId().indexOf('modelid') != -1) {
                return "Primary Group";
            }
            return "Secondary Group";
        }
    };

    return PersoService;

}, /* bExport= */ true);
