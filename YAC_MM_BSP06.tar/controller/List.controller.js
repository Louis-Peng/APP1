sap.ui.define([ "sap/ui/core/mvc/Controller",
                "sap/ui/core/routing/History",
                "sap/ui/model/json/JSONModel",
                "sap/ui/model/odata/v2/ODataModel",
                "sap/ui/model/resource/ResourceModel",
                "sap/m/Button",
                "sap/m/Dialog",
                "sap/m/Text",
                "sap/ui/model/Filter",
                "jquery.sap.global",
                'sap/m/MessageBox',
                'sap/m/TablePersoController',
                'ns/inventory/PersoService',
                'sap/ui/layout/HorizontalLayout',
                "sap/ui/layout/VerticalLayout",
                "sap/ui/layout/form/SimpleForm",
                'sap/ui/core/UIComponent',
                './Formatter'], function(Controller, History,
                JSONModel, ODataModel, ResourceModel, Button, Dialog, Text, Filter, jquery, MessageBox,
                TablePersoController, PersoService,HorizontalLayout,VerticalLayout,SimpleForm,UIComponent,Formatter) {
    "use strict";
    jQuery.sap.require("sap.ndc.BarcodeScanner");
    var tableData = '';
    var valueHelpData = '';
    var sPlant;
    var shousenum;
    var sCount;
    var defaultData = {};
    var newDefaultData = {};
    var tabledata = {};
    var settingModel;
    var Line1 = "@$&";
    var Line2 = "|";
    // proxy/http/160.21.205.176:8001
    var oModel = new ODataModel("/nsinventory/sap/opu/odata/SAP/ZGTWMF060_SRV", true);
    // ?sap-client=331
    return Controller.extend("ns.inventory.controller.List", {
        onInit: function() {
            var oRouter = UIComponent.getRouterFor(this);
            oRouter.getRoute('List').attachMatched(this.fRouteMatched, this);
        },
        fRouteMatched : function() {
                        this._oTPC = new TablePersoController({
                                        table : this.getView().byId("tableid"),
                                        // specify the first part of persistence
                                        // ids e.g.
                                        // 'demoApp-productsTable-dimensionsCol'
                                        componentName : "colsetting",
                                        persoService : PersoService,
                        }).activate();
                        var that = this;
                        var i18nModel = new ResourceModel({
                            bundleName : "ns.inventory.i18n.i18n"
                        });
                        this.getView().byId("multiid").setEnabled(false);
                        // setting dialog
                        oModel.read("/UserParaSet/", {
                                        async : false,
                                        success : function(defaultData) {
                                            if (defaultData.results[0].MSGTYP == "E"){
                                                that.fShowMessageBox('error', defaultData.results[0].MSG);
                                            }
                                            else {
                                            sPlant = defaultData.results[0].WERKS;
                                            shousenum = defaultData.results[0].LGNUM;
                                            that.getView().byId("plantid").setValue(sPlant);
                                            that.getView().byId("housenumid").setValue(shousenum);
                                            newDefaultData.WERKS = defaultData.results[0].WERKS;
                                            newDefaultData.LGNUM = defaultData.results[0].LGNUM;
                                            var aFilter = [];
                                            var filter = new sap.ui.model.Filter({
                                                path : "LGNUM",
                                                operator : sap.ui.model.FilterOperator.EQ,
                                                value1 : shousenum,
                                                value2 : ""
                                            });
                                            aFilter.push(filter);
                                            oModel.read("/StorageTypeSet/", {
                                                async : false,
                                                filters : aFilter,
                                                success : function(oData) {
                                                    if (oData.results[0].MSGTYP == "E"){
                                                        that.fShowMessageBox('error', oData.results[0].MSG);
                                                    } else {
                                                    valueHelpData = oData;
                                                    }
                                                },
                                                error : function(oError) {
                                                    that.fShowMessageBox('error', oError.message);
                                                }
                                            });
                                            }
                                        },
                                        error : function(oError) {
                                            that.fShowMessageBox('error', oError.message);
                                        }
                        });


                    },
                    onSearch : function() {
                        this.fClearMessage();
                        var oI18n = this.getView().getModel("i18n").getResourceBundle();
                        var swarenum = this.getView().byId("housenumid").getValue();
                        var splant = this.getView().byId("plantid").getValue();
                        var stype = this.getView().byId("typeid").getValue();
                        var sbin = this.getView().byId("stbinid").getValue();
                        var sstatus = this.getView().byId("status").getState();
                        if (sstatus == true) {
                            var sEmpty = "X";
                        } else if(sstatus == false) {
                            var sEmpty = "";
                        }
                        // emptyCheck
                        if (swarenum == null || swarenum == "") {
                            this.getView().byId('housenumid').setValueState("Error");
                            this.getView().byId('housenumid').focus();
                            return;
                        }
                        if (splant == null || splant == "") {
                            this.getView().byId('plantid').setValueState("Error");
                            this.getView().byId('plantid').focus();
                            return;
                        }
                        var that = this;
                        var aFilter = [];
                        var f1 = new sap.ui.model.Filter({
                                        path : "LGNUM",
                                        operator : sap.ui.model.FilterOperator.EQ,
                                        value1 : swarenum,
                                        value2 : ""
                        });
;
                        var f2 = new sap.ui.model.Filter({
                                        path : "WERKS",
                                        operator : sap.ui.model.FilterOperator.EQ,
                                        value1 : splant,
                                        value2 : ""
                        });
                        var f3 = new sap.ui.model.Filter({
                                        path : "LGTYP",
                                        operator : sap.ui.model.FilterOperator.EQ,
                                        value1 : stype,
                                        value2 : ""
                        });
                        var f4 = new sap.ui.model.Filter({
                            path : "LGPLA",
                            operator : sap.ui.model.FilterOperator.EQ,
                            value1 : sbin,
                            value2 : ""
            });
                        var f5 = new sap.ui.model.Filter({
                            path : "EMPTY",
                            operator : sap.ui.model.FilterOperator.EQ,
                            value1 : sEmpty,
                            value2 : ""
            });
                        aFilter.push(f1);
                        aFilter.push(f2);
                        if (stype != "" && stype != null) {
                        aFilter.push(f3);
                        }
                        if (sbin != "" && sbin != null) {
                        aFilter.push(f4);
                        }
                        aFilter.push(f5);
                        this.fShowBusyIndicator();
                        oModel.read("/PIListSet/", {
                                        async : false,
                                        filters : aFilter,
                                        success : function(oERP, oResponse) {
                                            that.fHideBusyIndicator();
                                            if (oERP.results[0].MSGTYP == "E") {
                                                that.getView().byId("listTitleid").setText(
                                                                oI18n.getText("Inventory Information") + "(0)");
                                                that.getView().byId('multiid').setEnabled(false);
                                                that.fShowMessageBox('error', oERP.results[0].MSG);
                                                that.getView().byId("tableid").setModel(new JSONModel([]));
                                                that.getView().setModel(new JSONModel());
                                                return;
                                            } else if (oERP.results[0].MSGTYP == "S") {
                                                sCount = oERP.results.length;
                                                that.getView().byId("listTitleid").setText(
                                                                oI18n.getText("Inventory Information") + "("
                                                                                + oERP.results.length + ")");
                                                that.getView().byId('multiid').setEnabled(true);
                                                // search field
                                                for ( var i in oERP.results) {
                                                    var IVNUM = oERP.results[i].IVNUM;
                                                    var IVPOS = oERP.results[i].IVPOS;
                                                    var LGTYP = oERP.results[i].LGTYP;
                                                    var EMPTY = oERP.results[i].EMPTY;
                                                    var LGPLA = oERP.results[i].LGPLA;
                                                    var MATNR = oERP.results[i].MATNR;
                                                    var CHARG = oERP.results[i].CHARG;
                                                    var IDATU = oERP.results[i].IDATU;
                                                    oERP.results[i].filter = IVNUM + IVPOS + LGTYP + EMPTY + LGPLA
                                                                    + MATNR + CHARG + IDATU;
                                                }
                                                tabledata = oERP.results;
                                                that.getView().byId("zerobtnid").setEnabled(true);
                                                that.getView().byId("scanbtnid").setEnabled(true);
                                                var oModel = new JSONModel(oERP);
                                                that.getView().byId("tableid").setModel(oModel);
                                            }
                                        },
                                        error : function(oError) {
                                            that.fHideBusyIndicator();
                                            that.getView().setModel(new JSONModel());
                                            that.fShowMessageBox('error', oError.message);
                                        }
                        })
                    },
                    handleSearch : function(oEvent) {
                        var oI18n = this.getView().getModel("i18n").getResourceBundle();// getText("Picking.Date");
                        var aFilters = [];
                        var sQuery = this.getView().byId("multiid").getValue();
                        this.sQuery = oEvent.getSource().getValue();
                        var f3 = new Filter("filter", sap.ui.model.FilterOperator.Contains, sQuery);
                        aFilters.push(f3);
                        var oTable = this.getView().byId('tableid');
                        var binding = oTable.getBinding("items");
                        binding.filter(aFilters, "Application");
                        this.getView().byId("listTitleid").setText(
                                        oI18n.getText("Picking.Title") + "(" + oTable.getItems().length + "/" + sCount
                                                        + ")");
                    },
                    onNavnext: function(oEvent){
                        var oItem, oCtx, oProperty;
                        oItem = oEvent.getSource();
                        oCtx = oItem.getBindingContext();
                        oProperty = oCtx.getProperty();
                        oProperty.FLAG = false;
                        var oPropertyModel = new JSONModel(oProperty);
                        this.getOwnerComponent().setModel(oPropertyModel,'navModel');
                        var oRouter = UIComponent.getRouterFor(this);
                        oRouter.navTo('Detail');
                    },
                    // confirm, alert, error, information, warning, success
                    fShowMessageBox : function(type, content) {
                        var oI18n = this.getView().getModel("i18n").getResourceBundle();
                        var bCompact = !!this.getView().$().closest(".sapUiSizeCozy").length;
                        var Options = null;
                        if (type == 'none') {
                            Options = {
                                            icon : sap.m.MessageBox.Icon.NONE,
                                            title : oI18n.getText("Picking.noneBox"),
                                            actions : sap.m.MessageBox.Action.OK,
                                            onClose : null,
                                            styleClass : bCompact ? "sapUiSizeCozy" : "",
                                            initialFocus : null,
                                            textDirection : sap.ui.core.TextDirection.Inherit
                            };
                        } else if (type == 'question') {
                            Options = {
                                            icon : sap.m.MessageBox.Icon.QUESTION,
                                            title : oI18n.getText("Picking.questionBox"),
                                            actions : sap.m.MessageBox.Action.OK,
                                            onClose : null,
                                            styleClass : bCompact ? "sapUiSizeCozy" : "",
                                            initialFocus : null,
                                            textDirection : sap.ui.core.TextDirection.Inherit
                            };
                        } else if (type == 'error') {
                            Options = {
                                            icon : sap.m.MessageBox.Icon.ERROR,
                                            title : oI18n.getText("Picking.errorBox"),
                                            actions : sap.m.MessageBox.Action.OK,
                                            onClose : null,
                                            styleClass : bCompact ? "sapUiSizeCozy" : "",
                                            initialFocus : null,
                                            textDirection : sap.ui.core.TextDirection.Inherit
                            };
                        } else if (type == 'information') {
                            Options = {
                                            icon : sap.m.MessageBox.Icon.INFORMATION,
                                            title : oI18n.getText("Picking.informationBox"),
                                            actions : sap.m.MessageBox.Action.OK,
                                            onClose : null,
                                            styleClass : bCompact ? "sapUiSizeCozy" : "",
                                            initialFocus : null,
                                            textDirection : sap.ui.core.TextDirection.Inherit
                            };
                        } else if (type == 'warning') {
                            Options = {
                                            icon : sap.m.MessageBox.Icon.WARNING,
                                            title : oI18n.getText("Picking.warningBox"),
                                            actions : sap.m.MessageBox.Action.OK,
                                            onClose : null,
                                            styleClass : bCompact ? "sapUiSizeCozy" : "",
                                            initialFocus : null,
                                            textDirection : sap.ui.core.TextDirection.Inherit
                            };
                        } else if (type == 'success') {
                            Options = {
                                            icon : sap.m.MessageBox.Icon.SUCCESS,
                                            title : oI18n.getText("Picking.successBox"),
                                            actions : sap.m.MessageBox.Action.OK,
                                            onClose : null,
                                            styleClass : bCompact ? "sapUiSizeCozy" : "",
                                            initialFocus : null,
                                            textDirection : sap.ui.core.TextDirection.Inherit
                            };
                        }
                        sap.m.MessageBox.show(content, Options);
                    },
                    fHideBusyIndicator : function() {
                        var oDialog = sap.ui.getCore().byId('BusyDialog');
                        if (oDialog) {
                            oDialog.close();
                        }
                    },
                    fShowBusyIndicator : function() {
                        var oDialog = sap.ui.getCore().byId('BusyDialog');
                        if (!oDialog) {
                            oDialog = new sap.m.BusyDialog('BusyDialog');
                        }
                        oDialog.open();
                    },
                    fClearMessage : function() {
                        this.getView().byId('housenumid').setValueState("None");
                        this.getView().byId('plantid').setValueState("None");
                    },
                    onClear : function() {
                        var oI18n = this.getView().getModel("i18n").getResourceBundle();
                        this.fClearMessage();
                        this.getView().byId("housenumid").setValue(shousenum);
                        this.getView().byId("multiid").setEnabled(false);
                        this.getView().byId("multiid").setValue("");
                        this.getView().byId("plantid").setValue(sPlant);
                        this.getView().byId("typeid").setValue("");
                        this.getView().byId("stbinid").setValue("");
                        this.getView().byId("tableid").setModel(new JSONModel([]));
                        this.getView().byId("scanbtnid").setEnabled(false);
                        this.getView().byId("zerobtnid").setEnabled(false);
                        this.getView().byId("listTitleid").setText(oI18n.getText("Inventory Information"));
                    },
                    onNavBack : function(oEvent) {
                        var oHistory, sPreviousHash;
                        oHistory = History.getInstance();
                        sPreviousHash = oHistory.getPreviousHash();
                        window.history.go(-1);
                    },
                    onPersoButtonPressed : function(oEvent) {
                        this._oTPC.openDialog();
                    },

                    onTablePersoRefresh : function() {
                        PersoService.resetPersData();
                        this._oTPC.refresh();
                    },
                    onSetting : function() {
                        var oI18n = this.getView().getModel('i18n').getResourceBundle();
                        var that = this;
                        if (!that._settingDialog) {
                            settingModel = {
                                            WERKS : newDefaultData.WERKS,
                                            LGNUM : newDefaultData.LGNUM
                            }
                            sap.ui.getCore().setModel(new JSONModel(settingModel), "settingData")
                            that._settingDialog = new sap.m.Dialog({
                                title : oI18n.getText("Default Setting"),
                                icon : "sap-icon://employee",
                                state : 'Success',
                                content : [
                                    new SimpleForm({
                                content : [ new VerticalLayout({
                                    width : '350px',
                                    content : [ new sap.m.Label({
                                                    text : oI18n.getText("Plant"),
                                                    required : true
                                    }), new sap.m.Input("plant", {
                                                    value : "{settingData>/WERKS}",
                                                    valueLiveUpdate : true,
                                                    maxLength : 4
                                    }),
                                    new sap.m.Label({
                                        text : oI18n.getText("Warehouse Number"),
                                        required : true
                                    }), new sap.m.Input("housenum", {
                                        value : "{settingData>/LGNUM}",
                                        valueLiveUpdate : true,
                                        maxLength : 4
                                    })
                                ]
                                        }) ]
                                }) ]
                            });
                            that._settingDialog.addButton(new sap.m.Button({
                                            text : oI18n.getText("Save"),
                                            type : "Accept",
                                            icon : "sap-icon://save",
                                            press : function() {
                                                if (!that.emptyCheckSet()) {
                                                    return;
                                                } else {
                                                    settingModel.WERKS = sap.ui.getCore().byId('plant').getValue();
                                                    settingModel.LGNUM = sap.ui.getCore().byId('housenum').getValue();
                                                    sap.ui.getCore().setModel(new JSONModel(settingModel),
                                                                    "settingData");
                                                    var oTimeStap = new Date();
                                                    var oData = {};
                                                    oData.WERKS = sap.ui.getCore().byId('plant').getValue();
                                                    oData.LGNUM = sap.ui.getCore().byId('housenum').getValue();
                                                                                                            // OData
                                                                                                            // create
                                                    oModel.create("/UserParaSet/" + '?' + oTimeStap, oData, {
                                                                    success : function(oResult, oResponse) {
                                                                        if (oResult.MSGTYP == "E") {
                                                                            that.fShowMessageBox('error', oResult.MSG);
                                                                        } else {
                                                                            that.onInit();
                                                                        }
                                                                    },
                                                                    error : function(oError) {
                                                                        that.fShowMessageBox('error', oError.message);
                                                                    }
                                                    });
                                                    that._settingDialog.close();
                                                }
                                            }
                            }));
                            that._settingDialog.insertButton(new sap.m.Button({
                                            text : oI18n.getText("Cancel"),
                                            press : function() {
                                                that._settingDialog.close();
                                            }
                            }));
                        }

                        that._settingDialog.open();
                    },
                    emptyCheckSet : function() {
                        var owerks = sap.ui.getCore().byId('plant');
                        var olgnum = sap.ui.getCore().byId("housenum");
                        owerks.setValueState("None");
                        var swerks = owerks.getValue();
                        var slgnum = olgnum.getValue();
                        if (swerks == null || swerks == '') {
                            owerks.setValueState("Error");
                            owerks.focus();
                            return false;
                        } else if (slgnum == null || slgnum == '') {
                            olgnum.setValueState("Error");
                            olgnum.focus();
                            return false;
                        }
                        return true;
                    },
                    handleValueHelp : function(oEvent) {
                        var sInputValue = oEvent.getSource().getValue();
                        this.inputId = oEvent.getSource().getId();
                        // create value help dialog
                        if (!this._valueHelpDialog) {
                            this._valueHelpDialog = sap.ui.xmlfragment("ns.inventory.view.Dialog", this);
                            this.getView().addDependent(this._valueHelpDialog);
                        }
                        this._valueHelpDialog.setModel(new JSONModel(valueHelpData));
                        // create a filter for the binding
                        this._valueHelpDialog.getBinding("items").filter(
                                        [ new Filter("LGTYP", sap.ui.model.FilterOperator.Contains, sInputValue) ]);
                        // open value help dialog filtered by the input value
                        this._valueHelpDialog.open(sInputValue);
                    },

                    _handleValueHelpSearch : function(evt) {
                        var sValue = evt.getParameter("value");
                        var oFilter = new Filter("LGTYP", sap.ui.model.FilterOperator.Contains, sValue);
                        evt.getSource().getBinding("items").filter([ oFilter ]);
                    },

                    _handleValueHelpClose : function(evt) {
                        var oSelectedItem = evt.getParameter("selectedItem");
                        if (oSelectedItem) {
                            var productInput = this.getView().byId(this.inputId);
                            productInput.setValue(oSelectedItem.getTitle());
                            $("#V1").html(oSelectedItem.getTitle());
                        }
                        evt.getSource().getBinding("items").filter([]);
                    },
                    onScan: function(evt) {
                        var oI18n = this.getView().getModel('i18n').getResourceBundle();
                        var that = this;
                        var result = {};
                        result.text = "Y_BATCH_C_POWDER,EA,2.000,4501991108,TEST,1005115919";
                        if(true){
                            sap.ndc.BarcodeScanner.scan(
                                    function(result){
                                        var values = result.text;
                                        var aResult = values.split(',');
                                        if(aResult.length != 6){
                                            this.fShowMessageBox('error', oI18n.getText('ScanFailed'));
                                            return;
                                        }
                                        var smater = aResult[0];
                                        var sCHARG = aResult[5];
                                        var sMENGE = aResult[2];
                                        var sMEINS = aResult[1];
                                        for (var i in tabledata){
                                            var oMatnr = tabledata[i].MATNR;
                                            if(smater == oMatnr){
                                                var oLGPLA = tabledata[i].LGPLA;
                                                var oLGNUM = tabledata[i].LGNUM;
                                                var oLGTYP = tabledata[i].LGTYP;
                                                var oEMPTY = tabledata[i].EMPTY;
                                                break;
                                            }
                                        }
                                        if(smater != oMatnr){
                                            that.fShowMessageBox('error', oI18n.getText('NoMaterial'));
                                            return;
                                        } else {
                                       var navModel = new JSONModel({
                                            MATNR:smater,
                                            LGPLA:oLGPLA,
                                            LGTYP:oLGTYP,
                                            LGNUM:oLGNUM,
                                            WERKS:sPlant,
                                            EMPTY:oEMPTY,
                                            CHARG:sCHARG,
                                            MENGE:sMENGE,
                                            MEINS:sMEINS,
                                            FLAG:true
                                        });
                                        }
                                        var oPropertyModel = navModel;
                                        that.getOwnerComponent().setModel(oPropertyModel,'navModel');
                                        var oRouter = UIComponent.getRouterFor(that);
                                        oRouter.navTo('Detail');
                                           },
                                    function(error){
                                        that.fShowMessageBox('error', oI18n.getText('ScanFailed'));
                                    }
                            );
                        }
                        else{
                            that.fShowMessageBox('error', oI18n.getText('ScanFailed'));
                        }
                    },
                    onZero: function() {
                        var oI18n = this.getView().getModel('i18n').getResourceBundle();
                        var that = this;
                        var splant = this.getView().byId("plantid").getValue();
                        var slgnum = this.getView().byId("housenumid").getValue();
                        var sempty = "X";
                        var sItems = [];
                        for (var i in tabledata){
                            var oEMPTY = tabledata[i].EMPTY;
                            var oIVNUM = tabledata[i].IVNUM;
                            var oIVPOS = tabledata[i].IVPOS;
                            var oLGTYP = tabledata[i].LGTYP;
                            var oLGPLA = tabledata[i].LGPLA;
                            if(oEMPTY == "X"){
                            var sLine = oIVNUM + Line1 + oIVPOS + Line1 + oLGTYP + Line1 + oLGPLA;
                            sItems[i] = sLine;
                            }
                        }
                        var sObject = sItems.join(Line2);
                        var oData = {'IVINF' : sObject,'WERKS' : splant,'LGNUM' : slgnum,'EMPTY' : sempty};
                        var oSubDialog = new sap.m.Dialog({
                            title: oI18n.getText("Confirmation"),
                            state: 'Warning',
                            content: [new sap.m.Label({
                              text: oI18n.getText("Confirm") + "?"
                            })]
                          });
                          oSubDialog.open();
                          oSubDialog.addButton(new sap.m.Button({
                            text: oI18n.getText("OK"),
                            press: function() {
                              oSubDialog.close();
                              var oTimeStap = new Date();
                              oModel.create("/ZeroCountSet" + '?' + oTimeStap , oData,{
                                  async : false,
                                    success: function(oResult, oResponse){
                                      if(oResult.MSGTYP == "E"){
                                        that.fShowMessageBox('error', oResult.MSG);
                                      }else {
                                        that.fShowMessageBox('success', oResult.MSG);
                                      }
                                    },
                                    error: function(oError){
                                      that.fShowMessageBox('error', oError.message);
                                    }
                                });
                            }
                          }));
                          //Cancel
                          oSubDialog.addButton(new sap.m.Button({
                              text: oI18n.getText("Cancel"),
                              press: function() {
                                oSubDialog.close();
                              }
                            }));
                    },
    });
});