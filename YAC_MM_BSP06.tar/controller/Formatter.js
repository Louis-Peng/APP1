sap.ui.define(function() {
    "use strict";

    var Formatter = {
                    buttonText: function(EMPTY){
                        if (EMPTY === 'X') {
                                return 'Navigation';
                            } else {
                                return 'Inactive';
                            }
                    }
    };

    return Formatter;

}, /* bExport= */true);