sap.ui.define([ "sap/ui/core/mvc/Controller",
                "sap/ui/core/routing/History",
                "sap/ui/model/json/JSONModel",
                "sap/ui/model/odata/v2/ODataModel",
                "sap/ui/model/resource/ResourceModel",
                "sap/m/Button",
                "sap/m/Dialog",
                "sap/m/Text",
                "sap/ui/model/Filter",
                "jquery.sap.global",
                'sap/m/MessageBox',
                'sap/m/TablePersoController',
                'ns/inventory/PersoService',
                'sap/ui/layout/HorizontalLayout',
                "sap/ui/layout/VerticalLayout",
                "sap/ui/layout/form/SimpleForm",
                'sap/ui/core/UIComponent',
                './Formatter'], function(Controller, History,
                JSONModel, ODataModel, ResourceModel, Button, Dialog, Text, Filter, jquery, MessageBox,
                TablePersoController, PersoService,HorizontalLayout,VerticalLayout,SimpleForm,UIComponent,Formatter) {
    "use strict";
    jQuery.sap.require("sap.ndc.BarcodeScanner");
    var sPlant;
    var shousenum;
    var sCount;
    var navModel,navData;
    var sFlag = '';
    // proxy/http/160.21.205.176:8001
    var oModel = new ODataModel("/nsinventory/sap/opu/odata/SAP/ZGTWMF060_SRV", true);
    // ?sap-client=331
    return Controller.extend("ns.inventory.controller.Detail", {
        onInit: function() {
            var oRouter = UIComponent.getRouterFor(this);
            oRouter.getRoute('Detail').attachMatched(this.fRouteMatched, this);
        },
        fRouteMatched : function() {
                        var that = this;
                        var i18nModel = new ResourceModel({
                            bundleName : "ns.inventory.i18n.i18n"
                        });
                        var HH = sap.ui.core.format.DateFormat.getDateInstance({
                            pattern : "HH"
                        });
                        var nowDate = new Date();
//                        this.getView().byId('printid').setEnabled(false);
                        var oDate = HH.format(nowDate);
                        if (oDate <= 8) {
                            nowDate.setDate(nowDate.getDate() - 1);
                        }
                        this.getView().byId("dateid").setDateValue(nowDate);
                        navModel = this.getOwnerComponent().getModel('navModel');
                        navData = navModel.getData();
                        sFlag = navData.FLAG;
                        if (sFlag == false) {
                            var sBin = navData.LGPLA;
                            that.getView().byId("storagebinid").setValue(sBin);
                        } else if(sFlag == true) {
                            var sLgnum = navData.LGNUM;
                            var sLGPLA = navData.LGPLA;
                            var sLGTYP = navData.LGTYP;
                            var sWERKS = navData.WERKS;
                            var sMATNR = navData.MATNR;
                            var sCHARG = navData.CHARG;
                            var sEMPTY = navData.EMPTY;
                            var sMENGE = navData.MENGE;
                            var sMEINS = navData.MEINS;
                            that.getView().byId("matnrid").setValue(sMATNR);
                            that.getView().byId("batchid").setValue(sCHARG);
                            that.getView().byId("qtyid").setValue(sMENGE);
                            that.getView().byId("qtyid").setDescription(sMEINS);
                            var aFilter = [];
                            var bFilter = [];
                            var f1 = new sap.ui.model.Filter({
                                            path : "LGNUM",
                                            operator : sap.ui.model.FilterOperator.EQ,
                                            value1 : sLgnum,
                                            value2 : ""
                            });

                            var f2 = new sap.ui.model.Filter({
                                            path : "LGPLA",
                                            operator : sap.ui.model.FilterOperator.EQ,
                                            value1 : sLGPLA,
                                            value2 : ""
                            });
                            var f3 = new sap.ui.model.Filter({
                                            path : "LGTYP",
                                            operator : sap.ui.model.FilterOperator.EQ,
                                            value1 : sLGTYP,
                                            value2 : ""
                            });
                            var f4 = new sap.ui.model.Filter({
                                path : "WERKS",
                                operator : sap.ui.model.FilterOperator.EQ,
                                value1 : sWERKS,
                                value2 : ""
                            });
                            var f5 = new sap.ui.model.Filter({
                                path : "MATNR",
                                operator : sap.ui.model.FilterOperator.EQ,
                                value1 : sMATNR,
                                value2 : ""
                            });
                            var f6 = new sap.ui.model.Filter({
                                path : "CHARG",
                                operator : sap.ui.model.FilterOperator.EQ,
                                value1 : sCHARG,
                                value2 : ""
                            });
                            var f7 = new sap.ui.model.Filter({
                                path : "EMPTY",
                                operator : sap.ui.model.FilterOperator.EQ,
                                value1 : sEMPTY,
                                value2 : ""
                            });
                            aFilter.push(f1);
                            aFilter.push(f2);
                            aFilter.push(f3);
                            aFilter.push(f4);
                            aFilter.push(f5);
                            aFilter.push(f6);
                            aFilter.push(f7);
                           /* bFilter.push(f5);
                            oModel.read("/MatnrDescription/", {
                                async : false,
                                filters : bFilter,
                                success : function(oERP, oResponse) {
                                    that.fHideBusyIndicator();
                                    if (oERP.results[0].MSGTYP == "E") {
                                        that.fShowMessageBox('error', oERP.results[0].MSG);
                                        return;
                                    } else if (oERP.results[0].MSGTYP == "S") {
                                        var sMAKTX = oERP.results[0].MAKTX;
                                        that.getView().byId("descriptionid").setValue(sMAKTX);
                                    }
                                },
                                error : function(oError) {
                                    that.fShowMessageBox('error', oError.message);
                                }
                });*/
                            oModel.read("/PIListSet/", {
                                async : false,
                                filters : aFilter,
                                success : function(oERP, oResponse) {
                                    that.fHideBusyIndicator();
                                    if (oERP.results[0].MSGTYP == "E") {
                                        that.fShowMessageBox('error', oERP.results[0].MSG);
                                        return;
                                    } else if (oERP.results[0].MSGTYP == "S") {
                                        var sBin = [];
                                        for ( var i in oERP.results) {
                                             sBin[i].LGPLA = oERP.results[i].LGPLA;
                                        }
                                        that.getView().byId("storagebinid").setModel(sBin);
                                    }
                                },
                                error : function(oError) {
                                    that.fShowMessageBox('error', oError.message);
                                }
                });
                        }
                    },
                    // confirm, alert, error, information, warning, success
                    fShowMessageBox : function(type, content) {
                        var oI18n = this.getView().getModel("i18n").getResourceBundle();
                        var bCompact = !!this.getView().$().closest(".sapUiSizeCozy").length;
                        var Options = null;
                        if (type == 'none') {
                            Options = {
                                            icon : sap.m.MessageBox.Icon.NONE,
                                            title : oI18n.getText("Picking.noneBox"),
                                            actions : sap.m.MessageBox.Action.OK,
                                            onClose : null,
                                            styleClass : bCompact ? "sapUiSizeCozy" : "",
                                            initialFocus : null,
                                            textDirection : sap.ui.core.TextDirection.Inherit
                            };
                        } else if (type == 'question') {
                            Options = {
                                            icon : sap.m.MessageBox.Icon.QUESTION,
                                            title : oI18n.getText("Picking.questionBox"),
                                            actions : sap.m.MessageBox.Action.OK,
                                            onClose : null,
                                            styleClass : bCompact ? "sapUiSizeCozy" : "",
                                            initialFocus : null,
                                            textDirection : sap.ui.core.TextDirection.Inherit
                            };
                        } else if (type == 'error') {
                            Options = {
                                            icon : sap.m.MessageBox.Icon.ERROR,
                                            title : oI18n.getText("Picking.errorBox"),
                                            actions : sap.m.MessageBox.Action.OK,
                                            onClose : null,
                                            styleClass : bCompact ? "sapUiSizeCozy" : "",
                                            initialFocus : null,
                                            textDirection : sap.ui.core.TextDirection.Inherit
                            };
                        } else if (type == 'information') {
                            Options = {
                                            icon : sap.m.MessageBox.Icon.INFORMATION,
                                            title : oI18n.getText("Picking.informationBox"),
                                            actions : sap.m.MessageBox.Action.OK,
                                            onClose : null,
                                            styleClass : bCompact ? "sapUiSizeCozy" : "",
                                            initialFocus : null,
                                            textDirection : sap.ui.core.TextDirection.Inherit
                            };
                        } else if (type == 'warning') {
                            Options = {
                                            icon : sap.m.MessageBox.Icon.WARNING,
                                            title : oI18n.getText("Picking.warningBox"),
                                            actions : sap.m.MessageBox.Action.OK,
                                            onClose : null,
                                            styleClass : bCompact ? "sapUiSizeCozy" : "",
                                            initialFocus : null,
                                            textDirection : sap.ui.core.TextDirection.Inherit
                            };
                        } else if (type == 'success') {
                            Options = {
                                            icon : sap.m.MessageBox.Icon.SUCCESS,
                                            title : oI18n.getText("Picking.successBox"),
                                            actions : sap.m.MessageBox.Action.OK,
                                            onClose : null,
                                            styleClass : bCompact ? "sapUiSizeCozy" : "",
                                            initialFocus : null,
                                            textDirection : sap.ui.core.TextDirection.Inherit
                            };
                        }
                        sap.m.MessageBox.show(content, Options);
                    },
                    fHideBusyIndicator : function() {
                        var oDialog = sap.ui.getCore().byId('BusyDialog');
                        if (oDialog) {
                            oDialog.close();
                        }
                    },
                    fShowBusyIndicator : function() {
                        var oDialog = sap.ui.getCore().byId('BusyDialog');
                        if (!oDialog) {
                            oDialog = new sap.m.BusyDialog('BusyDialog');
                        }
                        oDialog.open();
                    },
                    fClearMessage : function() {
                        this.getView().byId('housenumid').setValueState("None");
                        this.getView().byId('plantid').setValueState("None");
                    },
                    onNavBack : function(oEvent) {
                        var oHistory, sPreviousHash;
                        oHistory = History.getInstance();
                        sPreviousHash = oHistory.getPreviousHash();
                        window.history.go(-1);
                    },
                    onScan: function() {

                    },
    });
});