sap.ui.define([
	"ns/moreport/test/unit/controller/App.controller"
], function () {
	"use strict";
});
