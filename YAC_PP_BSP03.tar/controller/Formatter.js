sap.ui.define(function() {
	"use strict";
	var Formatter = {

		iconStatus: function(Status) {
			if (Status == '1') {
				return 'sap-icon://message-warning';
			} else if(Status == '0'){
				return 'sap-icon://message-success';
			} else {
				return 'sap-icon://message-warning';
			}
		},
		iconColor: function(Status) {
			if (Status == '1') {
				return 'Error';
			} else if(Status == '0'){
				return 'Success';
			} else {
				return 'Warning';
			}
		},
	};

	return Formatter;

}, /* bExport= */true);