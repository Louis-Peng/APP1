sap.ui.define([
	"ns/moreport/controller/App.controller",
	"sap/ui/model/json/JSONModel",
	"sap/m/MessageBox",
	"sap/ui/model/odata/v2/ODataModel",
	"sap/ui/model/resource/ResourceModel",
	"sap/ui/base/ManagedObject",
	"sap/m/Dialog",
	"sap/m/Button",
	"sap/ui/layout/VerticalLayout",
	"sap/ui/layout/form/SimpleForm" ,
	"sap/ui/model/Filter",
	"jquery.sap.global",
	"sap/m/MessageToast",
	"sap/ui/core/routing/History",
	"sap/ui/core/Fragment",
	"sap/ui/core/UIComponent",
],function(
	App,
	JSONModel,
	MessageBox,
	ODataModel,
	ResourceModel,
	ManagedObject,
	Dialog,
	Button,
	VerticalLayout,
	SimpleForm,
	Filter,
	jquery,
	MessageToast,
	History,
	Fragment,
	UIComponent){
	'use strict';
	/**
	 * Global Variable(Only For Current Page)
	 */
	var NONE = "None";
    var ERROR = "Error";
    var bUpdateModel = undefined;
    var bUpdate = true;
	var navModel,navData;
	//var oModel = new ODataModel('proxy/http/160.21.205.176:8001/sap/opu/odata/SAP/ZGTPPF050_SRV/?sap-client=331');
	var oModel = new ODataModel('/nsmoreport/sap/opu/odata/SAP/ZGTPPF050_SRV/');
	return App.extend('ns.moreport.controller.ReversePage',{
		/**
		 * APP Opened Initialization at First Time
		 * Making ColumnChart Structure And TableColumn SettingController
		 */
		onInit: function() {
			//this.fSetDate();
            var oRouter = UIComponent.getRouterFor(this);
            oRouter.getRoute('reportReverse').attachMatched(this.fRouteMatched, this);
        },
        /**
         * Get SessionModel Form OWnerComponent Created by detialController
         * Set Model
         */
        fRouteMatched: function(){
        	var that = this;
        	var oI18n = that.oI18n = this.getView().getModel('i18n').getResourceBundle();
        	navModel = this.getOwnerComponent().getModel('navModel');
        	navData = navModel.getData();
        	this.setReverseModel();
        },
        /**
         * Set Model to Reverse Page
         */
        setReverseModel: function(){
        	var dDate;
        	if(navData.BUDAT == "" || navData.BUDAT == undefined){
        		dDate = new Date();
        	}else{
        		dDate = new Date(navData.BUDAT);
        	}
        	this.getView().byId('postingDateId').setDateValue(dDate);
        	this.getView().byId('formReverse').setModel(navModel,'data');
        },
        //Control function of Default value of DatePicker display
		fSetDate: function(){
            var dDate = new Date();
            if(dDate.getHours() < 8){
                dDate.setDate(dDate.getDate() - 1);
                this.getView().byId('postingDateId').setDateValue(dDate);
            }
            else{
                this.getView().byId('postingDateId').setDateValue(dDate);
            }
        },
        /**
         * Reverse action
         */
        onReversed: function(){
        	var that = this;
        	var oI18n = this.getView().getModel("i18n").getResourceBundle();
        	if(!this.emptyCheckReverse()){
        		return;
        	}
        	delete navData.filter;
        	var sData = {};//navData
        	sData.Rueck = navData.Rueck;
        	sData.Rmzhl = navData.Rmzhl;
        	sData.Aufnr = navData.Aufnr; //Order Number
        	sData.Werks = navData.Werks; //Plant
        	sData.Matnr = navData.Matnr; //Material Num
        	sData.Gmnga = navData.Gmnga; //Confirned Qty
        	sData.Budat = this.getView().byId('postingDateId').getValue();
        	sData.Ltxa1 = this.getView().byId('reverseReasonId').getValue();
        	var oSubDialog = new sap.m.Dialog({
                title : oI18n.getText("ConfirmTitle"),
                type : 'Message',
                state : 'Warning',
                content : [new sap.m.Label({
                	text : oI18n.getText("reverseConfirmText")
                	//text : oI18n.getText("ConfirmText") + sData.MATNR + "?"
                })]
        	});
        	oSubDialog.open();
        	oSubDialog.addButton(new sap.m.Button({
                text: oI18n.getText("okBtn"),
                press: function() {
                	oModel.create("/CancelConfirmSet/", sData,{
                		async : false,
                		success : function(oData, oResponse){
                			if(oData.Msgtyp == 'S'){
                				//that.fShowMessageBox('success', oData.Msg);
                				var osuccessMsgDialog = new sap.m.Dialog({
                					title: oI18n.getText('boxSuccess'),
                					type: 'Message',
                					state: 'Success',
                					content: [ new sap.m.Label({
                						text: oData.Msg
                					}) ]
                				});
                				osuccessMsgDialog.open();
                				osuccessMsgDialog.addButton(new sap.m.Button({
                					text : oI18n.getText('okBtn'),
                					press : function() {
                						osuccessMsgDialog.close();
                						that.createRefreshModel();
                					}
                				}));
                			}else{//oData.Msgtyp == ''
                				that.fShowMessageBox('error', oData.Msg);
                				return;
                			}
                        },
                        error : function(oError){
                        	that.fShowMessageBox('error', oError.message);
                        }
                	});
                	oSubDialog.close();
                }
            }));
        	//Cancel
			oSubDialog.addButton(new sap.m.Button({
				text: oI18n.getText("cancelBtn"),
				press: function() {
					oSubDialog.close();
				}
			}));
        },
        /**
         * check whether empty when reverse
         * */
        emptyCheckReverse: function(){
        	this.fClearMessage();
        	var sPostingDate = this.getView().byId('postingDateId').getValue();
        	if(sPostingDate == '' || sPostingDate == null){
        		this.getView().byId('postingDateId').setValueState(ERROR);
                this.getView().byId('postingDateId').focus();
                return false;
        	}
        	var sconfirmedTime = this.getView().byId('confirmedTimeId').getValue();
        	if(sconfirmedTime == '' || sconfirmedTime == null){
        		this.getView().byId('confirmedTimeId').setValueState(ERROR);
                this.getView().byId('confirmedTimeId').focus();
                return false;
        	}
        	var sconfirmedQty = this.getView().byId('confirmedQtyId').getValue();
        	if(sconfirmedQty == '' || sconfirmedQty == null){
        		this.getView().byId('confirmedQtyId').setValueState(ERROR);
                this.getView().byId('confirmedQtyId').focus();
                return false;
        	}
        	var sGRQty = this.getView().byId('GRQtyId').getValue();
        	if(sGRQty == '' || sGRQty == null){
        		this.getView().byId('GRQtyId').setValueState(ERROR);
                this.getView().byId('GRQtyId').focus();
                return false;
        	}
        	var sEmployee = this.getView().byId('employeeId').getValue();
        	if(sEmployee == '' || sEmployee == null){
        		this.getView().byId('employeeId').setValueState(ERROR);
                this.getView().byId('employeeId').focus();
                return false;
        	}
        	var sPlanQty = this.getView().byId('planedQtyId').getValue();
        	if(sPlanQty == '' || sEmployee == null){
        		this.getView().byId('planedQtyId').setValueState(ERROR);
                this.getView().byId('planedQtyId').focus();
                return false;
        	}
        	var sDefectQty = this.getView().byId('DefectQtyId').getValue();
        	if(sDefectQty == '' || sDefectQty == null){
        		this.getView().byId('DefectQtyId').setValueState(ERROR);
                this.getView().byId('DefectQtyId').focus();
                return false;
        	}
        	return true;
        },
        /**
         * clear input valueState
         */
        fClearMessage : function(){
			this.getView().byId('postingDateId').setValueState(NONE);
            this.getView().byId('confirmedTimeId').setValueState(NONE);
            this.getView().byId('confirmedQtyId').setValueState(NONE);
            this.getView().byId('GRQtyId').setValueState(NONE);
            this.getView().byId('employeeId').setValueState(NONE);
        },
        //back to previous page
        onNavBackDetail: function(oEvent) {
        	var bUpdateModel = new JSONModel({
                bUpdate: bUpdate //没有冲销时，值为true
            });
        	this.getOwnerComponent().setModel(bUpdateModel, 'bUpdateModelppf050');
            history.go(-1);
        },
        /**
         * Nav back previous page after reverse operation
         */
        createRefreshModel: function(){
			bUpdate = false;
            bUpdateModel = new JSONModel({
                bUpdate: bUpdate //有冲销时，值为false
            });
            this.getOwnerComponent().setModel(bUpdateModel, 'bUpdateModelppf050');
            if(navData.itemQty == 1){
            	history.go(-2);
            }else{
            	history.go(-1);
            }
		},
        /**
         * confirm, alert, error, information, warning, success
		 * Common Method
		 */
        fShowMessageBox : function(type, content) {
            var oI18n = this.getView().getModel("i18n").getResourceBundle();
            var bCompact = !!this.getView().$().closest(".sapUiSizeCozy").length;
            var Options = null;
            if (type == 'none') {
                Options = {
                    icon : sap.m.MessageBox.Icon.NONE,
                    title : oI18n.getText("noneBox"),
                    actions : sap.m.MessageBox.Action.OK,
                    onClose : null,
                    styleClass : bCompact ? "sapUiSizeCozy" : "",
                    initialFocus : null,
                    textDirection : sap.ui.core.TextDirection.Inherit
                };
            } else if (type == 'question') {
                Options = {
                    icon : sap.m.MessageBox.Icon.QUESTION,
                    title : oI18n.getText("questionBox"),
                    actions : sap.m.MessageBox.Action.OK,
                    onClose : null,
                    styleClass : bCompact ? "sapUiSizeCozy" : "",
                    initialFocus : null,
                    textDirection : sap.ui.core.TextDirection.Inherit
                };
            } else if (type == 'error') {
                Options = {
                    icon : sap.m.MessageBox.Icon.ERROR,
                    title : oI18n.getText("boxError"),
                    actions : sap.m.MessageBox.Action.OK,
                    onClose : null,
                    styleClass : bCompact ? "sapUiSizeCozy" : "",
                    initialFocus : null,
                    textDirection : sap.ui.core.TextDirection.Inherit
                };
            } else if (type == 'information') {
                Options = {
                    icon : sap.m.MessageBox.Icon.INFORMATION,
                    title : oI18n.getText("informationBox"),
                    actions : sap.m.MessageBox.Action.OK,
                    onClose : null,
                    styleClass : bCompact ? "sapUiSizeCozy" : "",
                    initialFocus : null,
                    textDirection : sap.ui.core.TextDirection.Inherit
                };
            } else if (type == 'warning') {
                Options = {
                    icon : sap.m.MessageBox.Icon.WARNING,
                    title : oI18n.getText("WARNING"),
                    actions : sap.m.MessageBox.Action.OK,
                    onClose : null,
                    styleClass : bCompact ? "sapUiSizeCozy" : "",
                    initialFocus : null,
                    textDirection : sap.ui.core.TextDirection.Inherit
                };
            } else if (type == 'success') {
                Options = {
                    icon : sap.m.MessageBox.Icon.SUCCESS,
                    title : oI18n.getText("boxSuccess"),
                    actions : sap.m.MessageBox.Action.OK,
                    onClose : null,
                    styleClass : bCompact ? "sapUiSizeCozy" : "",
                    initialFocus : null,
                    textDirection : sap.ui.core.TextDirection.Inherit
                };
            }
            sap.m.MessageBox.show(content, Options);
        },
	});
});