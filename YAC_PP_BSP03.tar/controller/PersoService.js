sap.ui.define(['jquery.sap.global'],
	function(jQuery) {
	"use strict";

	// Very simple page-context personalization
	// persistence service, not for productive use!
	var PersoService = {

		oData : {
			_persoSchemaVersion: "1.0",
			aColumns : [
				{
					id: "colSetting-idDetailTable-idTime",
					order: 0,
					text: "{i18n>detailTableTime}",
					visible: true
				},
				{
					id: "colSetting-idDetailTable-idPlan",
					order: 1,
					text: "{i18n>detailTablePlan}",
					visible: true
				},
				{
					id: "colSetting-idDetailTable-idYield",
					order: 2,
					text: "{i18n>detailTableYield}",
					visible: true
				},
				{
					id: "colSetting-idDetailTable-idEmployee",
					order: 3,
					text: "{i18n>detailTableEmployee}",
					visible: true
				},
				{
					id: "colSetting-idDetailTable-idDefect",
					order: 4,
					text: "{i18n>detailTableDefect}",
					visible: true
				},
				{
                    id: "colSetting-idDetailTable-idReason",
                    order: 5,
                    text: "{i18n>detailTableReason}",
                    visible: true
                },
                {
                    id: "colSetting-idDetailTable-idBreakTime",
                    order: 6,
                    text: "{i18n>detailTableBreakTime}",
                    visible: true
                },
                {
                    id: "colSetting-idDetailTable-idActivity",
                    order: 7,
                    text: "{i18n>detailTableActivity}",
                    visible: true
                },
                {
                    id: "colSetting-idDetailTable-idActivityPerUnit",
                    order: 8,
                    text: "{i18n>detailTableActivityPerUnit}",
                    visible: true
                },
                {
                    id: "colSetting-idDetailTable-idStandardTime",
                    order: 9,
                    text: "{i18n>detailTableStandardTime}",
                    visible: true
                },
                {
                    id: "colSetting-idDetailTable-idDiff",
                    order: 10,
                    text: "{i18n>detailTableDiff}",
                    visible: true
                }
			]
		},

		getPersData : function () {
			var oDeferred = new jQuery.Deferred();
			if (!this._oBundle) {
				this._oBundle = this.oData;
			}
			var oBundle = this._oBundle;
			oDeferred.resolve(oBundle);
			return oDeferred.promise();
		},

		setPersData : function (oBundle) {
			var oDeferred = new jQuery.Deferred();
			this._oBundle = oBundle;
			oDeferred.resolve();
			return oDeferred.promise();
		},

		resetPersData : function () {
			var oDeferred = new jQuery.Deferred();
			var oInitialData = {
					_persoSchemaVersion: "1.0",
					aColumns : [
								{
									id: "colSetting-idDetailTable-idTime",
									order: 0,
									text: "{i18n>detailTableTime}",
									visible: true
								},
								{
									id: "colSetting-idDetailTable-idPlan",
									order: 1,
									text: "{i18n>detailTablePlan}",
									visible: true
								},
								{
									id: "colSetting-idDetailTable-idYield",
									order: 2,
									text: "{i18n>detailTableYield}",
									visible: true
								},
								{
									id: "colSetting-idDetailTable-idEmployee",
									order: 3,
									text: "{i18n>detailTableEmployee}",
									visible: true
								},
								{
									id: "colSetting-idDetailTable-idDefect",
									order: 4,
									text: "{i18n>detailTableDefect}",
									visible: true
								},
								{
				                    id: "colSetting-idDetailTable-idReason",
				                    order: 5,
				                    text: "{i18n>detailTableReason}",
				                    visible: true
				                },
				                {
				                    id: "colSetting-idDetailTable-idBreakTime",
				                    order: 6,
				                    text: "{i18n>detailTableBreakTime}",
				                    visible: true
				                },
				                {
				                    id: "colSetting-idDetailTable-idActivity",
				                    order: 7,
				                    text: "{i18n>detailTableActivity}",
				                    visible: true
				                },
				                {
				                    id: "colSetting-idDetailTable-idActivityPerUnit",
				                    order: 8,
				                    text: "{i18n>detailTableActivityPerUnit}",
				                    visible: true
				                },
				                {
				                    id: "colSetting-idDetailTable-idStandardTime",
				                    order: 9,
				                    text: "{i18n>detailTableStandardTime}",
				                    visible: true
				                },
				                {
				                    id: "colSetting-idDetailTable-idDiff",
				                    order: 10,
				                    text: "{i18n>detailTableDiff}",
				                    visible: true
				                }
							]
			};

			//set personalization
			this._oBundle = oInitialData;

			oDeferred.resolve();
			return oDeferred.promise();
		},

	};

	return PersoService;

}, /* bExport= */ true);