sap.ui.define([ 'ns/moreport/controller/App.controller',
                'sap/ui/core/UIComponent',
                'sap/ui/model/json/JSONModel',
                'sap/viz/ui5/controls/common/feeds/FeedItem',
                'sap/viz/ui5/data/FlattenedDataset',
                'sap/ui/model/odata/ODataModel',
                'sap/ui/model/Filter',
                'sap/ui/model/FilterOperator',
                'sap/m/TablePersoController',
                'ns/moreport/controller/PersoService',
                "sap/ui/model/resource/ResourceModel"
], function(App,UIComponent,JSONModel,FeedItem,FlattenedDataset,ODataModel,Filter,FilterOperator,TablePersoController,PersoService,ResourceModel) {
	'use strict';
	/**
	 * Global Variable(Only For Current Page)
	 */
	var EMPTY = '';
	var NULL = null;
	var bUpdateModel;
	var navModel,navData;
	var reasonModel;
	var sLength;
	var MsgType = '',MsgError;
	var sumWemng,sumIgmng;
	//var oModel = new ODataModel('proxy/http/160.21.205.176:8001/sap/opu/odata/SAP/ZGTPPF050_SRV/?sap-client=331');
	var oModel = new ODataModel('/nsmoreport/sap/opu/odata/SAP/ZGTPPF050_SRV/');
	return App.extend('ns.moreport.controller.ReportDetail', {
		/**
		 * APP Opened Initialization at First Time
		 * Making ColumnChart Structure And TableColumn SettingController
		 */
		onInit: function() {
			var i18nModel = new ResourceModel({
                bundleName : "ns.moreport.i18n.i18n"
            });
            this.getView().setModel(i18nModel, "i18n");

			var oRouter = UIComponent.getRouterFor(this);
            oRouter.getRoute('reportDetail').attachMatched(this.fRouteMatched, this);
            this._oTPC = new TablePersoController({
                table : this.getView().byId('idDetailTable'),
                componentName : 'colSetting',
                persoService : PersoService,
            }).activate();

            this.makeLineChart();
        },
        /**
         * Get SessionModel Form OWnerComponent Created by HomeController
         * Set Model
         */
        fRouteMatched: function(){
        	var oI18n = this.getView().getModel('i18n').getResourceBundle();
        	//无冲销时，bUpdate为true； 有冲销时，bUpdate为false；
        	bUpdateModel = this.getOwnerComponent().getModel('bUpdateModelppf050');
        	if(bUpdateModel == NULL || bUpdateModel == EMPTY || bUpdateModel == undefined){
	        	navModel = this.getOwnerComponent().getModel('navModel');
	        	navData = navModel.getData();
	        }
        	
        	this.setDetailModel();
        },

        onAfterRendering: function() {
        },
        /**
         * ColumnChart Structure Method
         */
        makeLineChart: function(){
        	var oI18n = this.getView().getModel('i18n').getResourceBundle();
        	var namePlanQty = oI18n.getText("reportDetailPagePlanQuantity");
        	var GRPlanQty = oI18n.getText("reportDetailPageGRQuantity");
        	var confirmedPlanQty = oI18n.getText("reportDetailPageConfirmQuantity");
        	
        	var oVizFrame = this.oVizFrame = this.getView().byId('idVizFrame');
        	var oPopOver = this.getView().byId('idPopOver');
            oPopOver.connect(oVizFrame.getVizUid());

            var oDataset = new FlattenedDataset({
                dimensions: [{
                    name: 'Time',
                    value: '{Time}',
                }],
                measures: [{
                    name: namePlanQty,
                    value: '{Plan}'
                }, {
                    name: GRPlanQty,
                    value: '{Gr}'
                }, {
                    name: confirmedPlanQty,
                    value: '{Confirmed}'
                }],
                data: {
                    path: '/results'
                }
            });
            oVizFrame.setDataset(oDataset);
        	
            var feedValueAxis = new FeedItem({
                'uid': 'valueAxis',
                'type': 'Measure',
                'values': [namePlanQty, GRPlanQty, confirmedPlanQty]
            }),
            feedCategoryAxis = new FeedItem({
                'uid': 'categoryAxis',
                'type': 'Dimension',
                'values': ['Time']
            });
            oVizFrame.addFeed(feedValueAxis);
            oVizFrame.addFeed(feedCategoryAxis);
            oVizFrame.setVizProperties({
            	plotArea:{
            		drawingEffect: sap.viz.ui5.types.Line_drawingEffect.glossy
            		/*dataPointStyle: {
            			"rules":[
							{
								"dataContext":["Plan"],
								"displayName":namePlanQty
							},
							{
								"dataContext":["Gr"],
								"displayName":GRPlanQty
							},
							{
								"dataContext":["Confirmed"],
								"displayName":confirmedPlanQty
							}
    			         ]
            		},
                    //colorPalette: ["#FF0000","#FF9900","#009966"],*/
                },
            	title: {
                    visible: false,
                    text: ''
                },
                xAxis : {
					title : {
						visible : false
					}
				},
                valueAxis: {
                    title: {
                        visible: false
                    }
                },
                categoryAxis: {
                    title: {
                        visible: false
                    }
                },
                legend: {
                    title: {
                        visible: false
                    }
                }/*,
                legendGroup: {
                    layout: {
                    	position: "bottom"
                    }
                }*/
            });
        },
        /**
         * Set Model
         */
        setDetailModel: function(){
        	//OData
        	var that = this
        	var oI18n = this.getView().getModel('i18n').getResourceBundle();
        	var rFilter = [];
    		rFilter[0] = new Filter({
                path : 'Aufnr',
                operator : FilterOperator.EQ,
                value1 : navData.Aufnr
        	});
     	   	rFilter[1] = new Filter({
                path : 'Aufpl',
                operator : FilterOperator.EQ,
                value1 : navData.Aufpl
 	   		});
     	   	
        	oModel.read('/zreasonSet/',{
                async : false,
                filters : rFilter,
                success: function(oData){
             	   	if(oData.results[0].Msgtyp == 'E' || oData.results[0].Msgtyp == undefined){
             	   		MsgType = oData.results[0].Msgtyp;
             	   		MsgError = oData.results[0].Msg;
             	   		if(!bUpdateModel.oData.bUpdate){
             	   			that.getView().byId('textGrQtyId').setText('0');
             	   			that.getView().byId('textConfirmQtyId').setText('0');
             	   			that.getView().byId('idProgressPercent').setDisplayValue('0');
             	   			that.getView().byId('idProgress').setDisplayValue('0');
	             	   		var emptyModel = new JSONModel([]);
	            			/*var oVizFrame = that.oVizFrame = that.getView().byId('idVizFrame');
	                        oVizFrame.setModel(emptyModel);*/
	                        var oDetailTable = that.getView().byId('idDetailTable');
	                        oDetailTable.setModel(emptyModel);
             	   		}
             	   		//that.fShowMessageBox('error', oData.results[0].Msg);
             	   		//return;
            		}else {
            			reasonModel = new JSONModel(oData);
            			var oVizFrame = that.oVizFrame = that.getView().byId('idVizFrame');
                        oVizFrame.setModel(reasonModel);
                        var oDetailTable = that.getView().byId('idDetailTable');
                        oDetailTable.setModel(reasonModel);
                        sLength = oData.results.length;
                        sumWemng = 0,sumIgmng = 0;
                        for(var i in oData.results){//用于Table表内的模糊查询
                        	oData.results[i].filter = oData.results[i].Itime + oData.results[i].Iplan
								+ oData.results[i].Gmnga + oData.results[i].Wemng
								+ oData.results[i].Anzma + oData.results[i].Idefect
								+ oData.results[i].Grund + oData.results[i].Grdtx
								+ oData.results[i].Iserh + oData.results[i].Actity
								+ oData.results[i].Pactity + oData.results[i].Vgw01
								+ oData.results[i].Diff;
                        	sumWemng += parseFloat(oData.results[i].Wemng);//收货数量
                        	sumIgmng += parseFloat(oData.results[i].Gmnga);//报工数量
                        }
                        that._setDetailModel();
            		}
                },
                error: function(oError){
                    that.fShowMessageBox('error', oError.message);
                    return;
                }
 	   		});
        },
        _setDetailModel: function(){
        	var that = this
        	var oI18n = this.getView().getModel('i18n').getResourceBundle();
        	navModel.oData.Wemng = sumWemng;
        	navModel.oData.Igmng = sumIgmng;
        	//Title&SimpleFrom
        	this.getView().byId('idReportPage').setTitle(oI18n.getText('reportDetailPageTitle',navData.Aufnr));
        	this.getView().byId('idSimpleForm').setModel(navModel,'data');
        	that.getView().byId('textGrQtyId').setText(sumWemng);
   			that.getView().byId('textConfirmQtyId').setText(sumIgmng);
        	/*20161109-Leeyg-update sPercent结果由”收货数量/订单计划数量“更改为”收货数量/订单计划数量“ navData.Wemng*/
        	var sPercent = Math.round(sumWemng / navData.Gamng * 10000) / 100.00;
        	var sSpeedPercent = sPercent/(sLength-1);
        	var sSpeed = sPercent/((sLength-1)*2);
        	sSpeedPercent = Math.round(sSpeedPercent * 100) / 100;
        	sSpeed = Math.round(sSpeed * 100) / 100  + '/h';
        	var oProgressPercent = this.getView().byId('idProgressPercent');
        	var oProgress = this.getView().byId('idProgress');
        	//var oPercent = this.getView().byId('idPercent');
        	if(sPercent >= 0 && sPercent < 20){
        		oProgressPercent.setPercentValue(sPercent);
        		oProgressPercent.setState('Error');
        		
        		oProgress.setPercentValue(sPercent);
        		oProgress.setDisplayValue(sPercent + '%');
        		oProgress.setState('None');
        		
        		/*oPercent.setPercentValue(parseFloat(sSpeedPercent));
        		oPercent.setDisplayValue(parseFloat(sSpeed));
        		oPercent.setState('Success');*/
        	}else if(sPercent >= 20 && sPercent < 40){
        		oProgressPercent.setPercentValue(sPercent);
        		oProgressPercent.setState('Warning');
        		
        		oProgress.setPercentValue(sPercent);
        		oProgress.setDisplayValue(sPercent + '%');
        		oProgress.setState('Error');
        		
        		/*oPercent.setPercentValue(parseFloat(sSpeedPercent));
        		oPercent.setDisplayValue(parseFloat(sSpeed));
        		oPercent.setState('None');*/
        	}else if(sPercent >= 40 && sPercent < 90){
        		oProgressPercent.setPercentValue(sPercent);
        		oProgressPercent.setState('None');
        		
        		oProgress.setPercentValue(sPercent);
        		oProgress.setDisplayValue(sPercent + '%');
        		oProgress.setState('Success');
        		
        		/*oPercent.setPercentValue(parseFloat(sSpeedPercent));
        		oPercent.setDisplayValue(parseFloat(sSpeed));
        		oPercent.setState('Warning');*/
        	}else {
        		oProgressPercent.setPercentValue(100);
        		oProgressPercent.setState('Success');
        		
        		oProgress.setPercentValue(100);
        		oProgress.setDisplayValue(sPercent + '%');
        		oProgress.setState('Warning');
        		
        		/*oPercent.setPercentValue(parseFloat(100/(sLength-1)));
        		oPercent.setDisplayValue(parseFloat(sSpeed));
        		oPercent.setState('Error');*/
        	}
        },
        /**
         * Screen Out For Results
         * Add Filters With Table Items
         */
        onSearchField: function(evt){
            var sQuery = this.getView().byId('idDetailSearchField').getValue();
            var oFilter = [];
            oFilter[0] = new Filter('filter', FilterOperator.Contains, sQuery);

            this.getView().byId('idDetailTable').getBinding('items').filter(oFilter, 'Application');
        },

        /**
         * TableColumn SettingController Called
         */
        onPersoButtonPressed : function(oEvent) {
            this._oTPC.openDialog();
        },

        onTablePersoRefresh : function() {
            PersoService.resetPersData();
            this._oTPC.refresh();
        },
        /**
         * Nav to Reverse page
         */
        onNavReverse: function(oEvent){
        	var oI18n = this.getView().getModel('i18n').getResourceBundle();
        	var that = this;
        	var oItem, oCtx, oProperty;
        	oItem = oEvent.getSource();
        	oCtx = oItem.getBindingContext();
        	oProperty = oCtx.getProperty();
        	oProperty.Werks = navData.Werks;
        	oProperty.Matnr = navData.Matnr;
        	oProperty.itemQty = sLength;
        	var oPropertyModel = new JSONModel(oProperty);
        	this.getOwnerComponent().setModel(oPropertyModel,'navModel');
        	var oRouter = UIComponent.getRouterFor(this);
        	if(MsgType == 'E'){
        		var osuccessMsgDialog = new sap.m.Dialog({
        			title: oI18n.getText('boxError'),
        			type: 'Message',
        			state: 'Error',
        			content: [ new sap.m.Label({
        				text: MsgError
        			})]
        		});
        		osuccessMsgDialog.addButton(new sap.m.Button({
        			text : oI18n.getText('okBtn'),
        			press : function() {
        				osuccessMsgDialog.close();
        				that.createRefreshModel();
        			}
        		}));
        		osuccessMsgDialog.open();
        		return;
        	}else{
        		oRouter.navTo('reportReverse');
        	}
        },
        /**
         * Nav back previous page when did not reverse
         */
        onNavBackHome: function(){
        	//无冲销时，bUpdate为true； 有冲销时，bUpdate为false；
        	this.getOwnerComponent().setModel(bUpdateModel, 'bUpdateModelppf050');
            history.go(-1);
        },
        /**
         * Auto nav back previous page when reversed the last item
         */
        createRefreshModel: function(){
        	/*bUpdate = false;
            var bUpdateModel = new JSONModel({
                bUpdate: bUpdate
            });*/
        	//无冲销时，bUpdate为true； 有冲销时，bUpdate为false；
            this.getOwnerComponent().setModel(bUpdateModel, 'bUpdateModelppf050');
            history.go(-1);
		},
        /**
         * MessageBox Common Method
         */
        fShowMessageBox: function(type, content){
        	var oI18n = this.getView().getModel('i18n').getResourceBundle();
            var bCompact = !!this.getView().$().closest('.sapUiSizeCozy').length;
            var Options = null;
            if(type == 'error'){
                Options = {
                        icon: sap.m.MessageBox.Icon.ERROR,
                        title: oI18n.getText('boxError'),
                        actions: sap.m.MessageBox.Action.OK,
                        onClose: null,
                        styleClass: bCompact? 'sapUiSizeCozy' : '',
                        initialFocus: null,
                        textDirection: sap.ui.core.TextDirection.Inherit
                };
            }
            else if(type == 'success'){
                Options = {
                        icon: sap.m.MessageBox.Icon.SUCCESS,
                        title: oI18n.getText('boxSuccess'),
                        actions: sap.m.MessageBox.Action.OK,
                        onClose: null,
                        styleClass: bCompact? 'sapUiSizeCozy' : '',
                        initialFocus: null,
                        textDirection: sap.ui.core.TextDirection.Inherit
                };
            }
            sap.m.MessageBox.show(content, Options);

        }
	});
});