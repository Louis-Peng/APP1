sap.ui.define([ 'ns/moreport/controller/App.controller',
                'sap/ui/core/UIComponent',
                'sap/ui/model/odata/ODataModel',
                'sap/m/MessageBox',
                'sap/ui/model/json/JSONModel',
                'sap/ui/model/Filter',
                'sap/ui/model/FilterOperator',
                './Formatter'
], function(App,UIComponent,ODataModel,MessageBox,JSONModel,Filter,FilterOperator,Formatter) {
	'use strict';
	/**
	 * Global Variable(Only For Current Page)
	 */
	var bUpdateModel = undefined;
	var bUpdate = true;
	var initStatus = '';
	var initMessage = '';
	var filterData = {};
	var centerData = {};
	var materialData = {};
	var settingData = {};
	var sShiftDayOrNightVal;
	//var oModel = new ODataModel('proxy/http/160.21.205.176:8001/sap/opu/odata/SAP/ZGTPPF050_SRV/?sap-client=331');
	var oModel = new ODataModel('/nsmoreport/sap/opu/odata/SAP/ZGTPPF050_SRV/');
	return App.extend('ns.moreport.controller.ReportHome', {
		/**
		 * APP Opened Initialization at First Time
		 * Clear Setting Dialog's Session
		 */
		onInit: function() {
            var oRouter = UIComponent.getRouterFor(this);
            oRouter.getRoute('reportHome').attachMatched(this.fRouteMatched, this);
            if(sap.ui.getCore().byId('idSettingWerks')){
        	     sap.ui.getCore().byId('idSettingWerks').destroy();
        		 sap.ui.getCore().byId('idSettingArbpl').destroy();
        	}
        },
        /**
         * Page Initialization
         * Default Value,WorkCenter,Material
         */
        fRouteMatched: function(){
        	var that = this;
        	oModel.read('/UserParaSet/',{
                async : false,
                success: function(oData){
                	if(oData.results[0].Type == 'E' || oData.results[0].Type == undefined){
                		initMessage = oData.results[0].Message;
                		initStatus = 'error';
                		return;
                	}else {
        				filterData.Gstrp = new Date();//Date
                		filterData.Arbpl = oData.results[0].Arbpl;//Work Center
                		filterData.Matnr = '';//Material
                		filterData.Wempf = '';//Production Line
                		filterData.Werks = oData.results[0].Werks;//Plant
                		var wFilter = [];
                		wFilter[0] = new Filter({
                            path : 'Werks',
                            operator : FilterOperator.EQ,
                            value1 : filterData.Werks
                        });
                		oModel.read('/WorkCenterSet/',{
                            async : false,
                            filters : wFilter,
                            success: function(oData){
                            	if(oData.results[0].Type == 'E' || oData.results[0].Type == undefined){
                            		initMessage = oData.results[0].Message;
                            		initStatus = 'error';
                            		return;
                            	}else {
                            		centerData = oData;
                            	}
                            },
                            error: function(oError){
                            	initMessage = oError.message;
                            	initStatus = 'error';
                        		return;
                            }
                 	   	});
                		var mFilter = [];
                		mFilter[0] = new Filter({
                            path : 'Werks',
                            operator : FilterOperator.EQ,
                            value1 : filterData.Werks
                    	});
                 	   	mFilter[1] = new Filter({
                            path : 'Arbpl',
                            operator : FilterOperator.EQ,
                            value1 : filterData.Arbpl
             	   		});
                 	   	oModel.read('/MaterialSet/',{
                           async : false,
                           filters : mFilter,
                           success: function(oData){
                        	   if(oData.results[0].Type == 'E' || oData.results[0].Type == undefined){
                           			initMessage = oData.results[0].Message
                           			initStatus = 'error';
                           			return;
                           		}else {
                           			materialData = oData;
                           			initStatus = '';
                           		}
                           },
                           error: function(oError){
                               initMessage = oError.message;
                               initStatus = 'error';
                               return;
                           }
                	   });
                 	   //无冲销时，bUpdate为true； 有冲销时，bUpdate为false；有冲销的时，执行onSearch()
                 	   bUpdateModel = that.getOwnerComponent().getModel('bUpdateModelppf050');
                 	   if(bUpdateModel != null && bUpdateModel != '' && bUpdateModel != undefined){
                 		  var updateData = bUpdateModel.getData();
                 		  bUpdate = updateData.bUpdate;
                 		  if(!bUpdate){
                 			  that.onSearch();
                 		  }
            	       }
                	}
                },
                error:function(oError){
                	initMessage = oError.message;
                	initStatus = 'error';
                    return;
                }
        	});
        },
        /**
         * AfterRender
         * Server Status Check,Set Model
         */
        onAfterRendering: function() {
        	if(initStatus == 'error'){
        		this.fShowMessageBox(initStatus, initMessage);
        		initStatus = '';
        		filterData.Gstrp = new Date();//Date
        		filterData.Arbpl = '';//Work Center
        		filterData.Matnr = '';//Material
        		filterData.Wempf = '';//Production Line
        		filterData.Werks = '';
        		centerData = {};
            	materialData = {};
        	}
        	var filterModel = new JSONModel(filterData);
        	this.getView().byId('idHomeFilterBar').setModel(filterModel,'data');
        	this.getView().byId('idHomeTable').setModel(new JSONModel());
        	this.getView().byId('idHomeSearchField').setEnabled(false);
        	sShiftDayOrNightVal = this.getView().byId('shiftDayOrNight').getSelectedKey();
        	//sShiftDayOrNightVal = this.getView().byId('shiftDayOrNight').getItemByKey(sShiftDayOrNightId).mProperties.text;
        },
        /**
         * Shift Day or Shift Night change,Data change
         */
        shiftChange: function(oEvent){
        	var that = this;
        	sShiftDayOrNightVal = this.getView().byId('shiftDayOrNight').getSelectedKey();
        	this.onSearch();
        },
        /**
         * Work Center Search Help
         * Create Dialog,Set Model&itemFilter,Confirm value,Close Dialog
         */
        onCenterF4: function (oEvent) {
            var sInputValue = oEvent.getSource().getValue();
            this.inputId = oEvent.getSource().getId();
            // create center dialog
            if (!this._centerDialog) {
                this._centerDialog = sap.ui.xmlfragment('ns.moreport.view.centerDialog',this);
                this.getView().addDependent(this._centerDialog);
            }
            this._centerDialog.setModel(new JSONModel(centerData));
            // create a filter for the binding
            this._centerDialog.getBinding('items').filter([new Filter( 'Arbpl',  FilterOperator.Contains, sInputValue )]);
            // open value help dialog filtered by the input value
            this._centerDialog.open(sInputValue);
        },

        _centerF4Search: function (evt) {
            var sValue = evt.getParameter('value');
            var oFilter = new Filter( 'Arbpl', FilterOperator.Contains, sValue);
            evt.getSource().getBinding('items').filter([oFilter]);
        },

        _centerF4Close: function (evt) {
            var oSelectedItem = evt.getParameter('selectedItem');
            if (oSelectedItem) {
                var oArbpl = this.getView().byId('idArbpl');
                oArbpl.setValue(oSelectedItem.getTitle());
                this.onCenterChangeMaterial();
            }
            evt.getSource().getBinding('items').filter([]);
        },
        /**
         * Work Center LiveChange Material
         * Change Material Data
         */
        onCenterChangeMaterial: function(){
        	var that = this;
        	that.getView().byId('idMatnr').setValue('');
        	var sArbpl = this.getView().byId('idArbpl').getValue();
        	var length = sArbpl.length;
        	if(length == 8){
        		var mFilter = [];
 	     	   	mFilter[0] = new Filter({
 	                path : 'Werks',
 	                operator : FilterOperator.EQ,
 	                value1 : filterData.Werks,
 	                value2 : ''
 	            });
 	     	   	mFilter[1] = new Filter({
 	                path : 'Arbpl',
 	                operator : FilterOperator.EQ,
 	                value1 : sArbpl,
 	                value2 : ''
 	            });
 	     	   	oModel.read('/MaterialSet/',{
 	                async : false,
 	                filters : mFilter,
 	                success: function(oData){
 	             	   materialData = oData;
 	                },
 	                error: function(oError){
 	                    that.fShowMessageBox('error', oError.message);
 	                    materialData = {};
 	                    return;
 	                }
 	     	   });
        	}else{
        		materialData = {};
        	}
        },

        /**
         * Material Search Help
         * Create Dialog,Set Model&itemFilter,Confirm value,Close Dialog
         */
        onMaterialF4: function (oEvent) {
            var sInputValue = oEvent.getSource().getValue();
            this.inputId = oEvent.getSource().getId();
            // Material Dialog
            if (!this._materialDialog) {
                this._materialDialog = sap.ui.xmlfragment('ns.moreport.view.materialDialog',this);
                this.getView().addDependent(this._materialDialog);
            }
            this._materialDialog.setModel(new JSONModel(materialData));
            // create a filter for the binding
            this._materialDialog.getBinding('items').filter([new Filter( 'Matnr',  FilterOperator.Contains, sInputValue )]);
            // open value help dialog filtered by the input value
            this._materialDialog.open(sInputValue);
        },

        _materialF4Search: function (evt) {
            var sValue = evt.getParameter('value');
            var oFilter = new Filter( 'Matnr', FilterOperator.Contains, sValue);
            evt.getSource().getBinding('items').filter([oFilter]);
        },

        _materialF4Close: function (evt) {
            var oSelectedItem = evt.getParameter('selectedItem');
            if (oSelectedItem) {
                var productInput = this.getView().byId(this.inputId);
                productInput.setValue(oSelectedItem.getTitle());
                $('#V1').html(oSelectedItem.getTitle());
            }
            evt.getSource().getBinding('items').filter([]);
        },

        /**
         * User Default Setting
         * Change Default Value,Refresh View
         */
        onSetting: function(event){
        	var oI18n = this.getView().getModel('i18n').getResourceBundle();
        	var that = this;
        	if(!that._settingDialog){
        		settingData.Werks = filterData.Werks;
        		settingData.Arbpl = filterData.Arbpl;
            	sap.ui.getCore().setModel(new JSONModel(settingData),'settingData')
        		that._settingDialog = new sap.m.Dialog({
                    title: oI18n.getText('settingTitle'),
                    icon: 'sap-icon://employee',
                    state: 'Success',
                    content: [new sap.ui.layout.form.SimpleForm({
							content: [
					          new sap.m.Label({text : oI18n.getText('settingPlant'),required:true}),
	                		  new sap.m.Input('idSettingWerks',{value : '{settingData>/Werks}',
	                			  valueLiveUpdate:true,maxLength:4}),    					
                			  new sap.m.Label({text : oI18n.getText('settingWorkCenter'),required:true}),
	                		  new sap.m.Input('idSettingArbpl',{value : '{settingData>/Arbpl}',
	                			  valueLiveUpdate:true,maxLength:8})
					          ]
	            		})]
                  	});
        		that._settingDialog.addButton(new sap.m.Button({
                    text: oI18n.getText('settingSave'),
                    type: 'Accept',
                    icon: 'sap-icon://save',
                    press: function() {
                    	if(!that.emptyCheckSet()){
                    		return;
                    	}else{
                    		var oTimeStap = new Date();
                    		oModel.create('/UserParaSet/' + '?' + oTimeStap , settingData,{
        	              		success: function(oData){
        	              			if(oData.Type == 'E' || oData.Type == undefined){
        	              				that.fShowMessageBox('error', oData.Message);
        	  						}else {
        	  							that.fRouteMatched();
        	  							that.onAfterRendering();
        	  						}
        	                    },
        	                    error: function(oError){
        	      	              	that.fShowMessageBox('error', oError.message);
        	                    }
        	                });
                    		that._settingDialog.close();
                    	}
                     }
                }));
            	that._settingDialog.insertButton(new sap.m.Button({
                    text: oI18n.getText('settingCancel'),
                    press: function() {
                    	that._settingDialog.close();
                    }
                }));
        	}
        	that._settingDialog.open();
        },
        /**
         * Empty Check
         * User Default Value Required in APP
         */
        emptyCheckSet: function(){
        	var oWerks = sap.ui.getCore().byId('idSettingWerks');
        	oWerks.setValueState('None');
        	var sWerks= oWerks.getValue();
        	if ( sWerks == null || sWerks == '') {
        		oWerks.setValueState('Error');
        		oWerks.focus();
                return false;
            }
        	var oArbpl = sap.ui.getCore().byId('idSettingArbpl');
        	oArbpl.setValueState('None');
        	var sArbpl= oArbpl.getValue();
        	if ( sArbpl == null || sArbpl == '') {
        		oArbpl.setValueState('Error');
        		oArbpl.focus();
                return false;
            }
            return true;
        },
        /**
         * Search By Filters
         * Table Set Results Model
         */
        onSearch: function(){
        	this.fClearMessage();
        	if(!this.emptyCheckSearch()){
        		return;
        	}
        	filterData.Gstrp = this.getView().byId('idGstrp').getValue();
        	filterData.Arbpl = this.getView().byId('idArbpl').getValue();
    		filterData.Matnr = this.getView().byId('idMatnr').getValue();
    		filterData.Wempf = this.getView().byId('idWempf').getValue();
    		filterData.Shiftc = sShiftDayOrNightVal;
        	var oI18n = this.getView().getModel('i18n').getResourceBundle();
        	
        	var that = this;
        	var oTimeStap = new Date();
        	var sFilter = [];
        	sFilter[0] = new Filter({
                path: 'Gstrp',//Date
                operator: FilterOperator.EQ,
                value1: filterData.Gstrp
            });
        	
        	if (filterData.Matnr == ""){
            	sFilter[1] = new Filter({
                    path: 'Matnr',//material
                    operator: FilterOperator.Contains,
                    value1: filterData.Matnr
                });       		
        	}else{
            	sFilter[1] = new Filter({
                    path: 'Matnr',//material
                    operator: FilterOperator.EQ,
                    value1: filterData.Matnr
                });        		
        	};

        	if (filterData.Wempf == ""){
            	sFilter[2] = new Filter({
                    path: 'Wempf',//production line
                    operator: FilterOperator.Contains,
                    value1: filterData.Wempf
                });      		
        	}else{
            	sFilter[2] = new Filter({
                    path: 'Wempf',//production line
                    operator: FilterOperator.EQ,
                    value1: filterData.Wempf
                });       		
        	};
        	
        	sFilter[3] = new Filter({
                path: 'Werks',//plant
                operator: FilterOperator.EQ,
                value1: filterData.Werks
            });
        	
        	sFilter[4] = new Filter({
                path: 'Arbpl',//Work Center
                operator: FilterOperator.EQ,
                value1: filterData.Arbpl
            });
        	
        	sFilter[5] = new Filter({
                path: 'Shiftc',//Shift Day or Night - Value is D:ShiftDay, N:ShiftNight
                operator: FilterOperator.EQ,
                value1: filterData.Shiftc
            });
        	
        	oModel.read('/MOCONREPORTSet/' + '?' + oTimeStap, {
                async: false,
                filters: sFilter,
                success: function(oData){
                	if(oData.results[0].Msgtyp == 'E'|| oData.results[0].Msgtyp == undefined){
                		that.fShowMessageBox('error', oData.results[0].Msg);
                		that.getView().byId('idHomeTable').setModel(new JSONModel());
                		that.getView().byId('idHomeSearchField').setEnabled(false);
                	}else {
                		/*Add Filter for SearchField
                		 * Order Number + Material NO. + Material Dec. + Plan Qty +
                		 * Confirmed Qty + Defect Qty + GR Qty + Activity
                		 */
                		for ( var i in oData.results) {
                            oData.results[i].filter = oData.results[i].Aufnr
                            + oData.results[i].Matnr
                            + oData.results[i].Maktx
                            + oData.results[i].Gamng //Target quantity
                            + oData.results[i].Igmng //Confirmed qty
                            + oData.results[i].Iasmg //Confirmed scrap
                            + oData.results[i].Wemng //GR quantity
                            + oData.results[i].Ism01;//Activity
                        }
                		
                		that.getView().byId('idHomeTable').setModel(new JSONModel(oData));
                		that.getView().byId('idHomeSearchField').setEnabled(true);
                	}
                },
                error: function(oError){
                	that.getView().byId('idHomeTable').setModel(new JSONModel());
                	that.getView().byId('idHomeSearchField').setEnabled(false);
                	that.fShowMessageBox('error', oError.message);
                }
            });
        },

        fClearMessage: function(){
            this.getView().byId('idGstrp').setValueState('None');
            this.getView().byId('idMatnr').setValueState('None');
            this.getView().byId('idHomeSearchField').setValue('');
        },
        /**
         * Search Mandatory Filters Empty Check
         */
        emptyCheckSearch: function(){
        	this.fClearMessage();
        	var sGstrp = this.getView().byId('idGstrp').getValue();
            if (sGstrp == null || sGstrp == '') {
                this.getView().byId('idGstrp').setValueState('Error');
                this.getView().byId('idGstrp').focus();
                return false;
            }
            var sArbpl = this.getView().byId('idArbpl').getValue();
            if (sArbpl == null || sArbpl == '') {
                this.getView().byId('idArbpl').setValueState('Error');
                this.getView().byId('idArbpl').focus();
                return false;
            }
            return true;
        },
        /**
         * Screen Out For Results
         * Add Filters With Table Items
         */
        onSearchField: function(evt){
            var sQuery = this.getView().byId('idHomeSearchField').getValue();
            var oFilter = [];
            oFilter[0] = new Filter('filter', FilterOperator.Contains, sQuery);

            this.getView().byId('idHomeTable').getBinding('items').filter(oFilter, 'Application');
        },
        /**
         * Clear Old Filters,Get Default Value
         * Refresh Default Value
         */
        onClear: function(){
        	this.fClearMessage();
        	this.fRouteMatched();
        	this.onAfterRendering();
        },
        /**
         * Navigate To Detail Page
         */
        onNavDetail: function(oEvent){
        	var oItem, oCtx, oProperty;
        	oItem = oEvent.getSource();
        	oCtx = oItem.getBindingContext();
        	oProperty = oCtx.getProperty();
        	        	
        	if (oProperty.Igmng == "0.000" && oProperty.Wemng == "0.000" &&
        	    oProperty.Iasmg == "0.000" && oProperty.Ism01 == "0.000"){
            	var oI18n = this.getView().getModel('i18n').getResourceBundle();
            	var oMessage =oI18n.getText('reportHomePageConfirmedItems',oProperty.Aufnr);
        		this.fShowMessageBox('error', oMessage);
        	} else{
        		var bUpdateModel = undefined;
            	this.getOwnerComponent().setModel(bUpdateModel, 'bUpdateModelppf050');
            	
            	var oPropertyModel = new JSONModel(oProperty);
            	this.getOwnerComponent().setModel(oPropertyModel,'navModel');
            	var oRouter = UIComponent.getRouterFor(this);
                oRouter.navTo('reportDetail');
        	}
        },
        /**
         * MessageBox Common Method
         */
        fShowMessageBox: function(type, content){
        	var oI18n = this.getView().getModel('i18n').getResourceBundle();
            var bCompact = !!this.getView().$().closest('.sapUiSizeCozy').length;
            var Options = null;
            if(type == 'error'){
                Options = {
                    icon: MessageBox.Icon.ERROR,
                    title: oI18n.getText('boxError'),
                    actions: MessageBox.Action.OK,
                    onClose: null,
                    styleClass: bCompact? 'sapUiSizeCozy' : '',
                    initialFocus: null,
                    textDirection: sap.ui.core.TextDirection.Inherit
                };
            }
            else if(type == 'success'){
                Options = {
                    icon: MessageBox.Icon.SUCCESS,
                    title: oI18n.getText('boxSuccess'),
                    actions: MessageBox.Action.OK,
                    onClose: null,
                    styleClass: bCompact? 'sapUiSizeCozy' : '',
                    initialFocus: null,
                    textDirection: sap.ui.core.TextDirection.Inherit
                };
            }
            MessageBox.show(content, Options);
        }
	});
});