sap.ui.define(
		[
         "sap/ui/core/mvc/Controller", "sap/ui/model/resource/ResourceModel"
         ],
         function(Controller, ResourceModel) {
			"use strict";
		    return Controller.extend("ns.bsp05.controller.BaseController",{
		    	onInit: function() {

		            var i18nModel = new ResourceModel({
		               bundleName: "ns.bsp05.i18n.i18n"
		             });
		             this.getView().setModel(i18nModel, "i18n");
		        },
		    	
		    	getRouter : function() {
		            return sap.ui.core.UIComponent.getRouterFor(this);
		        },
		         /**
				 * Convenience method for getting the view model by name.
				 * @public
				 * @param {string} [sName] the model name
				 * @returns {sap.ui.model.Model} the model instance
				 */
				getModel: function(sName) {
					return this.getView().getModel(sName);
				}
				
		    });
});
