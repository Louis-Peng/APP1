sap.ui.define(function() {
    "use strict";
    var Formatter = {
        valueDate: function(svalueDate){
            if (svalueDate === '00000000') {
                return '';
            } else {
                return svalueDate;
            }
        },
        status: function(state){
            if (state === '0') {//0:not be borrowed, 1:borrowed
                return "Not Borrowed";
            } else {
                return "Borrowed" ;
            }
        },
        total: function(numVal){//截取小数点后两位,四舍五入
        	var endTotal;
        	if(typeof numVal === 'number'){
        		endTotal = numVal.toFixed(2);
        	}else{
        		var numTotal = parseFloat(numVal);
        		endTotal = numTotal.toFixed(2);
        	}
        	return endTotal;
        },
        borroweddate: function(bDate){
        	
        },
        planreturndate: function(PrDate){
        	
        },
        counts: function(str){
        	var countNum = Number(str);
   	return countNum;
        }
    };
    return Formatter;
}, /* bExport= */true);