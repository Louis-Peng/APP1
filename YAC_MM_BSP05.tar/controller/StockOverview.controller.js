sap.ui.define([
	"ns/bsp05/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/m/MessageToast",
	"sap/m/MessageBox",
	"sap/ui/layout/VerticalLayout",
	"sap/ui/model/odata/ODataModel",
	"sap/ui/model/resource/ResourceModel",
	"sap/m/Dialog",
	"sap/ui/core/routing/History",
	"./Formatter",
	"sap/m/Text",
	"sap/m/TextArea",
	"sap/m/Button",
	"sap/ui/comp/valuehelpdialog/ValueHelpDialog",
    'sap/ui/core/UIComponent'
], function(BaseController, JSONModel, Filter, FilterOperator, MessageToast, MessageBox, VerticalLayout, ODataModel,
	ResourceModel,
	Dialog,
	History,
	Formatter,
	Text,
	TextArea,
	Button,
	ValueHelpDialog,
	UIComponent) {
	"use strict";
	var flag = false;	
	var scanTimes = 0;
	var plant = "";
	var userPlant = "";
	var materialNumHelpData = {};
	var specialStockHelpData = {};
//    var oModel = new ODataModel("proxy/http/160.21.205.176:8001/sap/opu/odata/sap/ZGTMMF160_SRV?sap-client=331");
	var oModel = new ODataModel("/nsbsp05/sap/opu/odata/sap/ZGTMMF160_SRV", true);
	var initStatus = '';
	var initMessage = '';
	jQuery.sap.require("sap.ndc.BarcodeScanner");
	return BaseController.extend("ns.bsp05.controller.StockOverview", {

		onInit: function() {
			var oRouter = UIComponent.getRouterFor(this);
            oRouter.getRoute('stockOverview').attachMatched(this.fRouteMatched, this);
		},
		
		fRouteMatched: function(){
			this.bKeys = ["Storage Location"];
			this.theStorageTokenInput = this.getView().byId("idStorageLocation");
//			this.theStorageTokenInput.setEnableMultiLineMode(sap.ui.Device.system.phone);

			var oData = {};

			var i18nModel = new ResourceModel({
				bundleName: "ns.bsp05.i18n.i18n"
			});
			this.getView().setModel(i18nModel, "i18n");

			var that = this;

			oModel.read("/UserParameterSet/", {
				async: false,
				success: function(oData) {
					var sPlant = oData.results[0].Plant;
					if (!sPlant) {
						initMessage = oData.results[0].MessageText;
                		initStatus = 'error';
                		return;
					} else {
						userPlant = oData.results[0].Plant;

						oModel.read("/SpecialStockSearchHelpSet/", {
							async: false,
							success: function(oData) {
								// search field
								for (var i in oData.results) {
									var sSpecialStock = oData.results[i].SpecialStock;
									var sSpecialStockDesc = oData.results[i].SpecialStockDescription;
									oData.results[i].filter = sSpecialStock + sSpecialStockDesc;
								}
								specialStockHelpData = oData;
							},
							error: function(oError) {
								that.fShowMessageBox("error", oError.message);
							}
						});
					}
				},
				error: function(oError) {
					that.fShowMessageBox("error", oError.message);
				}
			});
		},
		
		onAfterRendering: function() {
        	if(initStatus == 'error'){
        		var oI18n = this.getView().getModel("i18n").getResourceBundle();
				this.fShowMessageBox(initStatus, oI18n.getText("emptyDefaultSetting"));
        		initStatus = '';
        	}
        },

		onMaterialNOChange: function(oEvent) {
			var sMaterialStr = oEvent.getSource().getValue();
			if(sMaterialStr){
				oEvent.getSource().setValueState("None");
			}
		},

		handleMaterialHelpVal: function(oEvent) {
			if ($.isEmptyObject(materialNumHelpData)) {
				var aFilter = [];
				var filter = new sap.ui.model.Filter({
					path: "Plant",
					operator: sap.ui.model.FilterOperator.EQ,
					value1: userPlant,
					value2: ""
				});
				aFilter.push(filter);
				oModel.read("/MaterialSearchHelpSet/", {
					async: false,
					filters: aFilter,
					success: function(oData) {
						// search field
						for (var i in oData.results) {
							var sMaterialNumber = oData.results[i].MaterialNumber;
							var sMAKTX = oData.results[i].MaterialDescription;
							oData.results[i].filter = sMaterialNumber + sMAKTX;
						}
						materialNumHelpData = oData;
					},
					error: function(oError) {
						that.fShowMessageBox("error", oError.message);
					}
				});
			}
			
			var sInputValue = oEvent.getSource().getValue();
			this.inputId = oEvent.getSource().getId();
			// create value help dialog
			if (!this._materialvalueHelpDialog) {
				this._materialvalueHelpDialog = sap.ui.xmlfragment("ns.bsp05.view.MaterialDialog", this);
				this.getView().addDependent(this._materialvalueHelpDialog);
			}
			//setModel for dialog
			this._materialvalueHelpDialog.setModel(new JSONModel(materialNumHelpData));
			// create a filter for the binding
			this._materialvalueHelpDialog.getBinding("items").filter([new Filter("MaterialNumber", sap.ui.model.FilterOperator.Contains, sInputValue)]);
			// open value help dialog filtered by the input value
			this._materialvalueHelpDialog.open(sInputValue);
		},

		_materialhandleValueHelpSearch: function(evt) {
			var sValue = evt.getParameter("value");
			var oFilter = new Filter("MaterialNumber", sap.ui.model.FilterOperator.Contains, sValue);
			evt.getSource().getBinding("items").filter([oFilter]);
		},
		_materialhandleValueHelpClose: function(evt) {
			var oSelectedItem = evt.getParameter("selectedItem");
			if (oSelectedItem) {
				var productInput = this.getView().byId(this.inputId);
				var materialNumber = oSelectedItem.getTitle();
				if (materialNumber.indexOf("0") == 0) {
					materialNumber = new Number(materialNumber);
				}
				productInput.setValue(materialNumber);
				$("#V1").html(oSelectedItem.getTitle());
			}
			evt.getSource().getBinding("items").filter([]);
		},

		onHandleSpecialStockHelpVal: function(oEvent) {
			var sInputValue = oEvent.getSource().getValue();
			this.inputId = oEvent.getSource().getId();
			// create value help dialog
			if (!this._specialStockHelpDialog) {
				this._specialStockHelpDialog = sap.ui.xmlfragment("ns.bsp05.view.SpecialStockDialog", this);
				this.getView().addDependent(this._specialStockHelpDialog);
			}
			this._specialStockHelpDialog.setModel(new JSONModel(specialStockHelpData));
			// create a filter for the binding
			this._specialStockHelpDialog.getBinding("items").filter([new Filter(
				"SpecialStock",
				sap.ui.model.FilterOperator.Contains, sInputValue
			)]);
			// open value help dialog filtered by the input value
			this._specialStockHelpDialog.open(sInputValue);
		},
		_specialStockHelpSearch: function(evt) {
			var sValue = evt.getParameter("value");
			var oFilter = new Filter(
				"filter",
				sap.ui.model.FilterOperator.Contains, sValue
			);
			evt.getSource().getBinding("items").filter([oFilter]);
		},
		_specialStockHelpClose: function(evt) {
			var oSelectedItem = evt.getParameter("selectedItem");
			if (oSelectedItem) {
				var productInput = this.getView().byId(this.inputId);
				productInput.setValue(oSelectedItem.getTitle());
				$("#V1").html(oSelectedItem.getTitle());
			}
			evt.getSource().getBinding("items").filter([]);
		},

		onHandleStorageLocationHelpVal: function() {
			var that = this;
			var oI18n = this.getView().getModel("i18n").getResourceBundle();
			var onStorageHelpDialog = new ValueHelpDialog({
				basicSearchText: this.theStorageTokenInput.getValue(),
				title: oI18n.getText("StorageLocation"),
				supportMultiselect: true,
				supportRanges: true,
				supportRangesOnly: true,
				key: this.bKeys[0],
				descriptionKey: this.bKeys[1],
				stretch: sap.ui.Device.system.phone,
				ok: function(oControlEvent) {
					that.bTokens = oControlEvent.getParameter("tokens");
					
					try {
						that.validateStorageLocationValues(that.bTokens);
						
						that.theStorageTokenInput.setTokens(that.bTokens);

						onStorageHelpDialog.close();
					} catch (e) {
						var oI18n = that.getView().getModel("i18n").getResourceBundle();
						that.fShowMessageBox('error', oI18n.getText("wrongStorageLocation"));
					}
				},
				cancel: function() {
					sap.m.MessageToast.show("Cancel pressed!");
					onStorageHelpDialog.close();
				},
				afterClose: function() {
					onStorageHelpDialog.destroy();
				}
			});
			onStorageHelpDialog.setRangeKeyFields([{
				label: "Storage Location",
				key: "CompanyCode"
			}]);
			onStorageHelpDialog.setTokens(this.theStorageTokenInput.getTokens());

			if (this.theStorageTokenInput.$().closest(".sapUiSizeCompact").length > 0) { // check if the Token field runs in Compact mode
				onStorageHelpDialog.addStyleClass("sapUiSizeCompact");
			} else {
				onStorageHelpDialog.addStyleClass("sapUiSizeCozy");
			}
			onStorageHelpDialog.open();
		},
		
		validateStorageLocationValues: function (tokens) {
			if (tokens.length > "0") {
				for (var i in tokens) {
					var btoken = tokens[i].getText();
					var value1 = "",
						value2 = "";
					if (btoken.indexOf("(") !== -1) {
						value1 = btoken.replace(/[^a-z^0-9^-]/ig, "");
					} else {
						var m1 = btoken.replace(/[^=><.*]/ig, "");
						switch (m1) {
						case "=":
							value1 = btoken.replace(/[^a-z^0-9^-]/ig, "");
							break;
						case ">":
							value1 = btoken.replace(/[^a-z^0-9^-]/ig, "");
							break;
						case "<":
							value1 = btoken.replace(/[^a-z^0-9^-]/ig, "");
							break;
						case ">=":
							value1 = btoken.replace(/[^a-z^0-9^-]/ig, "");
							break;
						case "<=":
							value1 = btoken.replace(/[^a-z^0-9^-]/ig, "");
							break;
						case "...":
							var valueArray = btoken.split("...");
							value1 = valueArray[0];
							value2 = valueArray[1];
							break;
						case "**":
							value1 = btoken.replace(/[^a-z^0-9^-]/ig, "");
							break;
						case "*":
							if (btoken.indexOf("*") === 0) {
								value1 = btoken.replace(/[^a-z^0-9^-]/ig, "");
								break;
							} else {
								value1 = btoken.replace(/[^a-z^0-9^-]/ig, "");
								break;
							}
						}
					}
					
					if (value1.length > 4  || value2.length > 4) {
						throw "wrongStorageLocation";
					}
				}
			}
		},

		_onHandleSpecialStockHelpSearch: function(evt) {
			var sValue = evt.getParameter("value");
			var oFilter = new Filter("StorageLocation", sap.ui.model.FilterOperator.Contains, sValue);
			evt.getSource().getBinding("items").filter([oFilter]);
		},

		_onHandleSpecialStockHelpClose: function(evt) {
			var oSelectedItem = evt.getParameter("selectedItem");
			if (oSelectedItem) {
				var productInput = this.getView().byId(this.inputId);
				productInput.setValue(oSelectedItem.getTitle());
				$("#V1").html(oSelectedItem.getTitle());
			}
			evt.getSource().getBinding("items").filter([]);
		},

		/**For scan test on PC*/
		onScanTest: function() {
			var that = this;
			var oView = that.getView();
			//test data
			var sResult = {};
			sResult.text = "Y_BATCH_C_POWDER,EA,2.000,4501991108,TEST,1005115919";
			var result = sResult.text.split(",");
			if (result.length !== 6) {
        		//that.onScanError();
                that.onSubmitDialog(
            		'sap-icon://message-error',
            		oI18n.getText("boxError"),
            		oI18n.getText("codeError") + sResult.text
        		);
                return;
        	}
			oView.byId("idMaterialFilter").setValue(result[0]);
			oView.byId("idBatchFilter").setValue(result[5]);
		},

		/**
         *Scan get value of 0:material NO. 1:Unit 2:Qty 3:PO/MO 4:Vender Batch 5:Sap Batch
         */
        onScan : function(){
			flag = true;
			scanTimes += 1;
			var that = this;
			var oData = this.getView().getModel('data');
			var oI18n = this.getView().getModel("i18n").getResourceBundle();
			if(true){
//			if(sap.ui.Device.os.ios){
				//call method to scan
				sap.ndc.BarcodeScanner.scan(
					function(sResult){
						//scan normally by user
	                    if(sResult.cancelled == false){
	                    	//test data
	                    	//var sResult = {};
	                        //sResult.text = "100020772,EA,72.000,4502294340,TEST,2016072101";
	                    	var result = sResult.text.split(',');
	                    	if(result.length != 6){
	                    		//that.onScanError();
	                            that.onSubmitDialog(
                            		'sap-icon://message-error',
                            		oI18n.getText("boxError"),
                            		oI18n.getText("codeError") + sResult.text
                        		);
	                            return;
	                    	}
	                    	var sPoEBELN = result[3],//PO Number
	                    	sMATELNUM = result[0],//Material NO.	                    	
	                    	sUnitMEINS = result[1],//Unit
	                    	sQtyVal = result[2],//Qty
	                    	vdBatchVal = result[4],//Vender Batch
	                    	sSAPBATCH = result[5];//Sap Batch
	                    	
	                    	that.getView().byId('idMaterialFilter').setValue(sMATELNUM);
	                    	that.getView().byId('idBatchFilter').setValue(sSAPBATCH);
	                    }else{
	                    	//that.onScanError();
	                        that.fShowMessageBox('error', oI18n.getText("scanCancel"));
	                        return;
	                    }
					},
					function(error){
						if(scanTimes == 1){
							that.onClear();
						}
						that.onSubmitDialog(
		            		'sap-icon://message-error',
		            		oI18n.getText("boxError"),
		            		oI18n.getText("scanError")
		        		);
					}
				)
			}else{
				//that.onScanError();
				that.onSubmitDialog(
            		'sap-icon://message-error',
            		oI18n.getText("boxError"),
            		oI18n.getText("scanError")
        		);
			}
		},
		/**Error Dialog for scan with submit*/
		onSubmitDialog: function (iconUrl,typeDecs,msgContent) {
			var oData = this.getView().getModel('data');
			var that = this;
			var oI18n = this.getView().getModel("i18n").getResourceBundle();
			var _TextArea = "";
			var dialog = new Dialog({
				icon: iconUrl,
				title: typeDecs,
				type: "Message",
				state: "Error",
				content: [
					new Text({ text: msgContent }),
					_TextArea = new TextArea(that.createId('submitDialogTextarea'), {
						liveChange: function(oEvent) {
							var sText = oEvent.getParameter('value');
							var parent = oEvent.getSource().getParent();
							parent.getBeginButton().setEnabled(sText.length > 0);
						},
						width: '100%',
						placeholder: oI18n.getText("enterQrInfor")
					}),
					_TextArea.addStyleClass("sapUiTinyMarginTop")
				],
				beginButton: new Button({
					text: oI18n.getText("okBtn"),
					enabled: false,
					press: function () {
						var sText = sap.ui.getCore().byId(that.createId('submitDialogTextarea')).getValue();
						var result = {};
						result.text = sText;
						var values = result.text;
		                var aResult = values.split(',');

                    	if(aResult.length != 6){
                    		that.fShowMessageBox('error', oI18n.getText("codeError"));
                    		return;
                    	}
		                var sPoEBELN = aResult[3],//PO NO.
	                    	sMATELNUM = aResult[0],//material number
	                    	sUnitMEINS = aResult[1],//Unit
	                    	sQtyVal = aResult[2],//Qty
	                    	vdBatchVal = aResult[4],//Vender Batch
	                    	sSAPBATCH = aResult[5];//Sap Batch
		
		                if($.trim(sMATELNUM) == "" || sMATELNUM == null || sMATELNUM == undefined){
                    		that.fShowMessageBox('error', oI18n.getText("codeError"));
                    		return;
                    	}
                    	
                    	that.getView().byId('idMaterialFilter').setValue(sMATELNUM);
                    	that.getView().byId('idBatchFilter').setValue(sSAPBATCH);
                    	
                    	that.onSearch();
						dialog.close();
					}
				}),
				endButton: new Button({
					text: oI18n.getText("Cancel"),
					press: function () {
						dialog.close();
					}
				}),
				afterClose: function() {
					dialog.destroy();
				}
			});
			dialog.open();
		},

		onSearch: function() {
			var that = this;
			var aFilter = [];
			var f = [];
			var sFCheckboxVal = "",
				sSCheckboxVal = "",
				sThrCheckboxVal = "";
			var oView = this.getView();
			var sMaterialVal = oView.byId("idMaterialFilter").getValue();
			var aStorageVal = oView.byId("idStorageLocation").getTokens();
			var sBatch = oView.byId("idBatchFilter").getValue();
			var sSpecialStockVal = oView.byId("idSpecialStockIndicator").getValue();
			if (!sMaterialVal) {
				oView.byId("idMaterialFilter").setValueState("Error");
				oView.byId("idMaterialFilter").focus();
				return;
			} else {
				oView.byId("idMaterialFilter").setValueState("None");
			}
			if (oView.byId("idCheckboxFirst").getSelected()) {
				sFCheckboxVal = "X";
			}
			if (oView.byId("idCheckboxSecond").getSelected()) {
				sSCheckboxVal = "X";
			}
			if (oView.byId("idCheckboxThird").getSelected()) {
				sThrCheckboxVal = "X";
			}
			if (aStorageVal.length > "0") {
				for (var i in aStorageVal) {
					var btoken = aStorageVal[i].getText();
					if (btoken.indexOf("(") !== -1) {
						f[i] = new sap.ui.model.Filter({
							path: "StorageLocation",
							operator: sap.ui.model.FilterOperator.NE,
							value1: btoken.replace(/[^a-z^0-9^-]/ig, ""),
							value2: ""
						});
						aFilter.push(f[i]);
					} else {
						var m1 = btoken.replace(/[^=><.*]/ig, "");
						switch (m1) {
							case "=":
								f[i] = new sap.ui.model.Filter({
									path: "StorageLocation",
									operator: sap.ui.model.FilterOperator.EQ,
									value1: btoken.replace(/[^a-z^0-9^-]/ig, ""),
									value2: ""
								});
								aFilter.push(f[i]);
								break;
							case ">":
								f[i] = new sap.ui.model.Filter({
									path: "StorageLocation",
									operator: sap.ui.model.FilterOperator.GT,
									value1: btoken.replace(/[^a-z^0-9^-]/ig, ""),
									value2: ""
								});
								aFilter.push(f[i]);
								break;
							case "<":
								f[i] = new sap.ui.model.Filter({
									path: "StorageLocation",
									operator: sap.ui.model.FilterOperator.LT,
									value1: btoken.replace(/[^a-z^0-9^-]/ig, ""),
									value2: ""
								});
								aFilter.push(f[i]);
								break;
							case ">=":
								f[i] = new sap.ui.model.Filter({
									path: "StorageLocation",
									operator: sap.ui.model.FilterOperator.GE,
									value1: btoken.replace(/[^a-z^0-9^-]/ig, ""),
									value2: ""
								});
								aFilter.push(f[i]);
								break;
							case "<=":
								f[i] = new sap.ui.model.Filter({
									path: "StorageLocation",
									operator: sap.ui.model.FilterOperator.LE,
									value1: btoken.replace(/[^a-z^0-9^-]/ig, ""),
									value2: ""
								});
								aFilter.push(f[i]);
								break;
							case "...":
								var valueArray = btoken.split("...");
								var val1 = valueArray[0];
								var val2 = valueArray[1];
								f[i] = new sap.ui.model.Filter({
									path: "StorageLocation",
									operator: sap.ui.model.FilterOperator.BT,
									value1: val1,
									value2: val2
								});
								aFilter.push(f[i]);
								break;
							case "**":
								f[i] = new sap.ui.model.Filter({
									path: "StorageLocation",
									operator: sap.ui.model.FilterOperator.Contains,
									value1: btoken.replace(/[^a-z^0-9^-]/ig, ""),
									value2: ""
								});
								aFilter.push(f[i]);
								break;
							case "*":
								if (btoken.indexOf("*") === 0) {
									f[i] = new sap.ui.model.Filter({
										path: "StorageLocation",
										operator: sap.ui.model.FilterOperator.StartsWith,
										value1: btoken.replace(/[^a-z^0-9^-]/ig, ""),
										value2: ""
									});
									aFilter.push(f[i]);
									break;
								} else {
									f[i] = new sap.ui.model.Filter({
										path: "StorageLocation",
										operator: sap.ui.model.FilterOperator.EndsWith,
										value1: btoken.replace(/[^a-z^0-9^-]/ig, ""),
										value2: ""
									});
									aFilter.push(f[i]);
									break;
								}
						}
					}
				}
			}
			
			if (userPlant) {
				var f1 = new sap.ui.model.Filter({
					path: "Plant",
					operator: sap.ui.model.FilterOperator.EQ,
					value1: userPlant,
					value2: ""
				});
				aFilter.push(f1);
			}
			
			if (sMaterialVal) {
				var f2 = new sap.ui.model.Filter({
					path: "MaterialNumber",
					operator: sap.ui.model.FilterOperator.EQ,
					value1: sMaterialVal,
					value2: ""
				});
				aFilter.push(f2);
			}
			
			if (sBatch) {
				var f3 = new sap.ui.model.Filter({
					path: "Batch",
					operator: sap.ui.model.FilterOperator.EQ,
					value1: sBatch,
					value2: ""
				});
				aFilter.push(f3);
			}
			
			if (sSpecialStockVal) {
				var f4 = new sap.ui.model.Filter({
					path: "SpecialStock",
					operator: sap.ui.model.FilterOperator.EQ,
					value1: sSpecialStockVal,
					value2: ""
				});
				aFilter.push(f4);
			}
			
			if(sFCheckboxVal) {
				var f5 = new sap.ui.model.Filter({
					path: "ReadSpecialStocksIndicator",
					operator: sap.ui.model.FilterOperator.EQ,
					value1: sFCheckboxVal,
					value2: ""
				});
				aFilter.push(f5);
			}
			
			if (sSCheckboxVal) {
				var f6 = new sap.ui.model.Filter({
					path: "NoZeroStockLinesIndicator",
					operator: sap.ui.model.FilterOperator.EQ,
					value1: sSCheckboxVal,
					value2: ""
				});
				aFilter.push(f6);
			}
			
			if (sThrCheckboxVal) {
				var f7 = new sap.ui.model.Filter({
					path: "DecimalPlaceAsPerUnitIndicator",
					operator: sap.ui.model.FilterOperator.EQ,
					value1: sThrCheckboxVal,
					value2: ""
				});
				aFilter.push(f7);
			}
			
			this.fShowBusyIndicator();
			oModel.read("/SelectionSet?$expand=Categories,Categories/Categories,Categories/Categories/Categories,Categories/Categories/Categories/Categories", {
				async: false,
				filters: aFilter,
				success: function(oERP) {
					that.fHideBusyIndicator();
					var oI18n = that.getView().getModel("i18n").getResourceBundle();
					if (oERP.results.length === 0) {
						that.fShowMessageBox("error", oI18n.getText("NoData"));
						that.getView().byId("idTreeTableBasic").setModel(new JSONModel([]));
						that.getView().byId("idMaterialDesc").setValue("");
						that.getView().byId("idTotalStock").setValue("");
						that.getView().byId("idSafetyStock").setValue("");
						$("input[id*='idSafetyStock-inner']").css("border-color", "transparent");
						return;
					}
					var errorMessage = "";
					if (oERP.results[0].MessageType === "E") {
//						if (oERP.results[0].MessageID === "ZGTFIORI1" && oERP.results[0].MessageNumber === "001") {
//							errorMessage = oI18n.getText("MaterialNumberNotFound");
//						} else {
							errorMessage = oERP.results[0].MessageText;
//						}
						that.fShowMessageBox("error", errorMessage);
						that.getView().byId("idTreeTableBasic").setModel(new JSONModel([]));
						that.onClearFilterInput();
						that.getView().byId("idTotalStock").setValue("");
						that.getView().byId("idSafetyStock").setValue("");
						$("input[id*='idSafetyStock-inner']").css("border-color", "transparent");
						return;
					} else {
						that.reformatServiceRs(oERP.results[0]);
						var selectionResults = {
								"stockList": oERP.results[0]
						}
						var oTableModel = new JSONModel(selectionResults);
						that.getView().byId("idTreeTableBasic").setModel(oTableModel);
						that.getView().byId("idMaterialDesc").setValue(oERP.results[0].MaterialDescription);
						if (oERP.results[0].UnderSafe === "X") {
							$("input[id*='idSafetyStock-inner']").css("border-color", "#e52929");
						} else {
							$("input[id*='idSafetyStock-inner']").css("border-color", "transparent");
						}
			        	
					}
				},
				error: function(oError) {
					that.fHideBusyIndicator();
					that.getView().setModel(new JSONModel());
					that.fShowMessageBox("error", oError.message);
				}
			});
		},

		reformatServiceRs: function (serviceRs) {
			if (serviceRs.hasOwnProperty("Categories")) {
				serviceRs.Categories = serviceRs.Categories.results;
				for (var i = serviceRs.Categories.length - 1; i >= 0; i--) {
					this.reformatServiceRs(serviceRs.Categories[i]);
				}				
			}			
		},

		onSetting: function() {
			var oI18n = this.getView().getModel("i18n").getResourceBundle();
			var that = this;
			if (!that._settingNewDialog) {
				that._settingNewDialog = new sap.m.Dialog({
					title: oI18n.getText("Default"),
					icon: "sap-icon://employee",
					state: "Success",
					content: [
						new sap.ui.layout.form.SimpleForm({
							content: [
								new VerticalLayout({
									width: "350px",
									content: [
										new sap.m.Label({
											text: oI18n.getText("plant"),
											required: true
										}),
										new sap.m.Input("dialogPlantNId", {
											valueLiveUpdate: true,
											maxLength: 4
										})
									]
								})
							]
						})
					]
				});
				that._settingNewDialog.addButton(new sap.m.Button({
					text: oI18n.getText("Save"),
					type: "Accept",
					icon: "sap-icon://save",
					press: function() {
						if (!that.emptyCheckSet()) {
							return;
						} else {
							var userParam = {"Plant": sap.ui.getCore().byId("dialogPlantNId").getValue()};
							oModel.create("/UserParameterSet/", userParam, {
								success: function(oData) {
									if (oData.MessageType == "S") {
										that.getView().byId("idScanBtn").setEnabled(true);
										that.onClearFilterInput();

										userPlant = sap.ui.getCore().byId("dialogPlantNId").getValue();
										materialNumHelpData = {};
									} else { // if(oData.MessageType == "E")
										that.fShowMessageBox("error", oData.MessageText);
										return;
									}
								},
								error: function(oError) {
									that.fShowMessageBox("error", oError.message);
									return;
								}
							});
							that.getView().byId("idTreeTableBasic").setModel(new JSONModel([]));
							that._settingNewDialog.close();
						}
					}
				}));
				that._settingNewDialog.insertButton(new sap.m.Button({
					text: oI18n.getText("Cancel"),
					press: function() {
						that._settingNewDialog.close();
					}
				}));
			}
			sap.ui.getCore().byId("dialogPlantNId").setValue(userPlant);
			that._settingNewDialog.open();
		},
		
		onClearFilterInput: function() {
			var oView = this.getView();
			oView.byId("idMaterialFilter").setValue("");
			oView.byId("idMaterialDesc").setValue("");
			oView.byId("idStorageLocation").setValue("");
			oView.byId("idBatchFilter").setValue("");
			oView.byId("idSpecialStockIndicator").setValue("");
		},

		onClear: function() {
			var oView = this.getView();
			oView.byId("idMaterialFilter").setValue("");
			oView.byId("idMaterialDesc").setValue("");
			oView.byId("idStorageLocation").removeAllTokens();
			oView.byId("idBatchFilter").setValue("");
			oView.byId("idSpecialStockIndicator").setValue("");
			oView.byId("idCheckboxFirst").setSelected(false);
			oView.byId("idCheckboxSecond").setSelected(false);
			oView.byId("idCheckboxThird").setSelected(false);
			oView.byId("idTotalStock").setValue("");
			oView.byId("idSafetyStock").setValue("");
			$("input[id*='idSafetyStock-inner']").css("border-color", "transparent");
			oView.byId("idTreeTableBasic").setModel(new JSONModel([]));
		},
		
		emptyCheckSet: function () {
			var oplantelm = sap.ui.getCore().byId('dialogPlantNId');
            oplantelm.setValueState("None");
            var splantval = oplantelm.getValue();
            if (!splantval) {
            	oplantelm.setValueState("Error");
            	oplantelm.focus();
                return false;
            }
            return true;
		},

		onScanError: function() {
			var oView = this.getView();
			oView.byId("idMaterialFilter").setValue("");
			oView.byId("idBatchFilter").setValue("");
		},

		fHideBusyIndicator: function() {
			var oDialog = sap.ui.getCore().byId("BusyDialog");
			if (oDialog) {
				oDialog.close();
			}
		},
		fShowBusyIndicator: function() {
			var oDialog = sap.ui.getCore().byId("BusyDialog");
			if (!oDialog) {
				oDialog = new sap.m.BusyDialog("BusyDialog");
			}
			oDialog.open();
		},

		fShowMessageBox: function(type, content) {
			var oI18n = this.getView().getModel("i18n").getResourceBundle();
			var bCompact = !!this.getView().$().closest(".sapUiSizeCozy").length;
			var Options = null;
			if (type === "none") {
				Options = {
					icon: sap.m.MessageBox.Icon.NONE,
					title: oI18n.getText("noneBox"),
					actions: sap.m.MessageBox.Action.OK,
					onClose: null,
					styleClass: bCompact ? "sapUiSizeCozy" : "",
					initialFocus: null,
					textDirection: sap.ui.core.TextDirection.Inherit
				};
			} else if (type === "question") {
				Options = {
					icon: sap.m.MessageBox.Icon.QUESTION,
					title: oI18n.getText("questionBox"),
					actions: sap.m.MessageBox.Action.OK,
					onClose: null,
					styleClass: bCompact ? "sapUiSizeCozy" : "",
					initialFocus: null,
					textDirection: sap.ui.core.TextDirection.Inherit
				};
			} else if (type === "error") {
				Options = {
					icon: sap.m.MessageBox.Icon.ERROR,
					title: oI18n.getText("boxError"),
					actions: sap.m.MessageBox.Action.OK,
					onClose: null,
					styleClass: bCompact ? "sapUiSizeCozy" : "",
					initialFocus: null,
					textDirection: sap.ui.core.TextDirection.Inherit
				};
			} else if (type === "information") {
				Options = {
					icon: sap.m.MessageBox.Icon.INFORMATION,
					title: oI18n.getText("informationBox"),
					actions: sap.m.MessageBox.Action.OK,
					onClose: null,
					styleClass: bCompact ? "sapUiSizeCozy" : "",
					initialFocus: null,
					textDirection: sap.ui.core.TextDirection.Inherit
				};
			} else if (type === "warning") {
				Options = {
					icon: sap.m.MessageBox.Icon.WARNING,
					title: oI18n.getText("WARNING"),
					actions: sap.m.MessageBox.Action.OK,
					onClose: null,
					styleClass: bCompact ? "sapUiSizeCozy" : "",
					initialFocus: null,
					textDirection: sap.ui.core.TextDirection.Inherit
				};
			} else if (type === "success") {
				Options = {
					icon: sap.m.MessageBox.Icon.SUCCESS,
					title: oI18n.getText("boxSuccess"),
					actions: sap.m.MessageBox.Action.OK,
					onClose: null,
					styleClass: bCompact ? "sapUiSizeCozy" : "",
					initialFocus: null,
					textDirection: sap.ui.core.TextDirection.Inherit
				};
			}
			sap.m.MessageBox.show(content, Options);
		},
		
		onNavBack: function (oEvent) {
            history.go(-1);
			// var oHistory, sPreviousHash;
			// oHistory = History.getInstance();
			// sPreviousHash = oHistory.getPreviousHash();
			// if (sPreviousHash !== undefined) {
			// 	window.history.go(-1);
			// } else {
			// 	this.getRouter().navTo("stockOverview", {}, true /*no history*/);
			// }
		}
	});

});