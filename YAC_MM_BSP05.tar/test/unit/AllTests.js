sap.ui.define([
	"ns/bsp05/test/unit/controller/App.controller"
], function () {
	"use strict";
});
